---
name: exec-function-checkin
description: Assess and track a student's executive functioning skills across 8 domains (planning, time management, organization, task initiation, working memory, self-monitoring, emotional regulation, cognitive flexibility). Produces a structured EF profile with domain scores, evidence, and 1-2 priority intervention targets. Use at the start of a tutoring engagement, for monthly check-ins, when a student struggles despite knowing the material (suggesting EF gaps not content gaps), during school-year transitions, or when parents/teachers report focus/organization/time-management concerns. Completed in a conversational 10-15 minute interview with the student.
---

# Executive Function Check-In

Conduct a brief, conversational assessment of a student's executive functioning (EF) skills — the mental processes that enable planning, focus, organization, emotional regulation, and self-monitoring. This check-in is done WITH the student, not about them. The output is a structured EF profile with scores across 8 domains, observational evidence, and 1-2 priority domains with specific interventions and measurable goals.

## Workflow Overview

1. **Set the frame** — Explain the purpose and ask the student to self-assess first.
2. **Interview across 8 EF domains** — Ask 2-3 questions per domain; score each 1-5 based on behavioral anchors.
3. **Compare and calibrate** — Share tutor observations; discuss discrepancies with the student.
4. **Generate the EF profile** — Compile scores, evidence, and identify 1-2 priority domains.
5. **Set goals and interventions** — For each priority domain, define a strategy, measurable goal, and tracking method.
6. **Share and plan follow-up** — Provide the profile to parents with home strategies; schedule monthly re-check.

## Step 1 — Frame the Check-In

Explain executive functioning in plain language:

> "Executive functioning skills are basically your brain's management system — how you plan, stay organized, manage your time, get started on tasks, handle frustration, and keep track of what you're doing. Everyone has strengths and growth areas here. This isn't a test; it's a way for us to figure out where tutoring can help you the most beyond just the subject matter."

**Ground rules:**
- The student rates themselves first. The tutor shares their own observations afterward.
- There are no right or wrong answers — honesty helps us build a plan that actually works.
- Discrepancies between self-rating and tutor observation are valuable, not a problem.
- This takes about 10-15 minutes.

**Quick self-assessment warm-up:**
> "If you had to pick one area where you feel strongest — like you generally have things under control — which would it be: planning, time management, staying organized, getting started on work, remembering instructions, catching your own mistakes, handling frustration, or adapting when things change?"

## Step 2 — Interview Across the 8 EF Domains

For each domain, ask the 2-3 questions conversationally. Listen for specific behaviors and examples. Score each domain 1-5 using the behavioral anchors below. Record brief evidence notes (a phrase or sentence per domain).

### Rating Scale (use for every domain)

| Score | Anchor |
|-------|--------|
| 5 | Independent — consistently demonstrates without prompting |
| 4 | Usually demonstrates — occasional support needed |
| 3 | Inconsistent — needs regular support |
| 2 | Rarely demonstrates — needs frequent prompting |
| 1 | Not yet demonstrating — needs intensive support |

### Domain 1: Planning & Prioritization

**Questions to ask:**
1. "When you have a big project or assignment, how do you usually break it down? Walk me through what you did for [recent assignment]."
2. "How far ahead do you typically start working on something that's due?"
3. "When you have multiple assignments, how do you decide what to do first?"

**What to listen for:**
- Breaks tasks into sub-steps vs. sees only the whole
- Starts early vs. night-before pattern
- Uses a system to prioritize (urgency, difficulty, due date) vs. random or avoidance-based order
- Uses tools: planner, calendar, to-do list, digital reminders

### Domain 2: Time Management

**Questions to ask:**
1. "How good are you at guessing how long something takes? For example, how long does homework usually take you?"
2. "Do you usually meet deadlines? When you don't, what gets in the way?"
3. "Are you generally on time for things, or do you tend to run late?"

**What to listen for:**
- Realistic time estimates vs. consistently over/underestimating
- Meets deadlines independently vs. needs reminders/extensions
- Punctuality pattern — chronic lateness or last-minute rushing
- Awareness of how time passes while working (loses track vs. monitors)

### Domain 3: Organization

**Questions to ask:**
1. "Can you show me (or describe) how you keep your school materials organized — backpack, binder, folders, digital files?"
2. "How long does it usually take you to find a specific assignment or set of notes when you need them?"
3. "Have you ever lost an assignment or couldn't find notes when you needed to study?"

**What to listen for:**
- Functional system exists and is maintained vs. chaotic or absent
- Can locate materials quickly (under 2 minutes) vs. lengthy searches or giving up
- Frequency of lost assignments or missing materials
- Physical and/or digital organization habits

### Domain 4: Task Initiation

**Questions to ask:**
1. "When you sit down to do homework, how does it usually go? Do you get started right away or find yourself doing other things first?"
2. "Are there types of work that are especially hard to start? What makes them hard?"
3. "What helps you get going when you don't feel like starting?"

**What to listen for:**
- Starts within a few minutes vs. prolonged procrastination
- Recognizes own avoidance patterns vs. unaware
- Has personal strategies that work vs. relies entirely on external prompting
- Specific triggers: perfectionism, overwhelm, boredom, unclear instructions

### Domain 5: Working Memory

**Questions to ask:**
1. "When a teacher gives multi-step directions, how much do you usually remember?"
2. "Do you ever lose your place in the middle of a problem or forget what you were doing?"
3. "How much do you rely on reminders from other people to remember what to do?"

**What to listen for:**
- Retains multi-step instructions independently vs. needs repetition or written prompts
- Loses track mid-task frequently vs. rarely
- Uses compensatory strategies (notes, checklists, visual cues) effectively
- Needs parent/teacher reminders for routine tasks

### Domain 6: Self-Monitoring

**Questions to ask:**
1. "When you finish an assignment, do you usually check your work before turning it in? What do you check for?"
2. "How do you know when you don't understand something? What do you do about it?"
3. "Do you ask for help when you need it? When do you decide it's time to ask?"

**What to listen for:**
- Reviews work systematically (catches errors, checks against instructions) vs. turns in unchecked
- Recognizes gaps in understanding vs. doesn't realize they're off track
- Asks for help appropriately (not too early, not too late) vs. avoids asking or over-relies
- Can articulate what went wrong when they make a mistake

### Domain 7: Emotional Regulation

**Questions to ask:**
1. "When you get frustrated with schoolwork, what usually happens? How do you handle it?"
2. "How do you feel about making mistakes? How long does it take you to recover?"
3. "How do tests and quizzes feel for you? Do you get nervous? How do you manage that?"

**What to listen for:**
- Recovers from frustration in under 5 minutes vs. shuts down, avoids, or escalates
- Sees mistakes as learning opportunities vs. catastrophizes or gives up
- Manages test anxiety with strategies (breathing, preparation, reframing) vs. panics or avoids
- Seeks support when overwhelmed vs. internalizes or acts out

### Domain 8: Cognitive Flexibility

**Questions to ask:**
1. "How do you do when your plans suddenly change? Can you give me an example?"
2. "When you get stuck on a problem, do you try different ways to solve it, or do you keep doing the same thing?"
3. "How comfortable are you switching from one task to another?"

**What to listen for:**
- Adapts to changes with minimal distress vs. rigid, upset, or resistant
- Generates alternative approaches when stuck vs. perseverates or gives up
- Transitions between tasks smoothly vs. needs significant recovery time
- Open to feedback and trying new methods

## Step 3 — Compare and Calibrate

After the student has self-assessed all 8 domains, share the tutor's own ratings based on session observations.

**Present discrepancies as collaborative data:**
> "You rated yourself a 4 on organization, and from what I've seen in our sessions, I'd put it at a 2 right now. That's not a judgment — it just tells us two things: one, you care about being organized, and two, we might need to build some systems that actually work for you. What do you think?"

**Rules for calibration:**
- If the student rates higher than the tutor: explore what they believe they're doing vs. what's observable. They may have systems that are invisible to you, or they may overestimate.
- If the student rates lower than the tutor: they may have higher internal standards or anxiety. Acknowledge their self-awareness and validate what they are doing well.
- Agree on a final score for each domain. Default to the student's rating unless there is clear observational evidence to the contrary — buy-in matters more than precision.

## Step 4 — Generate the EF Profile

Compile the results into a structured profile. Use this exact format:

---

### Executive Function Profile — [Student Name]

**Date:** [Date] | **Assessment type:** [Baseline / Monthly check-in / Triggered] | **Completed by:** [Tutor name] with [Student name]

---

#### Scores Summary

| # | Domain | Score | Evidence / Observations |
|---|--------|-------|------------------------|
| 1 | Planning & Prioritization | [1-5] | [Brief note] |
| 2 | Time Management | [1-5] | [Brief note] |
| 3 | Organization | [1-5] | [Brief note] |
| 4 | Task Initiation | [1-5] | [Brief note] |
| 5 | Working Memory | [1-5] | [Brief note] |
| 6 | Self-Monitoring | [1-5] | [Brief note] |
| 7 | Emotional Regulation | [1-5] | [Brief note] |
| 8 | Cognitive Flexibility | [1-5] | [Brief note] |

**Average Score:** [Calculate mean of 8 scores, round to 1 decimal]

---

#### Strengths (top 2-3 domains)
1. **[Domain]** — [Specific evidence]
2. **[Domain]** — [Specific evidence]
3. **[Domain]** — [Specific evidence, if applicable]

---

#### Priority Growth Areas (1-2 domains)

For each priority domain, complete the following:

**Priority 1: [Domain Name]** (Score: [X])
- **Why this matters:** [1-2 sentences connecting this EF skill to the student's academic goals]
- **Evidence:** [Specific observation from the check-in]
- **Intervention strategy:** [Specific, actionable tutoring approach]
- **Measurable goal:** [SMART-format goal with timeline]
- **Tracking method:** [How progress will be monitored]

**Priority 2: [Domain Name]** (Score: [X]) *[if applicable]*
- **Why this matters:** [1-2 sentences]
- **Evidence:** [Specific observation]
- **Intervention strategy:** [Specific, actionable tutoring approach]
- **Measurable goal:** [SMART-format goal with timeline]
- **Tracking method:** [How progress will be monitored]

---

#### Progress Tracking (for re-checks)

| Domain | Baseline | Month 1 | Month 2 | Month 3 |
|--------|----------|---------|---------|---------|
| [Domain 1] | [Score] | | | |
| ... | ... | | | |

**Notes from re-check:**

---

## Step 5 — Set Goals and Interventions

For each priority domain, define the intervention using this structure:

### Intervention Template

**Strategy:** A specific tutoring practice or tool (not a vague platitude).
> Good: "Use a visual task breakdown card: student writes 3-5 steps for every assignment before starting."
> Bad: "Work on planning."

**Goal:** Follow SMART criteria — Specific, Measurable, Achievable, Relevant, Time-bound.
> Good: "By [date], student will independently break down 4 out of 5 multi-step assignments into a written plan with 3+ steps before starting, without tutor prompting."
> Bad: "Get better at planning."

**Tracking:** How the tutor will measure progress during sessions.
> Good: "Log on session notes whether student produced a task breakdown card independently. Review tally weekly."
> Bad: "Monitor improvement."

### Example Completed Priority

**Priority 1: Task Initiation** (Score: 2)
- **Why this matters:** Student procrastinates on math homework until the night before, leading to rushed, error-filled work. Improving initiation will reduce stress and improve output quality.
- **Evidence:** Student admitted they "always wait until the last minute" and during sessions needs 10+ minutes of conversation before opening the textbook.
- **Intervention strategy:** Use the "5-minute start" rule — commit to working for just 5 minutes before deciding to stop. Begin each session by setting a 5-minute timer and starting the hardest problem first.
- **Measurable goal:** By [4 weeks from now], student will begin the assigned task within 5 minutes of the session start in 4 out of 5 consecutive sessions, without needing a verbal prompt beyond the initial timer set.
- **Tracking method:** Session log: record minutes to task start and whether the 5-minute timer was used. Review trend after 4 sessions.

## Step 6 — Share and Plan Follow-Up

### Share with the student:
> "Here's what we found. Your strongest areas are [X and Y] — that's great, and we'll keep building on those. The two areas we're going to focus on are [A and B]. I've seen students make real progress on these with practice. Here's the plan..."

### Share with parents (adapt the profile):

Provide a parent-friendly version that includes:
1. The scores summary table
2. The 1-2 priority domains with plain-language explanations
3. **Two specific things parents can do at home:**

   > Example for Task Initiation priority:
   > - "Use a shared visible timer for homework start time. When the timer goes off, your child starts — not when you remind them verbally. Let the timer be the prompt."
   > - "Praise the start, not just the finish. Say 'I noticed you got started right at 4:00 today' rather than only commenting on completed work."

   > Example for Organization priority:
   > - "Do a 5-minute 'bag check' at the same time every evening — not a lecture, just a quick routine: backpack, planner, materials for tomorrow."
   > - "Let your child own the system, even if it's not how you would organize it. The goal is that THEY can find things, not that it looks neat to you."

4. Request parent observations: "Have you noticed similar patterns at home? Anything you'd add?"

### Schedule follow-up:
- Book the next EF check-in for approximately 4 weeks out.
- Between check-ins, log relevant EF observations on session notes.
- On re-check: compare scores to baseline, celebrate any improvement (even 0.5 points), adjust goals if needed.

## Key Principles

- **Student-first calibration:** Always ask the student to self-assess before sharing tutor observations. Discrepancies are data, not problems.
- **Evidence over impressions:** Every score must be backed by a specific behavioral observation or student statement — not a vague feeling.
- **Two priorities max:** Resist the urge to fix everything at once. One strong intervention beats eight weak ones.
- **Strengths matter:** Explicitly name and celebrate the student's top 2-3 domains. EF work is easier when students know what they can rely on.
- **0.5-point increments:** Use half-points when a student's skill level falls between anchors. On re-checks, celebrate any upward movement.
- **Interventions must be session-actionable:** Every strategy must be something the tutor can actually implement during tutoring time, not just a recommendation for the student to do elsewhere.
- **Share with parents as conversation, not diagnosis:** The EF profile is a starting point for collaborative support — frame it as "here's what we're working on" not "here's what's wrong."
- **Re-checks are mandatory:** EF skills develop slowly. Monthly re-checks keep goals alive and build momentum through visible progress.

## Theming / Formatting

- **Tone:** Collaborative, non-judgmental, optimistic-but-realistic. No clinical or deficit-focused language.
- **Language:** Plain, accessible. Avoid terms like "executive dysfunction" or "deficit" — use "growth area," "skill we're building," or "area to strengthen."
- **Student-facing output:** Use the student's name, keep it conversational, include their own words from the interview.
- **Parent-facing output:** Slightly more formal, include concrete home strategies, invite parent input.
- **File format:** Save as plain text or .md for easy copy-paste into session notes, emails, or CRM tools.
