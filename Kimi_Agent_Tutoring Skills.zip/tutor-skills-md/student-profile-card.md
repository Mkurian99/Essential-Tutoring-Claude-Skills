---
name: student-profile-card
description: Create and maintain a living one-page reference profile for each student — capturing learning preferences, strengths, challenges, goals, and personal context. Use during first-session intake, when new insights about a student emerge, at the start of each semester for review, when handing off a student to another tutor, or when a student's situation changes significantly (new school, medication, family events). Produces a quick-scan markdown profile (or .docx) that any tutor can read in 2 minutes and use to personalize instruction immediately.
---

# Student Profile Card

Build and maintain a one-page, quick-scan reference card for every student. This is a LIVING document — it gets appended and revised over time, never rewritten from scratch. The profile is tutor-facing only (not shared with parents or students) and serves two purposes: it captures what works so tutors don't have to rediscover it, and it gives any new tutor working with the student an instant playbook for how to connect and teach effectively.

Two modes:
- **CREATE** — Build the initial profile from an intake conversation (first session).
- **UPDATE** — Add new information, revise outdated facts, update progress metrics. The profile is NEVER rewritten from scratch.

## Workflow Overview

1. **Select mode** — Determine CREATE (new student, no profile) or UPDATE (existing profile).
2. **Gather information** — Use structured prompts to collect data across all 9 sections.
3. **Compile the profile** — Fill the template, keeping every section scannable and concise.
4. **Review and save** — Verify completeness, mark Watch Areas clearly, timestamp all updates.

---

## Step 1 — Select Mode

Determine which mode the session is operating in:

| Mode | Trigger | Opening Approach |
|------|---------|-----------------|
| **CREATE** | First session with new student; no profile exists | Conduct a 10–15 minute intake conversation using the prompts in Step 2. |
| **UPDATE** | Profile exists; new insight emerges, semester starts, student situation changes, or handoff to new tutor | Open existing profile, ask targeted update questions for changed sections only. Append revisions — do not rewrite. |

**Handoff note:** When giving a profile to a new tutor, export as .docx or PDF and include a brief verbal summary: "Start with What Works and Watch Areas — that's everything you need to know."

---

## Step 2 — Gather Information (CREATE Mode)

Conduct a warm, conversational intake. Do NOT read questions like a checklist — weave them naturally into the first session's rapport-building. Cover all 9 sections. Capture short phrases, not paragraphs.

### Section Prompts and Capture Guidance

#### 1. Basics
*Capture: Name, grade, school, subjects tutored, tutoring start date, session frequency/length.*

**Prompts:**
- "Tell me about your school — what grade are you in and where do you go?"
- "What subjects are we working on together?"
- "How often are we meeting and for how long?"

**Capture format:** Short facts only. No commentary.

---

#### 2. Academic Snapshot
*Capture: Current grades by subject (update monthly), strongest/most challenging subjects, recent test scores with dates, learning style hints.*

**Prompts:**
- "Which subject comes easiest to you right now? Which one feels hardest?"
- "What grades are you getting in each class — roughly?"
- "Any recent tests or big assignments? How did they go?"
- "When you're learning something new, what helps it stick — seeing it, hearing it, doing it, or reading about it?"

**Capture format:** Use a mini-table or short bullets. Include dates for all grades and scores.

---

#### 3. Executive Functioning
*Capture: EF check-in scores (1-5) for all 8 domains, last assessed date, top 1-2 EF priorities.*

**Prompts:**
- If an `exec-function-checkin` has been completed: auto-populate scores and priorities from that skill's output.
- If not: "How's your organization with school stuff? How about starting homework — do you jump in or procrastinate?"

**Capture format:** Score table with last-assessed date. Flag if EF check-in is pending.

---

#### 4. Goals
*Capture: Active SMART goals from `smart-goals-planner`. Mark completed goals with completion date. Archive older goals; keep 1-2 most relevant visible.*

**Prompts:**
- "What are you working toward right now — in school and outside of it?"
- If goals exist from `smart-goals-planner`: copy active goals directly. Mark any completed since last update.

**Capture format:** List 1-2 active goals with target dates. Archive completed goals at the bottom of the section with completion dates.

---

#### 5. What Works (THE MOST IMPORTANT SECTION)
*Capture: Specific strategies, phrases, or approaches that resonate with this student. This section prevents rediscovery.*

**Prompts (observe during session, then confirm):**
- "I noticed you seemed to get it when I used that analogy — does that kind of thing usually help?"
- "What do teachers or coaches do that makes things click for you?"
- "When you're stuck, what's the most helpful thing someone can do or say?"

**Capture format:** Short, specific bullets with examples. Each bullet should be actionable by any tutor who reads it.

> Good: "Uses basketball analogies for math concepts (e.g., 'passing' variables across the equation)."
> Bad: "Likes sports."

---

#### 6. Watch Areas (INTERNAL / TUTOR-ONLY)
*Capture: Sensitive topics, triggers, or challenges to navigate carefully. NEVER shared with parents, schools, or other students without explicit permission.*

**Prompts:**
- "Is there anything that makes you feel really frustrated or shut down when we're working?"
- "Are there things teachers do that don't work for you?"
- Observe during the session: frustration cues, avoidance patterns, anxiety signals.

**Capture format:** Clear, non-judgmental bullets. Flag severity if relevant.

> Good: "Gets frustrated with timed practice — start untimed, add time only after confidence builds."
> Bad: "Bad attitude about timing."

**Privacy rule:** This section is marked with a clear INTERNAL header. It is tutor-facing only. Do not include it in any document shared externally.

---

#### 7. Personal Context
*Capture: Family structure, extracurriculars, interests/hobbies, career aspirations. Used for making connections and building rapport.*

**Prompts:**
- "What do you do outside of school?"
- "What are you into — hobbies, sports, games, shows?"
- "Any idea what you want to do when you're older?"
- "Who do you live with?" *(only if it comes up naturally — don't force)*

**Capture format:** Short bullets. Each item should suggest a teaching angle.

> "Plays JV soccer — use sports analogies, respects coach-like structure."
> "Wants to be a vet — use biology/animal examples when possible."

---

#### 8. Session Preferences
*Capture: Preferred session time of day, seating/environment preference, break needs, technology comfort level.*

**Prompts:**
- "Do you feel sharper in the morning or later in the day?"
- "When you're working, do you like quiet or some background noise?"
- "Do you need breaks during a session, or do you prefer to push through?"
- "How comfortable are you with online tools — Google Docs, Desmos, Khan Academy?"

**Capture format:** Short preference bullets.

---

#### 9. Logistics
*Capture: Parent/guardian contact info, billing notes, scheduling constraints, cancellation policy understanding.*

**Prompts:**
- "Who should I contact if I need to reach someone about scheduling or billing?"
- "Are there days or times that absolutely don't work?"
- "Do you know the cancellation policy?"

**Capture format:** Contact info table + short constraint bullets.

---

### UPDATE Mode — Selective Questioning

When updating an existing profile, do NOT re-ask everything. Target only changed sections:

| Situation | Sections to Update | Prompt Example |
|-----------|-------------------|----------------|
| New semester / term | Academic Snapshot, Goals, EF scores | "What classes are you taking this term? Any new goals?" |
| New insight during session | What Works, Watch Areas | "I'm adding this to your profile — it really helped today when we..." |
| Student situation changes | Basics, Personal Context, Watch Areas | "I heard you changed schools — tell me about the new setup." |
| Monthly grade update | Academic Snapshot only | "Let's update your grades — what's changed since last month?" |
| Handoff to new tutor | All sections — verify and refresh | Review each section with the student; confirm What's Works and Watch Areas are current. |

**Update rule:** Always append the new information and update the "Last Updated" date for the section. Never delete historical data unless it is factually wrong — in that case, strike through the old entry and add the correction with the new date.

---

## Step 3 — Compile the Profile

Assemble all captured information into the template below. The profile MUST fit on one printed page (or one screen). Be ruthless about brevity.

### Full Profile Template

```
╔══════════════════════════════════════════════════════════════════════════╗
║  STUDENT PROFILE — [First Name Last Name]                    [Initial / Update] ║
╠══════════════════════════════════════════════════════════════════════════╣

┌─ QUICK STATS ──────────────────────────────────────────────────────────┐
│ Grade: [X]    │ School: [Name]        │ Subjects: [List]              │
│ Start Date: [X] │ Frequency: [Xx/week, X min] │ Last Profile Update: [Date] │
└────────────────────────────────────────────────────────────────────────┘

━━ BASICS ━━━━━━━━━━━━━━━━━━━━━━━━━ [Last updated: Date]
• Name: [Full name] (prefers [nickname if any])
• Grade: [X] at [School]
• Subjects tutored: [List]
• Tutoring since: [Date]  |  Sessions: [Frequency, length]
• Primary contact: [Name, relationship, phone/email]

━━ ACADEMIC SNAPSHOT ━━━━━━━━━━━━━━ [Last updated: Date]
Subject          │ Current Grade │ Recent Scores            │ Notes
─────────────────┼───────────────┼──────────────────────────┼─────────────
[Subject 1]      │ [Grade]       │ [Test: Score, Date]      │ [Brief]
[Subject 2]      │ [Grade]       │ [Test: Score, Date]      │ [Brief]
[Subject 3]      │ [Grade]       │                          │ [Brief]

• Strongest subject: [Name] — [one-line evidence]
• Most challenging: [Name] — [one-line evidence]
• Learning style: [Visual / Auditory / Kinesthetic / Reading / Mixed / Unknown]

━━ EXECUTIVE FUNCTIONING ━━━━━━━━━━ [Last updated: Date]  [Next check: Date]
Domain                     │ Score │ Evidence
───────────────────────────┼───────┼────────────────────────────────────
Planning & Prioritization  │ [1-5] │ [Brief note]
Time Management            │ [1-5] │ [Brief note]
Organization               │ [1-5] │ [Brief note]
Task Initiation            │ [1-5] │ [Brief note]
Working Memory             │ [1-5] │ [Brief note]
Self-Monitoring            │ [1-5] │ [Brief note]
Emotional Regulation       │ [1-5] │ [Brief note]
Cognitive Flexibility      │ [1-5] │ [Brief note]
                           │       │
Average: [X.X]             │       │ Top EF priorities: [1], [2]

━━ GOALS ━━━━━━━━━━━━━━━━━━━━━━━━━━ [Last updated: Date]
Active:
• [Goal text — from SMART goals planner] — by [target date]
• [Goal text] — by [target date]

Recently completed:
• [Goal text] — completed [date]

Archived:
• [Older goals with completion dates, if space allows]

━━ WHAT WORKS ━━━━━━━━━━━━━━━━━━━━━ [Last updated: Date]
• [Specific strategy, phrase, or approach with context]
• [Specific strategy with context]
• [Specific strategy with context]
• [Specific strategy with context]

━━ WATCH AREAS — INTERNAL / TUTOR-ONLY ━━━━━━━━━━━━━━━━━ [Last updated: Date]
⚠  This section is CONFIDENTIAL. Tutor-facing only. Do not share.
• [Sensitive topic or trigger — with navigation guidance]
• [Challenge area — with specific workaround]
• [Challenge area — with specific workaround]

━━ PERSONAL CONTEXT ━━━━━━━━━━━━━━━ [Last updated: Date]
• Family: [Brief — only if relevant to tutoring]
• Activities: [Extracurriculars, sports, clubs, jobs]
• Interests: [Hobbies, passions, favorites — with teaching angles noted]
• Career aspiration: [If known — with subject-connection noted]

━━ SESSION PREFERENCES ━━━━━━━━━━━━ [Last updated: Date]
• Best time of day: [Morning / Afternoon / Evening / No preference]
• Environment: [Quiet / Background noise / Specific seating / etc.]
• Breaks: [Frequency and length, or none needed]
• Tech comfort: [Tools the student uses well or needs support with]

━━ LOGISTICS ━━━━━━━━━━━━━━━━━━━━━━ [Last updated: Date]
• Billing contact: [Name, email, phone]
• Scheduling constraints: [Specific days/times that don't work]
• Cancellation policy: [Confirmed / Not yet discussed]
• Other: [Any relevant administrative notes]

═══════════════════════════════════════════════════════════════════════════
Profile created: [Date]  |  Created by: [Tutor Name]
Next review scheduled: [Date]
═══════════════════════════════════════════════════════════════════════════
```

### One-Page Constraint Rules

- Use short phrases and bullets. No paragraphs.
- Every entry in **What Works** and **Watch Areas** must fit on one line.
- If the profile exceeds one page, trim from the bottom up: Archived goals first, then Personal Context details, then Logistics. Never trim What Works or Watch Areas.
- Use abbreviations and shorthand freely — this is an internal reference, not a formal document.

---

## Step 4 — Review and Save

Before saving, verify against this checklist:

- [ ] Every section has a "Last updated" date.
- [ ] **What Works** has at least 3 specific, actionable entries.
- [ ] **Watch Areas** is clearly marked INTERNAL/TUTOR-ONLY.
- [ ] **Basics** and **Logistics** are complete (these rarely change — get them right the first time).
- [ ] **Academic Snapshot** grades and scores have dates attached.
- [ ] **EF scores** include the last assessed date and next check date.
- [ ] **Goals** are copied from the SMART goals planner (not invented independently).
- [ ] The entire profile fits on one page.
- [ ] File is saved as: `[StudentLastName]_[FirstInitial]_Profile_[YYYY-MM-DD].md` (or .docx)
- [ ] In UPDATE mode: all new information is appended, not overwritten; outdated facts are struck through with correction and new date.

---

## Key Principles

- **Living document, not a report.** This profile is continuously updated — never archive the old version; revise in place. Every section carries its own "last updated" date so you know what's fresh and what's stale.
- **Reference, not narrative.** A new tutor should be able to read this in 2 minutes and know how to work with the student. Bullets, not paragraphs. Short phrases, not full sentences where possible.
- **What Works is sacred.** This section captures hard-won insight about the student. Never let it get trimmed for space. Every entry must be specific enough that a substitute tutor can act on it immediately.
- **Watch Areas are confidential.** Marked clearly as INTERNAL/TUTOR-ONLY. Never shared with parents, schools, or other students. Include navigation guidance, not just problem descriptions — every Watch Area entry should end with what TO do, not just what NOT to do.
- **Never rewrite from scratch on updates.** Append new information. Strike through outdated facts with a correction and new date. This preserves history and shows the student's evolution over time.
- **Integrate with related skills.** Pull EF scores from `exec-function-checkin` and goals from `smart-goals-planner`. Cross-reference `session-notes-writer` for recent flags or performance trends to keep the Academic Snapshot current.
- **Student-driven where possible.** Ask the student before adding things to What Works and Watch Areas: "Can I add this to your profile so other tutors know what works for you?" This builds trust and gives the student agency.
- **One page, always.** If it doesn't fit, cut detail — not sections. The profile is designed for quick scanning during a session transition or by a new tutor before their first meeting.
- **Use for continuity, not surveillance.** The profile exists to help tutors serve the student better — not to track, diagnose, or label. Every entry should enable better teaching and stronger rapport.

---

## Theming / Formatting

- **Format:** Structured markdown with a quick-stats box at the top. Use .docx when tools are available for easier printing and handoff; otherwise use markdown.
- **Visual priority:** What Works and Watch Areas should be visually easy to find — they are the most-read sections. Use clear section dividers (━━) to make scanning fast.
- **Tone:** Neutral, professional, and respectful. No clinical or deficit-focused language. Even in Watch Areas, frame positively: "Needs untimed practice first" not "Can't handle timed work."
- **Language:** Short, direct, scannable. Write for a tutor who has 90 seconds before a session starts.
- **Privacy:** Store profiles securely. Treat them as confidential student records. The Watch Areas section in particular should never leave the tutoring organization's internal systems.
- **Naming convention:** `[StudentLastName]_[FirstInitial]_Profile_[YYYY-MM-DD].md` for markdown, `.docx` for Word documents. On update, overwrite the existing file with the new date in the filename.
