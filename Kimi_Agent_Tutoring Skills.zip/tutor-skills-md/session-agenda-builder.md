---
name: session-agenda-builder
description: Build a focused, time-boxed agenda for an upcoming tutoring session. Trigger before every session to create a shareable plan, when a student asks "what should we work on today?", or when planning a week's worth of sessions. Takes student context (previous session notes, homework status, upcoming deadlines, struggle areas, and communications) and produces a structured, student-facing session plan with time blocks, objectives, materials, and backup activities.
---

# Session Agenda Builder

Produce a clear, student-facing session agenda before every tutoring session. The agenda serves as a roadmap shared with the student at the start of the session, setting expectations, allocating time, and ensuring nothing important is missed. Two modes: **Quick Build** (auto-generated from previous session notes, ~30 seconds) and **Full Build** (tutor reviews materials and customizes, ~3-5 minutes).

## Workflow Overview

1. **Gather context** — Collect inputs about the student's current state and upcoming demands.
2. **Select mode and duration** — Choose Quick Build or Full Build; pick the session length template.
3. **Draft the agenda** — Populate the time-blocked plan with segments, objectives, materials, and backups.
4. **Finalize and share** — Render the agenda in clean, student-friendly format for on-screen or chat delivery.

## Step 1 — Gather Context

Collect the following inputs. Ask the tutor directly if any are missing.

**Required (Quick Build minimum):**
- Previous session notes or summary (what was covered, what was assigned)
- Homework status since last session (completed, partial, not done, stuck on what)

**Required (Full Build only):**
- Upcoming deadlines/tests in the next 1-2 weeks with dates
- Current struggle areas or topics the student/parent flagged
- Time since last session (today, a few days, a week+)
- Any parent or teacher communications since last session
- Textbook chapter, worksheet, or assignment the student is currently working on in class
- Student's goal for the session (if expressed)

**Prompt template for the tutor:**
> Ready to build the session agenda. I have [X/Y] inputs. Here's what I know:
> - Last session: [date] — covered [topic], assigned [homework]
> - Homework status: [status]
> - Upcoming: [test/deadline info, or "none noted"]
> - Struggles flagged: [topics, or "none noted"]
> - Mode: [Quick Build / Full Build]
> - Duration: [30 / 45 / 60] minutes
>
> Please add, correct, or confirm any details.

## Step 2 — Select Mode and Duration

**Quick Build mode:**
- Trigger: Tutor has less than 1 minute of prep time; student is waiting; back-to-back sessions.
- Auto-generate the agenda using only previous session notes and homework status.
- Apply defaults: assume standard 5-segment structure, estimate time blocks proportionally, infer objectives from whatever was "not completed" or "needs practice" from the last session.
- Skip asking for additional inputs unless a critical gap is detected (e.g., upcoming test tomorrow that was not mentioned).

**Full Build mode:**
- Trigger: Tutor has prep time before the session; planning a week's worth of sessions; student has a major test/assignment approaching.
- Tutor provides or confirms all inputs from Step 1.
- Agenda is customized: time blocks adjusted to student needs, specific worksheets or problems selected, objectives tied to upcoming assessments.

**Duration templates:**

| Duration | Use Case | Total Time Blocks |
|----------|----------|-------------------|
| 30 min | Elementary check-ins, quick review, younger students | 4 segments |
| 45 min | Standard session, middle/high school, single topic | 5 segments |
| 60 min | Deep-dive, multi-topic, test prep, older students | 5-6 segments |

## Step 3 — Draft the Agenda

Use the standard 5-segment structure below. Adjust time allocations to fit the selected duration template. Every agenda must include the following fields per segment: **Objective** (1 sentence, "Student will be able to..."), **Activity description** (student-facing language), **Time**, and **Materials needed**.

### Standard 5-Segment Structure

| # | Segment | Purpose | Time (30m) | Time (45m) | Time (60m) |
|---|---------|---------|------------|------------|------------|
| 1 | **Warm-up / Check-in** | Build rapport, assess mood/energy, quick recall of last session | 3 min | 5 min | 5 min |
| 2 | **Review homework / Previous material** | Check assigned work, reteach if stuck, close gaps from last time | 8 min | 12 min | 15 min |
| 3 | **New content / Concept work** | Teach the new topic, model worked examples, build understanding | 10 min | 15 min | 20 min |
| 4 | **Guided practice** | Student works problems with tutor support; identify remaining gaps | 7 min | 10 min | 15 min |
| 5 | **Wrap-up / Homework assignment** | Summarize what was learned, assign 2-4 specific next steps, confirm next session | 2 min | 3 min | 5 min |

**For 60-minute sessions only**, you may split Segment 3 into:
- 3a. New content / Concept work (12 min)
- 3b. Additional practice or second concept (8 min)

### Writing objectives
Each segment (except Warm-up and Wrap-up) must have a learning objective written as:
> **Objective:** Student will be able to [specific, observable action] by [method/context].

Examples:
- "Student will be able to solve two-step linear equations with integer coefficients by applying inverse operations in the correct order."
- "Student will be able to identify the main idea of a short nonfiction passage by using the first-and-last-sentence strategy."
- "Student will be able to explain the difference between mitosis and meiosis using a self-created comparison chart."

### Materials needed
List per segment, not as a single block. Include: worksheet name/page, textbook section, online resource link, whiteboard, calculator, printed handout, etc.

### Backup activities
Add 1-2 backup activities at the bottom of the agenda. These fire if any segment finishes faster than expected.
- Format: **Backup 1 (5 min):** [Activity name] — [one-line description]. Trigger: if [segment] finishes early.
- Choose backups that are lightweight, require no extra materials, and reinforce the session's main topic.
- Examples: "Quick-fire 5 review questions on the whiteboard"; "Student explains the concept back to me in their own words"; "Timed challenge: 3 problems, 4 minutes"; "Vocabulary rapid-review matching game".

## Step 4 — Finalize and Share

Render the agenda in a clean, consistent format. The output must be student-facing — the student can read it when shared at session start.

### Output format

Use the following template. Replace bracketed placeholders with session-specific content.

```
## Today's Session Plan — [Date] | [Subject] with [Tutor Name]
**Duration:** [X] minutes | **Goal:** [One-line summary of what the student will achieve today]

---

### 1. Warm-up / Check-in ([X] min)
**Activity:** [Brief student-facing description]

### 2. Review: [Topic] ([X] min)
**Objective:** Student will be able to [objective].
**Activity:** [Brief student-facing description]
**Materials:** [List]

### 3. New: [Topic] ([X] min)
**Objective:** Student will be able to [objective].
**Activity:** [Brief student-facing description]
**Materials:** [List]

### 4. Practice: [Topic] ([X] min)
**Objective:** Student will be able to [objective].
**Activity:** [Brief student-facing description]
**Materials:** [List]

### 5. Wrap-up & Homework ([X] min)
**Activity:** Quick recap of today's wins + assign next steps.
**Homework:** [2-4 specific items, each with estimated time]

---

### Backup Activities
- **Backup 1 ([X] min):** [Activity] — if we finish [segment] early.
- **Backup 2 ([X] min):** [Activity] — if we finish [segment] early.

---

**Notes for tutor:** [Any private reminders: parent communication needed, materials to print, follow-up items]
```

### Sharing methods
- **Chat/text:** Paste the rendered agenda into the session chat at the start.
- **On-screen (virtual whiteboard/shared doc):** Display the agenda for the first 60 seconds of the session, then minimize.
- **Weekly planning:** Produce 2-4 agendas at once for the week ahead when the tutor requests multi-session planning. Label each with the session date and sequence (e.g., "Session 1 of 3 this week").

## Key Principles

- **Student-facing language:** Every segment description must be readable by the student. No tutor jargon, no internal codes. Write as if the student is reading it to know what will happen.
- **One primary objective per session:** The agenda should have a clear, single focus. Do not try to cover more than one major new concept per session unless in a 60-minute deep-dive with explicit justification.
- **Time is a commitment:** Every minute is allocated. If a segment runs over, the tutor must consciously decide what to cut — never silently steal time from Wrap-up or Review.
- **Homework status drives the plan:** If homework is incomplete or the student was stuck, reallocate time from New Content to Review. Never proceed to new material if the foundation is shaky.
- **Backup activities are mandatory:** Every agenda must include 1-2 backups. An agenda without backups is incomplete.
- **Wrap-up is non-negotiable:** The last segment always includes a summary and specific homework assignment. Never end a session without this.
- **Quick Build must still be complete:** Even in Quick Build mode, all 5 segments, objectives, materials, and backups must appear. The difference is in input depth, not output completeness.
- **Label the mode on the agenda:** Mark "Quick Build" or "Full Build" in the tutor notes section so the tutor knows how much customization was applied.

## Quick Reference: Agenda at a Glance

| Field | Required? | Source |
|-------|-----------|--------|
| Session date, subject, tutor name | Yes | Auto / Tutor input |
| Duration (30/45/60) | Yes | Tutor selects |
| 5 segments with time blocks | Yes | Template + customization |
| Learning objectives (SWBAT) | Yes | Derived from content |
| Activity descriptions | Yes | Student-facing language |
| Materials list per segment | Yes | Tutor input / context |
| Homework assignment (2-4 items) | Yes | Based on session content |
| Backup activities (1-2) | Yes | Auto-generated / tutor picks |
| Private tutor notes | Optional | Tutor input |
| Mode label (Quick/Full) | Yes | Auto-applied |
