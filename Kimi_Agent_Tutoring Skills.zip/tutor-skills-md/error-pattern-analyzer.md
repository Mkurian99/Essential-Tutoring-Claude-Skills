---
name: error-pattern-analyzer
description: Diagnose systematic mistake patterns from a student's wrong answers on tests, homework, or practice problems. Categorizes errors by type and root cause so the tutor can design targeted remediation instead of re-teaching everything. Trigger when a student gets multiple problems wrong, keeps making "the same kind of mistake," is preparing for a retake, or when a tutor suspects a foundational gap. Also use for proactive pre-test diagnostics. Accepts input from photos of graded work, lists of missed problem numbers, pasted solutions, or conversationally described errors. Completes in 3-5 minutes of interaction.
---

# Error Pattern Analyzer

Turn a pile of wrong answers into a focused, prioritized remediation plan. The goal is not to count errors but to find the *patterns* behind them — a student who missed 10 questions may have only 2-3 underlying error patterns. Fixing those patterns fixes multiple errors at once.

The skill clusters errors by type, assesses confidence in each pattern, ranks them by impact, and produces a tutor-facing diagnostic report that can be shared with the student in simplified form. Every output includes a concrete next step — never just a label.

## Workflow Overview

1. **Collect errors** — Gather wrong answers from any input format; normalize into a workable list.
2. **Classify and cluster** — Map each error to the taxonomy, then group repeated errors into patterns.
3. **Diagnose each pattern** — Build a full profile for every identified pattern with root cause and remediation.
4. **Prioritize and output** — Rank by impact, render the final action plan.

---

## Step 1 — Collect Errors

Gather every wrong answer from the student. Work with whatever the tutor provides — do not require a specific format.

### Accepted input formats

| Format | How to Handle | Example |
|--------|--------------|---------|
| **Photo of graded work** | Ask the tutor to describe the problems missed and any visible work shown. Note both the problem type and the specific mistake. | "Problems 3, 7, 12 wrong on Chapter 5 test. On #7, student wrote (x+2)(x-3)=x²-6, dropping the middle term." |
| **List of missed problem numbers** | Ask the tutor to describe the problem type and the student's wrong answer for each. | "#4 (solving quadratic), #5 (factoring), #8 (solving quadratic), #11 (factoring)" |
| **Pasted student work** | Read each wrong answer. Note the problem statement (or type) and what the student wrote. | Student's handwritten steps shown in chat |
| **Conversational description** | Ask clarifying questions until you can identify at least the problem type and the nature of the error per problem. | "They keep messing up the signs when factoring" |
| **Combination** | Handle mixed inputs the same way — normalize into a simple list. | Photo + tutor notes |

### Minimum viable input

To run the analysis, you need at least:
- **3+ wrong answers** from the same assessment or topic area. (With fewer than 3, note that patterns will be Low confidence and avoid strong conclusions.)
- **Subject/topic** the errors came from (e.g., "Algebra II — quadratics unit test")

### Prompt template if input is incomplete

> I can analyze the error patterns from this [test/homework/assignment]. Here's what I need:
>
> **Subject/topic:** [e.g., Algebra I — linear equations]
> **Wrong answers:** [Problem numbers + what the student wrote or the type of mistake]
>
> For each problem the student got wrong, tell me:
> - Problem number and type (e.g., "#5 — solving two-step equation")
> - What the student wrote (if visible) or what the tutor observed
>
> Even rough descriptions work — I'll do the pattern matching.

### Normalized working list

Convert all input into an internal working list. Format each entry as:

```
- Problem [number]: [problem type] — Student wrote: [wrong answer/work] — Correct answer: [answer]
```

Example:
```
- Problem 3: Solving quadratic by factoring — Student wrote: x = 3 only (missed x = -2) — Correct: x = 3, x = -2
- Problem 7: Factoring trinomial — Student wrote: (x+2)(x-3) = x² - x - 6 — Correct: (x+3)(x-2)
- Problem 12: Solving quadratic by factoring — Student wrote: x = 4 only (missed x = 0) — Correct: x = 4, x = 0
```

---

## Step 2 — Classify and Cluster

### Classify each error into the taxonomy

For each wrong answer on the working list, assign exactly one error type. Use the definitions and examples below to decide.

| Type | Definition | Diagnostic Question | Example |
|------|-----------|---------------------|---------|
| **Conceptual** | Doesn't understand the underlying concept or applies a rule incorrectly | "Would the student get this wrong even if they took their time and checked their work?" | Thinks multiplication distributes over exponents: 2³ × 2⁴ = 2¹² |
| **Procedural** | Knows the concept but executes steps out of order, skips a step, or applies a correct algorithm incorrectly | "Does the student start correctly but lose it in the middle of the process?" | Knows to FOIL but forgets the Inner term: (a+b)(c+d) = ac + bc + ad |
| **Careless / Attentional** | Simple slip — sign error, arithmetic mistake, misreading the question, copying a number wrong | "Is this a one-off slip that doesn't reflect a knowledge gap?" | Writes -3 instead of +3; calculates 6×7=48; misreads "solve for y" as "solve for x" |
| **Foundational Gap** | Missing prerequisite knowledge that the current topic depends on | "Is the student stuck because something from an earlier unit never stuck?" | Can't solve quadratics because they never mastered factoring; can't work with fractions |
| **Test-Taking / Strategy** | Error driven by time pressure, skipping steps, not checking work, anxiety, or poor problem-selection | "Would this error disappear in a low-pressure, untimed setting?" | Runs out of time and leaves 4 problems blank; skips checking and misses 3 sign errors under pressure |

### Classification rules

- Assign exactly **one type per error**. If an error could fit two types, pick the **deepest** one (the one closer to the root cause). Foundational Gap beats Procedural; Conceptual beats Careless.
- When unsure, flag the entry as **"? — needs more info"** and move on. Do not force a classification.
- An error is **Careless** only if it looks like a one-off slip. If the same "careless" mistake appears 3+ times, reclassify it — it's likely Procedural or Foundational.

### Cluster into patterns

After classifying, group errors that share the **same underlying cause**. A pattern is not "missed 3 factoring problems" — it's "misses the middle term when factoring trinomials because they skip the systematic check step."

**Pattern clustering criteria:** Two errors belong to the same pattern if they share:
- The same error type AND
- The same mathematical/substantive mistake mechanism AND
- The same apparent root cause

**Examples of valid clusters:**

| Invalid Pattern (too vague) | Valid Pattern (specific, actionable) |
|----------------------------|--------------------------------------|
| "Got 3 factoring problems wrong" | "Procedural: Skips finding the middle-term pair when factoring trinomials with a=1 — always guesses the first factor pair that multiplies to c" |
| "Makes sign errors" | "Careless: Drops negative signs when distributing across parentheses — 3 instances, always in problems with negative coefficients" |
| "Doesn't understand quadratics" | "Foundational Gap: Cannot identify when an equation is quadratic vs. linear — treats x² terms as regular variables and tries to isolate them" |

### Pattern confidence

For each identified pattern, assign a confidence level:

| Confidence | Criteria | Action |
|-----------|----------|--------|
| **High** | 3+ examples of the same error pattern in the student's work | Treat as confirmed. Recommend specific remediation. |
| **Medium** | 2 examples of the same pattern, OR strong theoretical reason to suspect it | Flag as likely. Recommend remediation but note uncertainty. |
| **Low** | 1 example, but suspicious (e.g., aligns with a known common misconception) | Note as "watch" — do not build a remediation plan around it. Mention it in the output as an area to monitor. |

**Never over-diagnose from a single instance.** A Low-confidence pattern gets one line in the report, not a full remediation section.

---

## Step 3 — Diagnose Each Pattern

For every Medium- and High-confidence pattern, build a full diagnostic profile.

### Required fields per pattern

| Field | Description | Example |
|-------|-------------|---------|
| **Pattern ID** | Sequential number (P1, P2, P3...) | P1 |
| **Error Type** | One of the 5 taxonomy types | Procedural |
| **Description** | One sentence: what the student does wrong, in plain language | "Skips the middle term when applying FOIL to binomial multiplication" |
| **Frequency** | How many times this pattern appeared in the work analyzed | 3 of 8 errors |
| **Examples** | 1-2 specific instances from the student's actual work | "Problem 7: (x+2)(x-3) → x² - 6 (no middle term). Problem 15: (2a+1)(a-4) → 2a² - 4 (no middle term)." |
| **Root Cause Hypothesis** | 1-2 sentences explaining *why* this is happening | "Student has memorized the 'multiply first and last' part of FOIL but has not internalized that the Inner and Outer terms must also be combined. They may be rushing or relying on a partial memory of the procedure." |
| **Recommended Remediation** | Specific, actionable intervention — not "practice more" | "1) Whiteboard walkthrough: Student verbalizes each FOIL step aloud for 5 problems. 2) Color-code method: Have student highlight First, Outer, Inner, Last terms in different colors before combining. 3) Drill: 10 FOIL problems with immediate check — stop and correct after each one, not at the end." |
| **Priority** | Fix First / Address Soon / Monitor | Fix First |

### Priority guidelines

| Priority | Criteria | Typical Timeline |
|----------|----------|-----------------|
| **Fix First** | High-confidence pattern that is blocking current and upcoming material; appears on 30%+ of errors; foundational to the current unit | Address in the next 1-2 sessions |
| **Address Soon** | Medium-confidence pattern; important but not blocking; or secondary pattern that compounds with Fix First items | Address within 1-2 weeks |
| **Monitor** | Low-confidence pattern; Careless errors that might improve once Fix First patterns are resolved; or patterns that may disappear with better strategy | Watch in upcoming work, revisit if they recur |

### Remediation specificity rules

Every remediation recommendation must include:
- **What** the tutor will do (activity, method, or material)
- **How many** problems or how much time
- **How** the tutor will verify it's working (check, assessment, or observation)

**Bad:** "Practice factoring more."
**Good:** "Complete 8 structured factoring problems using the factor-pair list method. Tutor checks after each problem before student proceeds. Target: 7/8 correct before moving on."

### Cross-check: patterns vs. raw errors

Before proceeding, verify: **The number of patterns should be significantly smaller than the number of errors.**

| Raw Errors | Expected Pattern Count | Red Flag |
|-----------|----------------------|----------|
| 3-4 errors | 1-2 patterns | More patterns than errors = over-clustering |
| 5-8 errors | 2-3 patterns | |
| 9-15 errors | 3-5 patterns | |
| 15+ errors | 4-6 patterns, or suggest a broader assessment | More than 6 patterns suggests the student may need comprehensive review, not targeted remediation |

If you have more patterns than errors, re-cluster more broadly.

---

## Step 4 — Prioritize and Output

### Ranking order

Sort patterns by this tiebreaker sequence:
1. **Priority level** (Fix First > Address Soon > Monitor)
2. **Confidence** (High > Medium > Low)
3. **Frequency** (most occurrences first)

### Output format

Render the final report in this exact structure. The output is **tutor-facing** but written so it can be shared with the student (or summarized for them) without rewording.

```
# Error Pattern Analysis — [Student Name] | [Subject/Topic]
**Source:** [Test name / Homework assignment / Date]
**Total errors analyzed:** [N]
**Distinct patterns found:** [N] (High: [N], Medium: [N], Low: [N])
**Analyzed on:** [Date]

---

## Summary at a Glance

| Priority | Pattern | Type | Confidence | Frequency |
|----------|---------|------|------------|-----------|
| Fix First | [Short description] | [Type] | High/Medium/Low | [N] of [total] errors |
| Address Soon | [Short description] | [Type] | High/Medium/Low | [N] of [total] errors |
| Monitor | [Short description] | [Type] | High/Medium/Low | [N] of [total] errors |

---

## P1: [Pattern Name] — [Priority]
**Error Type:** [Conceptual / Procedural / Careless / Foundational Gap / Test-Taking]
**Confidence:** [High / Medium / Low] | **Frequency:** [N] of [total] errors

**Description:** [One sentence — what the student does wrong]

**Examples from student's work:**
- [Problem description and what student wrote]
- [Problem description and what student wrote]

**Root cause hypothesis:** [1-2 sentences — why this is happening]

**Recommended remediation:**
1. [Specific action — what, how many, how verified]
2. [Specific action — what, how many, how verified]
3. [Specific action — what, how many, how verified]

**What to tell the student (simplified):** [2-3 sentences in student-friendly language explaining what was noticed and what you'll work on together]

---

## P2: [Pattern Name] — [Priority]
[Same structure as P1]

---

## P3: [Pattern Name] — [Priority]
[Same structure as P1]

---

## Low-Confidence Observations (Watches)

- **[Pattern description]** — 1 instance; [Type]. May resolve when [related Fix First pattern] is addressed. Recheck in next assignment.
- **[Pattern description]** — 1 instance; [Type]. Monitor for recurrence.

---

## Suggested Session Plan

Based on the patterns above, here's a recommended focus for upcoming sessions:

| Session | Focus | Materials | Success Metric |
|---------|-------|-----------|----------------|
| Next session | [Pattern to address — specific skill/concept] | [What the tutor should prepare] | [Observable, measurable check] |
| Following session | [Next pattern or reinforcement] | [Materials] | [Success metric] |
| Ongoing | [Monitoring or maintenance task] | [Materials] | [Success metric] |

---

## Notes for Tutor

- [Any private reminders: e.g., "P1 and P2 are related — fixing P1 (FOIL structure) will likely reduce P2 (sign errors in binomial multiplication)"]
- ["Student's Careless errors may be downstream of Procedural gaps — don't treat as separate issues until P1 is resolved"]
- [Any follow-up needed: "Reassess with a 5-problem mini-quiz on [topic] after P1 remediation to verify pattern is closed"]
```

### Delivery format

| Situation | Format | Notes |
|-----------|--------|-------|
| Tutor is reviewing alone | Full report as markdown | Tutor reads and plans sessions |
| Sharing with student | Copy only the "What to tell the student" sections + Summary at a Glance | Simplify further if needed |
| Sharing with parent | Summary at a Glance + simplified pattern descriptions + Suggested Session Plan | Frame positively: "Here's what we're focusing on" |
| Pre-retake planning | Full report + Suggested Session Plan with retake date as deadline | Compress timeline, focus on Fix First only |

---

## Key Principles

- **Patterns over counts.** A student with 10 errors and 2 patterns needs targeted remediation, not 10 corrections. Never list errors individually without clustering.
- **Confidence discipline.** High confidence requires 3+ examples. Medium requires 2. Never build a remediation plan around a Low-confidence pattern.
- **Root cause, not symptom.** "Sign errors" is a symptom. "Rushes through distribution and doesn't verify sign of each product" is a root cause. Every diagnosis must explain *why*.
- **Actionable remediation.** Every recommendation must say what to do, for how long, and how to verify it works. "Practice more" is never acceptable.
- **Student-friendly translation.** Every pattern includes a "What to tell the student" section. The student deserves to understand their own learning, not just receive a label.
- **Careless is a last resort.** Only classify as Careless/Attentional when the error truly looks like a one-off slip. If the same "careless" mistake repeats, it's Procedural or Foundational.
- **Deepest type wins.** When an error could fit multiple types, pick the one closest to the root cause. A sign error from not understanding negative number rules is Foundational, not Careless.
- **Patterns are interconnected.** Note when fixing one pattern will likely resolve another. Don't build redundant remediation plans.
- **Reassess after remediation.** Every Fix First pattern should have a verification plan — a mini-quiz, a set of problems, or an observation checkpoint to confirm the pattern is closed.
- **Never diagnose from one error.** A single wrong answer is data; three of the same kind is a pattern. Keep the distinction clear.

---

## Theming / Formatting

- **Report format:** Clean markdown with `---` dividers between patterns. Designed for readability and quick scanning.
- **Priority colors (if rendering to HTML/rich text):** Fix First = red/urgent, Address Soon = yellow/medium, Monitor = gray/low.
- **Tables:** Summary at a Glance is always a table — it gives the tutor (and parent) the full picture in one glance.
- **No jargon in student-facing sections.** The "What to tell the student" sections must avoid terms like "procedural deficit" or "foundational gap." Use language like "I noticed you start problems strong and then the middle steps get tricky — we're going to build a checklist for those middle steps."
- **File naming:** Save as `[StudentName]_ErrorAnalysis_[Topic]_[Date].md` when retaining for records.
