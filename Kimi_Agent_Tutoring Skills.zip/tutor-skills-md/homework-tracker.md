---
name: homework-tracker
description: >
  Maintain a running log of homework assignments, track due dates and completion
  status, and use homework compliance as a diagnostic signal for student
  engagement and executive functioning. Trigger at the end of every session when
  homework is assigned, during sessions to check homework status, when a student
  is consistently missing assignments, or when a parent asks what homework has
  been assigned. Produces a living markdown table updated every session — not
  recreated. Completes in 2–4 minutes of interaction.
---

# Homework Tracker

Keep a single, continuously updated record of every homework assignment a
student receives. The tracker serves two purposes: it keeps the tutor and
student aligned on what is due when, and it generates actionable data about the
student's follow-through, time management, and barriers.

This is a **living document**. Each session, the tutor carries the existing
tracker forward — adding new assignments, updating statuses, and recording
notes. The tracker feeds directly into the **session-notes-writer** skill's
"Homework Assigned" and "Student Performance" fields.

Two operating modes:

1. **Log Entry** — Record new assignments at session end.
2. **Status Review** — Check in on existing assignments during a session.

At the start of every session, a **Homework Preview** quickly surfaces what is
due in the next 7 days.

## Workflow Overview

1. **Determine mode** — Log Entry (new assignments), Status Review (check-in),
   or Homework Preview (start-of-session scan).
2. **Collect and update** — Gather assignment details or current status; update
   the running table.
3. **Run hygiene checks** — For every "Missing" assignment, categorize the why.
   Flag patterns.
4. **Deliver updated tracker** — Output the complete, sorted table plus a brief
   summary. Feed homework data into session notes.

## Step 1 — Determine Mode

| Mode | Trigger | First Question |
|------|---------|----------------|
| **Log Entry** | End of session; new homework just assigned | "What homework did you assign today?" |
| **Status Review** | Mid-session check-in; student is consistently missing work; parent asks about assignments | "Let's check your homework tracker. Where do things stand?" |
| **Homework Preview** | Start of session | "Here's what's due in the next 7 days — anything we need to prioritize?" |

- If **Log Entry**: Proceed to Step 2a.
- If **Status Review**: Proceed to Step 2b.
- If **Homework Preview**: Scan the existing tracker for assignments with due
dates within the next 7 days. Read them aloud. Flag any "Not Started" or late
items. Then ask the student: "What would you like to tackle first?" No
full-table update needed — just a quick scan.

## Step 2a — Log Entry

Record each new assignment as a row in the tracker table.

### Required fields per assignment

| Field | Description | Example |
|-------|-------------|---------|
| **Assignment** | Short, specific name | "p. 142 #1–15 odd — solving inequalities" |
| **Subject** | The subject area | Algebra I |
| **Date Assigned** | Session date | 2025-06-22 |
| **Due Date** | When it is due (be specific) | 2025-06-29 |
| **Est. Time** | Student-facing time estimate | 30 min |
| **Resources** | What the student needs to complete it | Textbook p. 142, calculator, printed notes |
| **Priority** | Core / Supplementary / Optional | Core |

### Priority definitions

| Level | Definition | Example |
|-------|-----------|---------|
| **Core** | Essential for mastering current material; must be completed before next session | Practice problems on the skill just taught |
| **Supplementary** | Reinforcement or extension; valuable but not blocking | Extra credit worksheet, review packet |
| **Optional** | Enrichment; student can skip without falling behind | Challenge problems, reading extension |

### Conversation script for Log Entry

1. For each assignment, state it back to the student: *"Your Core homework is
   page 142, problems 1 through 15 odd, on solving inequalities. It's due June
   29th. I estimate 30 minutes. You'll need your textbook, calculator, and the
   notes we printed today. Sound right?"*
2. Confirm the due date and time estimate with the student. Adjust if needed.
3. Add the row to the tracker table.
4. Ask: *"Anything else you need from me to get this done?"*
5. Repeat for every assignment.

### Log entry example

```
New entries added 2025-06-22:

| Due Date   | Subject   | Assignment                        | Status      | Est. Time | Notes                           |
|------------|-----------|-----------------------------------|-------------|-----------|---------------------------------|
| 2025-06-29 | Algebra I | p. 142 #1–15 odd — inequalities   | Not Started | 30 min    | Core. Needs textbook + notes.   |
| 2025-06-29 | English   | Read Ch. 3–4, annotate for theme  | Not Started | 25 min    | Core. Use sticky-note method.   |
```

## Step 2b — Status Review

Walk through the existing tracker with the student, row by row, starting with
the most urgent due dates. Update the Status field and add notes.

### Status options

| Status | Definition | Tutor Action |
|--------|-----------|--------------|
| **Not Started** | Student has not begun the assignment | Ask: "What's the first step? When do you plan to start?" |
| **In Progress** | Student has started but not finished | Ask: "How far did you get? Where are you stuck?" |
| **Completed** | Student believes they finished it | **Always ask to see the completed work.** Do not accept verbal confirmation alone. |
| **Missing** | Assignment was not completed by the due date | Proceed immediately to the hygiene check (Step 3). |
| **Excused** | Assignment deadline extended or waived by tutor; note the reason | Record the reason and the new due date if applicable. |

### Status review conversation script

For each assignment being reviewed:

> **Tutor:** "Your Algebra worksheet was due the 29th. Where does it stand?"
>
> **Student:** "I finished it."
>
> **Tutor:** "Great — can you pull it up so I can take a look?"
> *(Student shares screen / holds up paper / describes work)*
>
> **Tutor:** *(skims the work)* "I see you got through problem 8. Problems 9
> and 10 look like they tripped you up on the negative signs. Let's mark this
> In Progress and finish it now."

**Rules for marking Completed:**

- Completed status requires **evidence**. The tutor must see the work — on
  screen, in a photo, or described in enough detail to confirm understanding.
- If the student says they finished it but cannot show it (forgot it at school,
  lost the file), mark as **In Progress** with a note: *"Student claims
  completion; could not verify. Re-check next session."*
- Spot-check at least one problem from each Completed assignment. Ask the
  student to explain their work on that problem.

## Step 3 — Assignment Hygiene Check & Pattern Flags

Every time an assignment is marked **Missing**, run the hygiene check. Also scan
the full tracker for pattern flags after every Status Review.

### Hygiene check for Missing assignments

For each Missing assignment, ask the student: *"What happened with this one?"*
Then categorize the reason:

| Category | Prompt Question | What to Record |
|----------|----------------|----------------|
| **Forgot** | "Did you forget this was due?" | Note: *"Forgot — no entry in planner / planner not checked"* |
| **Didn't understand** | "Did you get stuck and not know how to move forward?" | Note: *"Didn't understand [specific concept]. Needs re-teach."* |
| **Ran out of time** | "Did you plan to do it but run out of time?" | Note: *"Ran out of time — estimated X min, student reports not enough time."* |
| **Chose not to** | "Did you decide not to do it?" | Note: *"Chose not to — [student's reason if offered]."* Probe for motivation or overwhelm. |
| **Other** | "Something else going on?" | Note the student's explanation verbatim. |

**After categorizing, take action:**

| Category | Tutor Response |
|----------|----------------|
| **Forgot** | Reinforce planner/calendar habit. Suggest a specific reminder (phone alarm, sticky note). Assign a micro-deadline: *"Start 2 problems the night it's assigned."* |
| **Didn't understand** | Flag for re-teaching in the next session. Adjust priority of that topic upward. |
| **Ran out of time** | Re-evaluate the time estimate with the student. Break the assignment into smaller chunks. Consider reducing the assignment scope. |
| **Chose not to** | Explore why without being accusatory. Is the student overwhelmed? Is the assignment too big? Do they not see the value? Adjust priority or scope accordingly. |
| **Other** | Record details. Follow up as needed. |

### Pattern flags

After every Status Review, scan the tracker for these patterns:

**Flag A — Consecutive missing assignments**
- **Trigger:** 2+ Missing assignments in a row (regardless of subject).
- **Action:** Initiate a conversation about barriers. Ask: *"I'm noticing the
  last two assignments weren't completed. What's getting in the way? Is it
  time, understanding, or something else?"* Record the student's response in
  the tracker Notes field.

**Flag B — Subject-specific struggle**
- **Trigger:** 3+ Missing assignments in the same subject.
- **Action:** This signals a subject-specific struggle, not just executive
  functioning. Escalate: prioritize that subject in upcoming sessions. Note to
  tutor: *"3+ missing in [Subject] — consider whether the student lacks
  foundational skills or is avoiding the subject due to anxiety."*

**Flag C — Chronic "Forgot" pattern**
- **Trigger:** 3+ "Forgot" categorizations across any subjects.
- **Action:** The student needs planner/calendar skill-building. Dedicate 5
  minutes of the next session to setting up a reminder system. Consider
  involving the parent.

**Flag D — Chronic "Ran out of time"**
- **Trigger:** 3+ "Ran out of time" categorizations.
- **Action:** The student is over-scheduled or under-estimating how long work
  takes. Run a time-estimation exercise: for the next week's assignments, have
  the student predict time, then record actual time. Review together.

## Step 4 — Deliver Updated Tracker

Output the complete, up-to-date tracker table. Sort rows by **Due Date**
(ascending), then by **Priority** (Core > Supplementary > Optional).

### Output template

```
# Homework Tracker — [Student Name]
**Last updated:** [Date]
**Current session:** [Date, Start–End Time]

| Due Date   | Subject   | Assignment                        | Status      | Est. Time | Notes                              |
|------------|-----------|-----------------------------------|-------------|-----------|------------------------------------|
| 2025-06-24 | Algebra I | Quiz review packet (20 problems)  | In Progress | 40 min    | Core. Missing #11–15 — negative signs. |
| 2025-06-25 | English   | Ch. 3–4 theme annotation          | Completed   | 25 min    | Core. Verified — strong annotations. |
| 2025-06-29 | Algebra I | p. 142 #1–15 odd — inequalities   | Missing     | 30 min    | Core. Hygiene: Forgot. No planner entry. Reminder set. |
| 2025-07-02 | English   | Essay outline — persuasive        | Not Started | 45 min    | Supplementary. Graphic organizer provided. |
| 2025-07-05 | Algebra I | Extra credit: word problems set B | Not Started | 20 min    | Optional. Student interested — due before unit test. |
```

### Summary block (append after the table)

```
## Session Summary — [Date]

**Assignments reviewed this session:** [N]
**New assignments added:** [N]
**Status changes:** [N] (list: X → Completed, Y → Missing, etc.)

**Active flags:**
- [Flag letter + description, e.g., "Flag A — 2 consecutive missing assignments"]
- [Any other flags]

**Actions for next session:**
- [Action 1]
- [Action 2]
```

### Feeding into session notes

After updating the tracker, pass the following data to the **session-notes-writer** skill:

| Session-Notes Field | What to Pass |
|---------------------|-------------|
| **Homework Assigned** | List all new assignments added in this session (from Step 2a), with due dates and priorities. |
| **Student Performance** | Summary of hygiene-check findings and any active flags. Example: *"2 assignments marked Missing this week — both categorized as 'Forgot.' Flag A triggered; discussed planner reminders."* |

## Key Principles

- **The tracker is a living document.** Never recreate it from scratch each
  session. Carry the existing table forward, add rows, and update statuses.
- **Completed requires evidence.** Always ask to see the work. Verbal
  confirmation alone is not enough.
- **Every Missing assignment gets a hygiene check.** Categorize the why —
  Forgot / Didn't understand / Ran out of time / Chose not to / Other. This is
  executive functioning data.
- **Flags are conversation starters, not labels.** When a pattern flag triggers,
  use it to open a dialogue about barriers, not to reprimand the student.
- **Sort by urgency.** The table is always sorted by due date first, priority
  second. The student and tutor should be able to glance at the top and know
  what matters most right now.
- **Feed the session notes.** Homework data flows directly into the
  session-notes-writer skill. Keep the two documents aligned.
- **Time estimates are student-facing, not aspirational.** If a student
  consistently takes longer than the estimate, adjust future estimates upward
  rather than telling the student to work faster.
- **Parents get summaries, not raw hygiene data.** If a parent asks about
  homework, share the current tracker table plus a brief, non-judgmental
  summary. Save hygiene-check categories and flag details for tutor-internal
  notes.

## Theming / Formatting

- **Format:** Markdown table. Clean, scannable, sortable. If exporting to
  `.docx`, maintain the same column order and sorting rules.
- **Column order:** Due Date | Subject | Assignment | Status | Est. Time | Notes
- **Sort order:** Due Date (ascending), then Priority (Core > Supplementary >
  Optional).
- **Status indicators:** Use the exact status labels — Not Started, In Progress,
  Completed, Missing, Excused. Consistency matters for pattern detection.
- **File naming:** `[StudentName]_HomeworkTracker.md`. If using `.docx`:
  `[StudentName]_HomeworkTracker.docx`
- **Integration note:** The "Homework Assigned" and "Student Performance"
  fields in session-notes-writer are populated directly from this tracker. Keep
  the two skills in sync every session.
