---
name: session-notes-writer
description: >
  Write concise, structured post-session notes after every tutoring session.
  Produces two outputs — Quick Notes (internal tutor record) and Parent Summary
  (shareable progress update). Trigger after each session, when a student or
  parent requests a progress summary, or when handing off a student to a new
  tutor. Completes in 2–4 minutes of interaction.
---

# Session Notes Writer

Capture what happened, what the student learned, what still needs work, and
what's planned next. These notes are the primary record for tracking student
progress over time and keeping parents informed.

Two outputs are produced every time:

1. **Quick Notes** — A brief, structured internal record (under 150 words) for
tutor reference and trend tracking.
2. **Parent Summary** — A warm, parent-friendly message celebrating wins while
honestly noting growth areas, ready to share directly.

## Workflow Overview

1. Gather session data — focus, topics, performance metrics, engagement.
2. Draft Quick Notes — fill all required fields with objective, specific details.
3. Draft Parent Summary — reframe the same data into warm, shareable language.
4. Cross-check and finalize — verify specificity, trend references, and privacy.

## Step 1 — Gather Session Data

Collect the following from the tutor. Ask directly if any are missing.

**Required for every session:**

| Field | Example |
|---|---|
| Date / Time | 2025-06-22, 4:00–5:00 PM |
| Session Focus | Factoring quadratic expressions |
| Concepts Covered | GCF factoring, trinomial factoring (a=1), difference of squares |
| Quantitative Performance | 8/10 trinomials correct (up from 5/10 last session); GCF 5/5 correct |
| Engagement Level | High / Medium / Low — with one-sentence explanation |
| Homework Assigned | Practice worksheet (12 problems), due 2025-06-29 |
| Next Session Plan | Review homework + introduce factoring when a ≠ 1 |
| Materials Needed | Calculator, printed worksheet from shared folder |
| Flags (if any) | Arrived 10 min late; no previous flags |

**If this is not the first session, pull the previous session's Quick Notes and
reference at least one quantitative comparison** (e.g., "up from 5/10 last
session").

**Engagement scoring — be specific:**

- **High**: Student initiated questions, stayed focused entire session, asked
  for extra practice.
- **Medium**: Needed 2–3 refocusing prompts, completed all work but with
  prompting.
- **Low**: Required frequent redirection, avoided tasks, or expressed
  frustration repeatedly. Note what triggered the low engagement.

## Step 2 — Write Quick Notes

Produce a structured, scannable record. Target under 150 words.

**Template:**

```
**Date/Time:** [Date, Start–End Time]
**Session Focus:** [One-line topic]
**Concepts Covered:**
- [Concept 1]
- [Concept 2]
- [Concept 3]
**Student Performance:** [Specific metric with trend vs. previous session]
**Engagement:** [High/Medium/Low] — [One-sentence explanation]
**Homework Assigned:** [Description] — Due: [Date]
**Next Session Plan:** [One-line plan]
**Materials Needed:** [List]
**Flags:** [None, or brief factual note]
```

**Example:**

```
**Date/Time:** 2025-06-22, 4:00–5:00 PM
**Session Focus:** Factoring quadratic expressions
**Concepts Covered:**
- GCF factoring
- Trinomial factoring (a = 1)
- Difference of squares
**Student Performance:** Solved 8/10 trinomial factoring problems correctly,
up from 5/10 last session. GCF factoring 5/5 correct (mastered).
**Engagement:** High — asked for extra challenge problems after finishing
homework review.
**Homework Assigned:** Trinomial factoring worksheet (12 problems) — Due:
2025-06-29
**Next Session Plan:** Review homework + introduce factoring when a ≠ 1
**Materials Needed:** Calculator, printed worksheet from shared folder
**Flags:** None
```

**Rules for Quick Notes:**

- Use **quantified data only** — "solved 8/10" not "did well."
- Always **reference a previous session** metric when available.
- Keep flags **factual and neutral** — "arrived 10 min late" not "unreliable."
- One line per field. No paragraphs.

## Step 3 — Write Parent Summary

Reframe the same session data into a warm, parent-friendly message. This is
meant to be shared directly — no internal jargon.

**Template:**

```
Hi [Parent Name],

[Warm opening — one sentence celebrating the session overall.]

**Wins from today:**
- [Specific win 1 — with numbers if possible]
- [Specific win 2 — with numbers if possible]
- [Specific win 3 — brief, if applicable]

**Area we're growing:** [One honest growth area, framed positively — what we're
working toward and how]

**Homework reminder:** [What was assigned, when it's due, and what support they
might need]

**Next session:** [Date/time + one-line preview of what's coming]

[Open question for parent — prompt them to share observations from home]

Best,
[Tutor Name]
```

**Example:**

```
Hi Ms. Chen,

Alex had a strong session today — his confidence with factoring is really
building!

**Wins from today:**
- Solved 8 out of 10 trinomial factoring problems correctly, up from 5 last
  week — great improvement!
- Mastered GCF factoring (5/5 correct) and is now using it automatically as a
  first step.
- Asked for extra challenge problems at the end of the session.

**Area we're growing:** We're still working on checking answers by expanding
— Alex sometimes skips this step and misses small sign errors. We're practicing
it each session.

**Homework reminder:** A 12-problem trinomial factoring worksheet is due next
Sunday (6/29). Alex should try the first 3 problems while the session is still
fresh, then spread the rest across the week.

**Next session:** Sunday 6/29 at 4:00 PM — we'll review the homework and start
factoring when the leading coefficient isn't 1.

Have you noticed Alex applying any of these factoring strategies on his school
homework? I'd love to hear what you're seeing!

Best,
Jordan
```

**Rules for Parent Summary:**

- Always open with warmth. Parents should feel their child is seen and
  supported.
- Every win must include **specifics** — numbers, examples, or concrete
  behaviors.
- The growth area must be **honest but positively framed** — never alarming.
  Say "building toward" or "practicing," not "struggling with" or "failing at."
- Homework reminders include **due dates and a tip** for how parents can
  support.
- The open question should invite parent input without being burdensome.
- Never include flags about behavior, attendance, or engagement issues in the
  Parent Summary — address those privately.

## Step 4 — Cross-Check and Finalize

Before delivering, verify both outputs against this checklist:

**Quick Notes:**
- [ ] All 8 required fields are filled (Date/Time, Focus, Concepts, Performance,
  Engagement, Homework, Next Session, Materials, Flags).
- [ ] Performance includes at least one number (score, accuracy rate, time,
  attempt count).
- [ ] If session ≥2, a trend comparison to the previous session is present.
- [ ] Engagement level is one of High/Medium/Low with explanation.
- [ ] Flags are factual and neutral.
- [ ] Word count is under 150.

**Parent Summary:**
- [ ] Warm opening sets a positive tone.
- [ ] 2–3 wins listed, each with specific evidence.
- [ ] 1 growth area framed constructively (not critically).
- [ ] Homework includes description + due date.
- [ ] Next session includes date/time + preview.
- [ ] Open question for parent is present.
- [ ] No sensitive personal, behavioral, or attendance information included.
- [ ] Tone is professional, warm, and honest.

## Key Principles

- **Objective and specific.** "Solved 8/10 quadratic equations correctly, up
  from 5/10 last session" — not "did well." Every performance claim needs
  evidence.
- **Trend-aware.** Always look backward. Compare to the last session (or
  earlier baseline) to show trajectory.
- **Two audiences, one truth.** Quick Notes and Parent Summary describe the
  same session. Never sugarcoat in one and criticize in the other. The
  difference is tone and framing, not facts.
- **Engagement is observable.** Score High/Medium/Low based on concrete
  behaviors — focus, initiation, task completion, attitude — not gut feeling.
- **Privacy first.** Never include sensitive personal information, behavioral
  labels, or family details. Keep everything focused on academic performance
  and learning behaviors.
- **Flags are neutral and factual.** Record attendance and engagement data
  without interpretation. "Arrived 10 minutes late" — not "unmotivated."

## Theming / Formatting

- **Quick Notes**: Plain markdown with bold headers. Designed for speed and
  scanning. No decorative elements.
- **Parent Summary**: Clean paragraph + bullet format. Copy-paste ready for
  email, text, or tutoring platform messaging.
- Both outputs are produced from the same session data — draft Quick Notes
  first, then reframe into Parent Summary.
