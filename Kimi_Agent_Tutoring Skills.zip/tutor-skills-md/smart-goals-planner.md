---
name: smart-goals-planner
description: Guide students through goal-setting across five life domains using the SMART framework. Use whenever a student needs to set goals, complete a goal-setting exercise, create a goals roadmap, or review progress on existing goals. Also trigger at the start of a new tutoring engagement and at the beginning of each semester or term. Produces a structured .docx goals document with short-term and long-term goals for each domain, SMART validation, and a progress-tracking section.
---

# SMART Goals Planner

Guide students to set, refine, and review goals across five life domains using the SMART criteria (Specific, Measurable, Achievable, Relevant, Time-bound). This skill supports two modes — **CREATE** for building new goal documents and **REVIEW** for checking in on existing goals. The tutor leads a conversational exploration, validates each goal against SMART criteria, and produces a clean, structured document the student can reference and update over time.

## Workflow Overview

1. **Select mode** — Determine whether this is CREATE (new goals) or REVIEW (existing goals).
2. **Explore domains** — Walk through the 5 life domains, gathering goals from the student.
3. **Apply SMART validation** — Check each goal against all 5 SMART criteria; coach the student to revise until it passes.
4. **Generate the goals document** — Compile all goals into a formatted .docx (or markdown) with the 5-domain layout.
5. **Run a Goal Health Check** (REVIEW mode only) — Assess each existing goal as On Track, At Risk, or Completed; revise or replace stalled goals.

---

## Step 1 — Select Mode

Determine which mode the session is operating in:

| Mode | Trigger | Opening Question |
|------|---------|-----------------|
| **CREATE** | New student, new semester, no existing goals document | "Let's set goals across five areas of your life. What would you like to achieve this term?" |
| **REVIEW** | Existing goals document, mid-term check-in, student mentions feeling stuck | "Let's look back at the goals we set. How are things going with [Domain 1]?" |

- If CREATE: Proceed to Step 2 and build from scratch.
- If REVIEW: Load the existing goals document and proceed to Step 5 (Goal Health Check) first, then Step 2 for any gaps.

---

## Step 2 — Explore the 5 Domains

Walk through each domain conversationally. For each domain, elicit **at least one short-term goal** and **at least one long-term goal** from the student. Use open-ended prompts, then help the student sharpen their answers.

### The 5 Domains

1. **Academic** — Grades, study habits, specific subjects, organization, test prep
2. **Recreation / Fun** — Hobbies, social activities, travel, entertainment, exploration
3. **Physical / Health** — Exercise, sports, nutrition, sleep, fitness milestones
4. **Service / Community** — Volunteering, clubs, civic engagement, helping others
5. **Personal Life / Relationships** — Family time, friendships, personal projects, bonding activities

### Timeframe Definitions

| Horizon | Definition | Prompt Example |
|---------|-----------|----------------|
| **Short-Term** | Less than 8 weeks | "What can you accomplish in the next month or two?" |
| **Long-Term** | Semester to 18 months | "Where do you want to be by the end of this school year?" |

### Conversation Technique

For each domain:
1. Name the domain and give a quick example. *(e.g., "For Physical, one student set a short-term goal to work out at home once a week.")*
2. Ask the student what's on their mind — short-term first, then long-term.
3. Capture the raw goal exactly as the student states it.
4. If a student is stuck, offer 2–3 lightweight suggestions to spark ideas.
5. Write down any sub-tasks or notes the student mentions (e.g., "Practice shooting and dribbling," "Look up Honor societies").

**Example exchange — Academic domain:**
> **Tutor:** "Let's start with Academic. What's something you want to achieve in school in the next few weeks?"
>
> **Student:** "I want to do better in math."
>
> **Tutor:** "Great start. What does 'do better' look like specifically — a certain grade, understanding a topic, turning in all homework?"
>
> **Student:** "Get an 85 or above on the next math test."
>
> **Tutor:** "Perfect. When is that test?"
>
> **Student:** "Next week."
>
> **Tutor:** *(records)* Short-Term: "Score 85 or above on next math test (next week)." Now what's a bigger academic goal for the year?

---

## Step 3 — Apply SMART Validation

After gathering a raw goal, validate it against all 5 SMART criteria. The goal must pass ALL five to be recorded. Coach the student to revise if any criterion is missing.

### SMART Checklist

| Criterion | Question to Ask | Pass Example | Fail Example |
|-----------|----------------|--------------|--------------|
| **S** — Specific | "What exactly will you do? Can you describe the action?" | "Score 85 or above on next math test" | "Do better in math" |
| **M** — Measurable | "How will you know you've achieved it? What's the number or indicator?" | "85 or above" | "Get good grades" |
| **A** — Achievable | "Is this realistic given your schedule and resources? Do you need any support?" | "Work out at home once a week" | "Run a marathon next month" (for a non-runner) |
| **R** — Relevant | "Why does this matter to you? How does it connect to what you care about?" | "Improving soccer to JV level" (student plays soccer) | "Learn piano" (student has no interest) |
| **T** — Time-bound | "By when exactly? What's your deadline?" | "Next week," "By end of 4th 9-weeks" | "Soon" |

### Validation Process

1. State the goal back to the student.
2. Run through S-M-A-R-T one letter at a time.
3. For any criterion that fails, ask a follow-up question to help the student sharpen the goal.
4. Once all 5 pass, read the finalized goal aloud for confirmation.
5. Record the finalized goal plus any sub-tasks or notes.

**If a goal is too ambitious** (A fails): Help the student scale it down to a stepping-stone version.

**If a goal is too vague** (S or M fails): Ask for concrete actions or numbers.

**If no deadline exists** (T fails): Ask the student to pick a realistic date.

---

## Step 4 — Generate the Goals Document

Compile all validated goals into a clean document. Use the template below. Prefer .docx output when tools are available; otherwise use structured markdown.

### Document Template

```
[Student Name]'s SMART Goals
[Semester/Term] [Year]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Academic
Short-Term (< 8 Weeks):
  1. [Goal text] — by [date]
     - [Sub-task or note]
     - [Sub-task or note]
  2. [Goal text] — by [date]

Long-Term (Semester / Year):
  1. [Goal text] — by [date]
  2. [Goal text] — by [date]
     - [Sub-task or note]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Recreation / Fun
Short-Term (< 8 Weeks):
  1. [Goal text] — by [date]

Long-Term (Semester / Year):
  1. [Goal text] — by [date]
     - [Sub-task or note]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Physical / Health
Short-Term (< 8 Weeks):
  1. [Goal text] — by [date]
     - [Sub-task or note]

Long-Term (Semester / Year):
  1. [Goal text] — by [date]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Service / Community
Short-Term (< 8 Weeks):
  1. [Goal text] — by [date]
  2. [Goal text] — by [date]

Long-Term (Semester / Year):
  1. [Goal text] — by [date]
     - [Sub-task or note]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Personal Life / Relationships
Short-Term (< 8 Weeks):
  1. [Goal text] — by [date]
  2. [Goal text] — by [date]

Long-Term (Semester / Year):
  1. [Goal text] — by [date]
     - [Sub-task or note]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Progress Tracker

Domain            | Goal                    | Status      | Last Updated
------------------|-------------------------|-------------|-------------
Academic          | [Goal text]             | [On Track / | [Date]
                  |                         |  At Risk /  |
                  |                         |  Completed] |
[... repeat for each goal ...]

Status Key:
  On Track  — Making steady progress; no obstacles reported.
  At Risk   — Behind schedule or blocked; needs revision or support.
  Completed — Goal achieved; celebrate and set a new one!
```

### Formatting Notes

- Use clear section dividers between domains.
- List sub-tasks as indented bullet points under the parent goal.
- Include the student's name and the semester/term in the header.
- Save the file as: `[StudentName]_SMART_Goals_[Semester]_[Year].docx`
- Share the document with the student at the end of the session.

---

## Step 5 — Goal Health Check (REVIEW Mode)

When reviewing existing goals, run a health check on every goal in the document.

### Process

1. Read each goal aloud from the existing document.
2. Ask the student: "How's this going? What's your progress?"
3. Assign one of three statuses:

| Status | Definition | Action |
|--------|-----------|--------|
| **On Track** | Student reports progress and is on schedule to meet the deadline | Confirm, keep in document, update last-reviewed date |
| **At Risk** | Student is behind, blocked, or unsure how to proceed | Explore the blocker, revise the goal or deadline, add a sub-task for support |
| **Completed** | Student has achieved the goal | Mark as completed, add completion date, ask the student to set a replacement goal |

4. For **At Risk** goals, ask:
   - "What's making this hard right now?"
   - "Should we change the deadline, break it into smaller steps, or replace it with something different?"
   - "What support do you need?"
5. For **Completed** goals:
   - Celebrate the win.
   - Ask what the student wants to aim for next in that domain.
   - Run the new goal through SMART validation (Step 3).
6. Update the Progress Tracker table with new statuses and dates.
7. Save the revised document.

---

## Key Principles

- **Student-driven goals.** The student must own their goals — never impose goals on them. Coach, suggest, and guide, but the final wording must come from the student.
- **Every goal must pass all 5 SMART criteria.** A goal that fails even one criterion is a draft, not a final goal.
- **Short-term goals are non-negotiable.** Every domain must have at least one short-term goal; long-term goals can be fewer.
- **Sub-tasks make goals actionable.** Always capture the specific actions, resources, or research steps the student mentions.
- **Keep the conversation warm and casual.** Goal-setting should feel encouraging, not like an interrogation. Share examples freely.
- **Document everything immediately.** Update the goals document live during the session so the student sees their progress in real time.
- **Goal Health Checks are proactive.** In REVIEW mode, don't just ask "How's it going?" — probe for specifics on progress, obstacles, and next steps.
- **Replace, don't just delete.** If a goal is stalled, help the student revise or replace it so the domain doesn't end up empty.

---

## Example Goals by Domain

Use these as conversation starters when a student is stuck.

| Domain | Short-Term Example | Long-Term Example |
|--------|-------------------|-------------------|
| Academic | Score 85+ on next math test using the Pomodoro Technique daily | Earn all As in the 4th 9-week period |
| Recreation | Plan a day to hang out with friends at the mall + eat there | Family trip to Japan; research 3 things to do there |
| Physical | Work out at home once a week with calisthenics | Improve at soccer to JV level; practice shooting/dribbling daily |
| Service | Find a list of school clubs and activities | Do a volunteering session with a parent at a local animal shelter |
| Personal | Family outing to a favorite restaurant | Family trip to visit relatives in another city |
