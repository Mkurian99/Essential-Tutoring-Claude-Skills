---
name: parent-update-drafter
description: >
  Draft professional, warm, and informative parent update messages about a
  student's tutoring progress. Produces three output formats based on context —
  After-Session Text (brief, same-day), Weekly Update Email (structured
  end-of-week), and Formal Progress Report (month/term-end). Trigger after
  every session if parents request updates, weekly as a rollup, when there's
  a significant win or concern, at month/term end, or when transitioning the
  student to another tutor. Completes in 2–4 minutes of interaction.
---

# Parent Update Drafter

Draft parent communications that inform, celebrate, and build trust. Every
message is specific, warm, and honest — parents should feel empowered, not
anxious. This skill produces three output formats matched to the situation:

1. **After-Session Text** — A brief 3–5 sentence message for text/SMS or
   tutoring app messaging. Sent same-day.
2. **Weekly Update Email** — A structured email sent every Friday or after the
   last session of the week.
3. **Formal Progress Report** — A comprehensive document for month-end or
   term-end reporting.

All three pull from the same data sources — session notes (wins, growth areas,
homework completion, engagement) and the goals tracker (goal progress) — but
vary in depth, tone, and structure based on cadence and context.

## Workflow Overview

1. **Determine cadence and context** — Identify which output format and tone
   are needed based on timing, parent preference, and any escalation triggers.
2. **Gather source data** — Pull from session notes and the goals tracker.
   Ask the tutor for what's missing.
3. **Draft the update** — Fill the appropriate template with specifics.
4. **Apply tone and customization** — Tune language to parent style, insert
   the student's name naturally, and check concern-escalation rules.
5. **Review and finalize** — Run the quality checklist before sending.

---

## Step 1 — Determine Cadence and Context

Identify which output format to produce and what tone adjustments are needed.

### Output Format Selector

| Situation | Output | Timing | Tone |
|---|---|---|---|
| Parent requested regular updates | After-Session Text | Within 4 hours of session | Warm, brief |
| Last session of the week | Weekly Update Email | Within 24 hours (ideally Friday) | Warm, structured |
| Month-end or term-end | Formal Progress Report | Within 3 days of period end | Professional, comprehensive |
| Significant win (test score jump, breakthrough) | After-Session Text | Same day | Warm, celebratory |
| Significant concern (3+ sessions of issues) | Weekly or Formal (escalated) | Within 24 hours | Formal, phone-call suggested |
| Transitioning to new tutor | Formal Progress Report | At handoff | Professional, forward-looking |

### Parent Communication Style

If known, match the parent's preferred style. Default to warm-narrative unless
the tutor indicates otherwise.

| Style | Signals | Adjustments |
|---|---|---|
| **Brief / Factual** | Short replies, no small talk, asks for bottom line | Shorter sentences, bullet points, minimize narrative |
| **Narrative / Warm** | Long replies, asks how sessions went, shares stories | Full paragraphs, expressive language, personal touches |
| **Data-Driven** | Asks for scores, percentages, comparisons | Lead with numbers, include trend data, use metrics |
| **Hands-Off** | Rarely replies, defers to tutor | Shorter messages, only significant wins and concerns |

### Escalation Check

Before drafting, check for persistent problems. If **any** of the following
are true across **3 or more consecutive sessions**, the update must escalate:

- Homework not completed or not attempted
- Engagement level Low (by session-notes-writer criteria)
- Skill regression (performance declining vs. prior sessions)
- Repeated avoidance of a specific topic or task type

**Escalation rules:**
- Never deliver hard news via text — use Weekly Update or Formal Progress Report.
- Tone shifts to more formal and direct.
- Include a specific, bounded phone-call offer: *"I'd welcome a brief 10-minute
call this week. I'm free Tuesday at 4 PM or Wednesday at 5:30 PM — would
either work for you?"*
- Frame the issue as solvable: state what was observed, what the tutor is doing,
and what the parent can do to help.

---

## Step 2 — Gather Source Data

Collect the following from the tutor's records. Ask directly if anything is
missing — do not fabricate specifics.

### From Session Notes (current and recent sessions)

| Field | Example |
|---|---|
| Session date(s) and focus(es) | 2025-06-22: Factoring quadratics; 2025-06-24: Word problems |
| Specific wins with evidence | Solved 8/10 trinomials (up from 5/10); scored 87 on math quiz |
| Growth area (honest, 1 per update) | Still working on checking answers — skips verification step |
| Homework assigned and completion status | Worksheet (12 problems) — submitted on time |
| Engagement level(s) | High on 6/22 — asked for extra problems; Medium on 6/24 |
| Notable student quotes | *"I think I actually get this now"* |

### From Goals Tracker

| Field | Example |
|---|---|
| Goals set at start of period | Score 80+ on next math test; complete all homework for 4 weeks straight |
| Progress against each goal | Math test: 87 achieved ✓; Homework streak: 3/4 weeks, missed 1 assignment |
| Skills mastered this period | GCF factoring, trinomial factoring (a = 1) |
| Skills still developing | Factoring when a ≠ 1, word problem translation |
| Updated plan for next period | Introduce factoring with a ≠ 1, begin systems of equations |

### Customization Inputs

| Field | Notes |
|---|---|
| Student first name | Must appear 2–3 times naturally in every update |
| Parent name(s) / salutation preference | "Hi Ms. Chen" vs. "Hi Jennifer" vs. "Hi Chen family" |
| Parent communication style | Brief, narrative, data-driven, or hands-off |
| Known parent interests or context | *"I know Maya has a science fair coming up"* — if shared |

---

## Step 3 — Draft the Update

Select the appropriate template and fill it with specific data. Never use
placeholders in the final output — every bracketed field must be replaced with
real content.

---

### Format A: After-Session Text

**Purpose:** Brief, same-day message for text/SMS or app messaging.
**Length:** 3–5 sentences.
**Structure:** Warm opener → 1–2 session specifics → homework reminder →
friendly close.

**Template:**

```
Hi [Parent Name], [Student name] had a [positive descriptor] session today
[specific focus]! [He/She/They] [specific achievement with numbers/evidence],
and [related detail or second win]. [He/She/They] has [homework assignment]
due [due date]. [Friendly forward-looking close].
```

**Example (Brief-parent style):**

```
Hi Ms. Patel, Maya had a strong session today on factoring quadratics.
She solved 8/10 trinomial problems (up from 5 last week) and asked for
extra challenge problems. Homework worksheet is due Sunday 6/29.
She's building real confidence here.
```

**Example (Narrative-parent style):**

```
Hi Ms. Patel, Maya had a fantastic session today — her confidence with
factoring quadratics is really coming through! She solved 8 out of 10
trinomial problems correctly, which is a big jump from the 5 she got last
week, and she actually asked for extra challenge problems at the end. She
has a 12-problem worksheet due this Sunday (6/29). It's so great to see
her enthusiasm building!
```

**Rules for After-Session Text:**

- 3–5 sentences max. Never longer than a single short paragraph.
- Include at least one specific number, score, or concrete example — never
  *"did well today."*
- Mention homework only if assigned.
- Never include concerns, growth areas, or hard news — save those for Weekly or
  Formal formats.
- Student's name must appear at least once.
- Match the parent's communication style (brief parents get shorter text).

---

### Format B: Weekly Update Email

**Purpose:** Structured end-of-week summary. Sent every Friday or after the
last session of the week.
**Length:** 150–250 words.
**Structure:** 7 sections.

**Template:**

```
Subject: [Student Name]'s Weekly Update — [Week of Date]

Hi [Parent Name],

[Greeting — warm opener, one sentence about the week overall. Reference
something specific from the week.]

This Week's Focus
[2–3 sentences on what was covered this week. Name specific topics,
concepts, or assignments. Connect to broader goals if relevant.]

Wins This Week
• [Specific win 1 — with numbers or concrete evidence]
• [Specific win 2 — with numbers or concrete evidence]
• [Specific win 3 — if applicable, a behavioral or attitudinal win]

Area We're Growing
[One honest growth area, framed constructively. State what was observed,
what the tutor is doing to address it, and what progress is expected.]

Looking Ahead
[Next week's plan — 1–2 sentences on topics, goals, or upcoming
milestones like tests or assignments.]

A Question for You
[One engaging, low-effort question to invite parent response. Make it
specific to the student's situation.]

Best,
[Tutor Name]
```

**Example:**

```
Subject: Alex's Weekly Update — Week of June 22

Hi Ms. Chen,

Alex had a solid week — we covered a lot of ground with factoring and
he's starting to connect the pieces!

This Week's Focus
We spent both sessions on factoring quadratic expressions — starting with
GCF factoring, then moving into trinomials where the leading coefficient
is 1. Alex is getting more comfortable identifying which method to use
first.

Wins This Week
• Alex solved 8/10 trinomial factoring problems correctly on Thursday,
  up from 5/10 on Tuesday — clear improvement in just two sessions.
• He mastered GCF factoring (perfect score on the review set) and is
  now using it automatically as a first step.
• He asked for extra challenge problems at the end of Thursday's
  session, which shows growing confidence and engagement.

Area We're Growing
We're still working on the habit of checking answers by expanding — Alex
sometimes skips this step and misses small sign errors. I've been
prompting him to verify each answer before moving on, and we're
practicing it every session. It's a habit that takes time but will save
him points on tests.

Looking Ahead
Next week we'll tackle factoring when the leading coefficient isn't 1,
which is the next unit in his class. We'll also review his homework from
this weekend to make sure he's solid before moving on.

Have you noticed Alex using any of these factoring strategies on his
school homework? I'd love to hear what you're seeing at home!

Best,
Jordan
```

**Rules for Weekly Update Email:**

- Every win must include **specific evidence** — numbers, scores, or concrete
  behaviors. *"Solved 8/10"* not *"did well."*
- The growth area must be **honest but framed constructively** — never alarming.
  Say *"building toward"* or *"practicing,"* never *"struggling with"* or
  *"failing at."*
- The question for the parent should be **specific and easy to answer** — not
  generic *"Let me know if you have questions."*
- Student's name must appear 2–3 times naturally throughout.
- If an escalation trigger is active (3+ sessions of issues), use the
  **Escalated Weekly** variant (see Escalation section below).

---

### Format C: Formal Progress Report

**Purpose:** Comprehensive document for month-end or term-end.
**Length:** 300–500 words.
**Structure:** 8 sections.

**Template:**

```
Subject: [Student Name] — [Month/Term] Progress Report

Hi [Parent Name],

[Opening paragraph — warm acknowledgment of the period. 2–3 sentences
summarizing overall trajectory. Specific, not generic praise.]

Goals Set at the Start of [Period]
• [Goal 1]: [Original goal text]
• [Goal 2]: [Original goal text]
• [Goal 3]: [Original goal text]

Progress Evidence
[Paragraph with specific data — test scores, accuracy rates, homework
completion percentages, engagement trends. Compare start-of-period to
end-of-period.]

Skills Mastered
• [Skill 1] — [Evidence: e.g., "consistent 90%+ accuracy over 3 sessions"]
• [Skill 2] — [Evidence]
• [Skill 3] — [Evidence]

Skills Still Developing
• [Skill 1] — [Current status and what we're doing to build it]
• [Skill 2] — [Current status and what we're doing to build it]

Updated Plan for Next [Period]
[2–3 sentences on focus areas, upcoming topics, and any adjustments to
the approach based on this period's data.]

Recommended Schedule / Focus
[Any changes to session frequency, duration, or emphasis areas. Justify
with data from the period.]

What You Can Do to Support
[2–3 specific, actionable suggestions for the parent. Tie each to
something observed during sessions.]

A Word From [Student Name]
"[Positive quote from the student — something they said that reflects
growth, enjoyment, or pride.]"

[Closing paragraph — forward-looking, appreciative, open to parent
input.]

Best,
[Tutor Name]
```

**Example (excerpted key sections):**

```
Subject: Alex — June Progress Report

Hi Ms. Chen,

Alex has made strong progress this month in algebra. When we started,
he was unsure about factoring and often skipped steps. By the end of
June, he's factoring trinomials with confidence and using systematic
checks — a real shift in both skill and mindset.

Goals Set at the Start of June
• Score 80+ on the next math test: Achieved — scored 87 on the June 20 test.
• Complete all tutoring homework for the month: Partial — completed 3 of
  4 assignments (missed one during finals week).
• Master GCF and basic trinomial factoring: Achieved — consistent 90%+
  accuracy over the final three sessions.

Progress Evidence
Alex began June solving 4/10 trinomial factoring problems correctly with
frequent prompts. By June 24, he scored 8/10 independently and correctly
identified when to apply GCF first. His homework completion rate was 75%
(3/4 assignments), with the missed assignment occurring during school
finals — understandable given the context. Engagement was High in 3 of
4 sessions.

Skills Mastered
• GCF factoring — 100% accuracy, uses automatically as a first step
• Trinomial factoring (a = 1) — 80%+ accuracy, works independently
• Checking answers by expanding — now completes this step without
  prompting in 7/10 cases (up from 0/10)

Skills Still Developing
• Factoring when a ≠ 1 — introduced in the final session; Alex can
  complete with guided prompts but is not yet independent. We'll build
  this in July.
• Word problem translation — Alex can set up equations for simple
  scenarios but gets stuck on multi-step problems. We're practicing
  diagramming strategies.

Updated Plan for July
We'll build on Alex's factoring foundation by working through cases where
the leading coefficient isn't 1, then move into solving quadratic
equations. Once he's solid there, we'll return to word problems with
stronger algebraic tools.

Recommended Schedule / Focus
Continue with 2 sessions per week. No change needed — Alex is making
steady progress at this frequency.

What You Can Do to Support
• Encourage Alex to try the first 3 homework problems the same day as
  our session, while the concepts are fresh. This was the pattern on
  the weeks he submitted on time.
• If you notice him doing math homework, ask him to explain one problem
  out loud — he's proud of his progress and explaining reinforces it.
• The Khan Academy links I share after each session are great for extra
  practice if he has downtime.

A Word From Alex
"I didn't think I could do this at the start, but now it's like a puzzle
I know how to solve." — Alex, June 24 session

Thank you for your support this month, Ms. Chen. I'm excited about what
Alex can achieve in July. Please let me know if you'd like to chat
anytime — I'm always happy to jump on a quick call.

Best,
Jordan
```

**Rules for Formal Progress Report:**

- Every claim must be backed by **specific data** — scores, accuracy rates,
  completion percentages, session counts.
- Include **start-vs-end comparisons** to show trajectory.
- Goals must be explicitly marked as **Achieved / Partial / Not Yet** with
  evidence.
- The student quote must be **verbatim** from session notes — never invented.
- Recommendations for the parent must be **actionable and specific** — not
  generic *"keep supporting him."*
- Student's name must appear 2–3 times naturally.
- If an escalation trigger is active, the Formal Progress Report becomes the
  vehicle for addressing it — see Escalated Format below.

---

### Escalated Format (Concern Active)

When 3+ consecutive sessions show persistent problems, use this adjusted
structure within the Weekly or Formal template.

**Changes from standard format:**

1. **Tone shifts:** More formal, direct, and solution-oriented. Still warm —
   never clinical or cold.
2. **The growth area becomes a dedicated section** titled *"Let's Connect on
   [Topic]"* or *"Working Together on [Issue]."*
3. **Include a bounded phone-call offer:**
   > *"I'd welcome a brief 10-minute call to share what I'm seeing and hear
   > your perspective. I'm free [day] at [time] or [day] at [time] — would
   > either work for you?"*
4. **Frame as solvable:** State what was observed, what the tutor is already
   doing, and what the parent can do.
5. **Never send over text** — use Weekly Update Email at minimum.

**Example escalated growth area (Weekly format):**

```
Let's Connect on Homework Completion

I've noticed Alex hasn't submitted the last three homework assignments
(sessions on 6/10, 6/17, and 6/24). During sessions, he understands the
concepts well, but the lack of independent practice is showing — his
accuracy on warm-up problems has dropped from 80% to 55%. I'm trying a
few things: we're starting each session with a 5-minute homework review,
and I'm breaking assignments into smaller daily chunks. A brief 10-minute
call would help us get aligned. I'm free Thursday at 5 PM or Friday at
4:30 PM — would either work for you?
```

---

## Step 4 — Apply Tone and Customization

After drafting, run these customization passes before finalizing.

### Name Check

- [ ] Student's first name appears 2–3 times naturally (not forced).
- [ ] Parent name is correct in greeting and sign-off.
- [ ] Correct pronouns (he/she/they) used consistently throughout.

### Specificity Audit

Replace every vague phrase with concrete detail:

| Vague | Specific |
|---|---|
| "did well" | "solved 8/10 problems correctly" |
| "improved" | "scored 87, up from 72 last month" |
| "worked hard" | "completed all 15 problems and asked for 3 more" |
| "struggling with" | "building fluency in" or "practicing" |
| "some homework" | "12-problem factoring worksheet, due Sunday 6/29" |
| "next time" | "Tuesday 7/1 at 4:00 PM — we'll review the worksheet" |

### Tone Calibration

Match the final tone to the situation and parent style:

| Situation | Tone Target | Check |
|---|---|---|
| Standard update | Warm but professional | Reads like a trusted teacher, not a chatbot |
| Big win | Celebratory but grounded | Specific about what was achieved; no exclamation-point overload |
| Growth area | Honest but constructive | Problem is named; solution is emphasized; parent feels equipped |
| Escalation | Formal, direct, collaborative | Clear about concern; focused on solutions; phone call offered |

### Language Sensitivity

- Use the parent's communication style from Step 1. A brief-parent gets
  shorter sentences and bullets; a narrative-parent gets fuller paragraphs.
- If the parent's preferred language is known, write in that language.
- Avoid jargon. *"Trinomial factoring"* is fine if the parent has seen it
  before; otherwise add a brief plain-language note.

---

## Step 5 — Review and Finalize

Run this checklist before delivering any update.

### Universal Checks (all formats)

- [ ] Student name appears 2–3 times naturally.
- [ ] Parent name is correct.
- [ ] Every performance claim has specific evidence (number, score, example).
- [ ] No vague praise or vague concern — all specifics.
- [ ] Honest about struggles without alarming.
- [ ] Celebratory about wins without hyperbole.
- [ ] Homework mentioned only if assigned; includes due date if so.
- [ ] No fabricated quotes, scores, or data.
- [ ] Pronouns used correctly and consistently.
- [ ] Parent's communication style is matched.

### Format-Specific Checks

**After-Session Text:**
- [ ] 3–5 sentences max.
- [ ] Suitable for text/SMS — no complex formatting needed.
- [ ] No concerns or hard news included.
- [ ] Warm opener and friendly close present.

**Weekly Update Email:**
- [ ] All 7 sections present (Greeting, This Week's Focus, Wins, Growth Area,
  Looking Ahead, Question for Parent, Sign-off).
- [ ] 2–3 wins, each with specific evidence.
- [ ] 1 growth area, constructively framed.
- [ ] Parent question is specific and easy to answer.
- [ ] 150–250 words.

**Formal Progress Report:**
- [ ] All 8 sections present (Goals, Progress Evidence, Skills Mastered,
  Skills Developing, Updated Plan, Schedule, Parent Support, Student Quote,
  Opening and Closing).
- [ ] Goals marked Achieved / Partial / Not Yet with evidence.
- [ ] Start-vs-end comparisons included.
- [ ] Student quote is verbatim from session notes.
- [ ] 300–500 words.

**Escalation Checks (if applicable):**
- [ ] Not sent via text — Weekly or Formal format used.
- [ ] Phone call offered with 2 specific time slots.
- [ ] Issue framed as solvable; tutor actions stated.
- [ ] Parent given a specific, actionable way to help.
- [ ] Tone is formal but still collaborative — not clinical or blaming.

---

## Key Principles

- **Specific, never vague.** *"Solved 8/10 trinomials, up from 5/10 last
  week"* — not *"did well."* Every claim needs evidence.
- **Warm but professional.** The parent should feel their child is seen,
  supported, and liked — not diagnosed or judged.
- **Honest about struggles without alarming.** Growth areas are framed as
  *"building toward"* or *"practicing,"* never *"struggling with"* or
  *"failing at."* The parent should feel equipped to help, not anxious.
- **Celebratory without hyperbole.** Wins are grounded in specifics. No
  exclamation-point overload, no vague superlatives.
- **Empowered, not judged.** Every message should leave the parent feeling
  informed and capable of supporting their child.
- **Student name, naturally.** The student's name appears 2–3 times per
  update — woven in, not forced.
- **No hard news over text.** Persistent concerns (3+ sessions) are
  communicated via Weekly Update or Formal Progress Report, never
  After-Session Text. Always offer a phone call.
- **Match the parent's style.** Brief parents get brevity. Narrative parents
  get warmth. Data-driven parents get numbers. Never impose a tone mismatch.
- **Data integrity.** All numbers, scores, and quotes come from documented
  session notes and goals trackers — never fabricated.
- **The student quote is sacred.** Only include verbatim quotes from session
  notes. A missing quote is better than a made-up one.

---

## Theming / Formatting

- **After-Session Text**: Plain text, no markdown. Copy-paste ready for SMS,
  WhatsApp, or tutoring platform messaging. Single short paragraph.
- **Weekly Update Email**: Clean markdown with bold headers. Renders well in
  email clients. Copy-paste ready into email body.
- **Formal Progress Report**: Structured markdown with clear section headers.
  Can be pasted into email or saved as a document. Bullet points for scans;
  paragraphs for depth.
- All three formats are produced from the same data pool — gather once,
  then select and adapt the appropriate template.
- **Subject lines** are provided in templates. Keep them clear and
  student-name-first so parents can search their inbox.
