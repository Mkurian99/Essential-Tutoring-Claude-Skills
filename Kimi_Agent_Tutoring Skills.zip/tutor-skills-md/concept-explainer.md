---
name: concept-explainer
description: >
  Use when a student says "I don't get [topic]," when homework reveals a conceptual gap,
  when previewing upcoming class material, or when re-teaching after error-pattern analysis
  shows a conceptual root cause. Generates a tutor-facing script plus student-facing explanation
  with prerequisites, analogy, worked example, your-turn problem, check-for-understanding
  questions, and misconception warning — delivered in tiered mode (first pass → deep dive →
  quick refresher) based on time and student need.
---

# Concept Explainer

Generate a structured, grade-appropriate mini-lesson script that a tutor can read aloud or
adapt on the fly. The output includes both a tutor-facing script (with stage directions and
decision cues) and a student-facing explanation. The skill scales from a 30-second first pass
to a full deep dive depending on the student's need.

## Workflow Overview

1. **Gather context** — Identify topic, grade, proficiency, known misconceptions, and any
textbook/teacher notes to avoid conflicting explanations.
2. **Build the explanation package** — Generate the full deep-dive script with all seven
components, then mark which parts belong to first-pass and quick-refresher modes.
3. **Deliver the script** — Present tutor-facing script with delivery notes, visual cues, and
mode labels so the tutor can choose how deep to go in the moment.

---

## Step 1 — Gather Context

Collect the following from the tutor (or infer from conversation history):

| Field | What to capture |
|---|---|
| **Topic / concept** | The exact concept the student is stuck on. Be specific (e.g., "solving two-step equations with negative coefficients" not just "algebra"). |
| **Grade level** | Student's current grade (e.g., 7th, 10th, AP). Used to set vocabulary, analogy domain, and example complexity. |
| **Proficiency** | `beginner` — first exposure or completely lost; `intermediate` — partial understanding, inconsistent application; `advanced` — solid foundation but stuck on a specific edge case or extension. |
| **Known misconceptions** | Any wrong idea the student has voiced (e.g., "you can just add the exponents when multiplying any numbers with exponents"). |
| **Student interests** | Hobbies or interests for analogy anchoring — sports, gaming, music, cooking, art, pets, etc. |
| **Textbook / teacher notes** | How the teacher or textbook explains this. Avoid contradictory language or notation. |

**If the tutor provides only a topic:** Ask for grade and proficiency. Default to `intermediate`
and generate the full package. The tutor can skip sections.

---

## Step 2 — Build the Explanation Package

Generate a single script with all seven components below. Label every section with its
component tag and its delivery mode (`[FIRST PASS]`, `[DEEP DIVE]`, or `[QUICK REFRESHER]`).

### Required Components (generate ALL of these)

#### 1. Prerequisite Check `[DEEP DIVE]`
List 2–3 things the student must already know to follow this lesson. Frame each as a
confirmation question the tutor can ask.

**Template:**
```
Before we jump in, quick check — do you remember [prerequisite 1]?
And [prerequisite 2]?
If either feels shaky, I'll do a 30-second review right now.
```

**Example (solving two-step equations):**
> "Before we jump in — do you remember that whatever you do to one side of an equation,
> you have to do to the other? And are you comfortable with adding and subtracting
> negative numbers? If either feels shaky, I'll do a 30-second review right now."

---

#### 2. Core Explanation `[FIRST PASS]` `[QUICK REFRESHER]`
Explain the concept in plain language. **Maximum 3–4 sentences.** No jargon without definition.
Use the student's interests for an analogy hook if possible.

**Rules:**
- Lead with the "why this matters" if it fits in one sentence.
- Define any term you use that is newer than the student's grade level.
- If the student's proficiency is `beginner`, reduce to 2–3 sentences and simplify vocabulary.

**Example (photosynthesis, 7th grade, beginner, student likes video games):**
> "Plants make their own food using sunlight, water, and air — it's like a crafting recipe
> in a game. Sunlight provides the energy to combine water and carbon dioxide into glucose,
> which is the plant's fuel. Oxygen gets released as a byproduct — basically the plant's
> leftover crafting scrap."

---

#### 3. Analogy / Metaphor `[FIRST PASS]` `[QUICK REFRESHER]`
One concrete, relatable analogy that maps structurally to the concept. The analogy must
match the student's interest area if known; otherwise use a universally relatable domain
(food, sports, money, organizing a closet).

**Rules:**
- The analogy must map **all key parts** of the concept, not just one.
- State both the analogy and the mapping explicitly ("So X is like Y because...").
- Flag any place where the analogy **breaks down** if it could cause confusion.

**Example (solving equations = balancing a scale):**
> "Think of an equation like a seesaw that's perfectly level. The equals sign is the center.
> Whatever you put on the left, you have to put the same weight on the right, or it tips.
> We're trying to figure out what 'x' weighs by itself, so we keep removing the same amount
> from both sides until x is alone."
> *Breakdown warning:* "Unlike a real seesaw, in math you can subtract a negative — which
> is like adding weight. That's a weird seesaw but it's how equations work."

---

#### 4. Worked Example `[DEEP DIVE]` `[QUICK REFRESHER]`
A step-by-step worked problem with **reasoning narrated aloud for every step**. This is not
just the math — it's the *thinking*.

**Template (each step follows this rhythm):**
```
Step N: [Action]
Tutor says: "[Why I'm doing this and what I notice]"
[Work shown]
```

**Rules:**
- Use a **clean, medium-difficulty** example — not the hardest variant.
- Number every step.
- Include a `[VISUAL]` cue where drawing or labeling helps (e.g., `[VISUAL: Draw a number line labeled 0 to 10]`).
- State the goal of the problem at the start.
- End with a verification step: "Let's check — does this make sense?"

**Example (solving 3x + 7 = 22):**
> **Goal:** Find the value of x.
>
> **Step 1:** Subtract 7 from both sides.  
> Tutor says: "I want to get x by itself, but there's a +7 in the way. I need to undo
> that addition by subtracting 7 — and I do the exact same thing to both sides so the
> equation stays balanced."  
> 3x + 7 − 7 = 22 − 7 → 3x = 15
>
> **Step 2:** Divide both sides by 3.  
> Tutor says: "Now x is being multiplied by 3. To undo multiplication, I divide. Again,
> both sides, same amount — balance the scale."  
> 3x ÷ 3 = 15 ÷ 3 → x = 5
>
> **Step 3:** Check the answer.  
> Tutor says: "Let's plug 5 back in to make sure. Three times 5 is 15, plus 7 is 22.
> That's what we started with. Checks out."

---

#### 5. Your-Turn Problem `[DEEP DIVE]`
A similar problem for the student to solve independently. **Make it slightly easier** than
the worked example to build confidence.

**Rules:**
- Use the same structure and skills as the worked example.
- Reduce one source of complexity (smaller numbers, positive coefficients only, fewer steps).
- Include a hint the tutor can offer if the student stalls after 20–30 seconds.
- Include the full solution for the tutor (hidden from student view, or clearly marked).

**Example (following the 3x + 7 = 22 worked example):**
> **Student problem:** Solve 2x + 5 = 13.  
> **Hint if stuck:** "What's in the way of x being alone? How do you undo adding 5?"  
> **Solution:** x = 4. (2×4 + 5 = 13 ✓)

---

#### 6. Check-for-Understanding Questions `[DEEP DIVE]`
3 quick questions in this order:

| # | Type | Purpose |
|---|---|---|
| Q1 | **Factual recall** | Verify they know a definition or rule |
| Q2 | **Application** | Can they use the concept in a new, simple situation? |
| Q3 | **Extension / "What if?"** | Tests deeper understanding; what happens if we change one thing? |

**Rules:**
- Each question should take under 30 seconds to answer.
- Include the expected answer and a brief follow-up the tutor can use if the student is wrong.

**Example (solving equations):**
> **Q1 (Recall):** "What's the golden rule for keeping an equation balanced?"  
> *Expected:* "Whatever you do to one side, you do to the other."
>
> **Q2 (Application):** "If I have x − 9 = 4, what's my first move?"  
> *Expected:* "Add 9 to both sides."  
> *If wrong:* "Remember, we want x alone. What's attached to x right now? How do we undo that?"
>
> **Q3 (Extension):** "What if the equation was −2x = 14? How is this different, and what's
> the first step?"  
> *Expected:* "x is multiplied by −2, so divide both sides by −2. You get x = −7."  
> *If wrong:* "Let's think about what the minus sign means here. Is −2x the same as 2 times
> a negative number, or something else?"

---

#### 7. Common Misconception Warning `[DEEP DIVE]` `[QUICK REFRESHER]`
Name the single most likely wrong turn and explain **why** it's wrong.

**Template:**
```
⚠️ Watch out for: [misconception]
Why it's wrong: [brief explanation]
Right move instead: [what to do]
```

**Example:**
> ⚠️ **Watch out for:** "When you see 3x + 7, some students try to combine them into 10x."
> **Why it's wrong:** "3x and 7 are not like terms — 3x is 'some unknown number of x's'
> and 7 is just a plain number. You can't add apples and miles."
> **Right move instead:** "Leave them separate until you've dealt with the plain number
> (the +7) by moving it to the other side."

---

## Step 3 — Deliver the Script

Present the complete explanation package in the format below. The tutor reads the script and
decides how deep to go.

### Output Format

```
# [TOPIC] — Mini-Lesson Script

**Grade:** [level] | **Proficiency:** [beginner/intermediate/advanced] | **Mode:** All tiers included

---

## [FIRST PASS] — 30–60 Seconds
[Core explanation (3–4 sentences)]

**Analogy:**
[Concrete analogy with explicit mapping]

> 🎤 **Tutor delivery note:** Pause here. Ask: "Does that make sense so far?" If the student
> says yes and seems confident, you can stop or jump to the misconception warning. If they're
> unsure or say "kind of," continue to Deep Dive.

---

## [DEEP DIVE] — Full Lesson

### Prerequisite Check
[2–3 confirmation questions]

### Core Explanation
[3–4 sentence explanation]

### Analogy
[Concrete analogy with mapping and breakdown warning if needed]

### Worked Example
[Step-by-step with narrated reasoning and VISUAL cues]

### Your-Turn Problem
[Problem + hint + hidden solution]

### Check-for-Understanding Questions
[Q1 recall + expected answer + follow-up if wrong]
[Q2 application + expected answer + follow-up if wrong]
[Q3 extension + expected answer + follow-up if wrong]

### Misconception Warning
[⚠️ Name the trap, explain why it's wrong, state the right move]

---

## [QUICK REFRESHER] — Review Mode
[Compressed version: Analogy summary + one worked example + misconception warning.
Skip prerequisites. Use when reviewing before a test or after the student has seen the
full lesson once.]
```

---

## Key Principles

- **Plain language first.** Define every term that isn't solidly established for the student's
  grade. Never assume they know a word just because it's in their textbook.
- **Student interests drive analogies.** If you know the student plays soccer, use soccer.
  If they bake, use baking. Generic analogies are a last resort.
- **Narrate thinking, not just steps.** The worked example must include the *why* for every
  action — this is where understanding lives.
- **Build confidence with the your-turn problem.** Make it slightly easier than the worked
  example. A win here opens the door to harder problems later.
- **The tutor controls the pacing.** Label every section with its tier and time estimate so
  the tutor can make real-time decisions.
- **Match the teacher's language.** If the tutor provides textbook or teacher notes, echo
  that vocabulary and notation to avoid confusing the student with conflicting approaches.
- **Never skip the misconception warning.** Naming the trap before the student falls into it
  prevents rehearsal of wrong procedures.
- **One concept per skill invocation.** Don't try to cover an entire unit. One skill call =
  one specific concept (e.g., "multiplying fractions" not "all fraction operations").

---

## Theming / Branding

- Tone: Patient, encouraging, precise. The script should sound like a great tutor sitting
  next to the student — not a lecture hall.
- No robotic formatting. Use `>` blockquotes for spoken lines, plain text for stage
  directions, and `**bold**` for tutor decision cues.
- Visual cues: Mark `[VISUAL: ...]` inline where a quick sketch or label would help. Keep
  descriptions short — the tutor is drawing on paper or a whiteboard, not creating a poster.
- All content must be copy-paste ready for the tutor. No placeholders like `[insert analogy
  here]` — generate the full script every time.
