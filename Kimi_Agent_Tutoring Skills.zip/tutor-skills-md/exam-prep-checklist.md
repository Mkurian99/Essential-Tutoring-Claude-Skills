---
name: exam-prep-checklist
description: Use when a student has an exam, test, quiz, midterm, final, or standardized test coming up. Also use for project deadlines and presentation prep. Best used 1-3 weeks before the exam date. This skill produces a comprehensive, time-lined checklist organized into four phased phases — Inventory, Learning, Practice, and Consolidation — with daily check-off-able tasks, exam-format strategy guidance, logistics checklists, and a prioritized "sacrifice list" for when time runs short. Output is a printable markdown checklist or .docx.
---

# Exam Prep Checklist

Build a complete, day-by-day exam preparation checklist that ensures nothing falls through the cracks. Every task must be concrete enough to check off — "Complete p. 120-122 practice problems, check answers" not "Study Chapter 5." The checklist respects the time available, prioritizes weak topics, and includes logistics and exam-day strategy so the student walks in prepared and confident.

## Workflow Overview

1. **Gather inputs** — Collect exam details, topic list, confidence ratings, and available prep time.
2. **Run the Inventory Phase** — List every possible topic, cross-reference sources, and rate confidence 1-5.
3. **Build the phased checklist** — Assign specific, check-off-able tasks to specific days across four phases.
4. **Add format strategy and logistics** — Include exam-taking tactics and a what-to-bring checklist.
5. **Deliver as printable checklist** — Format as clean markdown or .docx; include the sacrifice list.

## Step 1 — Gather Inputs

Collect all of the following before building the checklist. Use a conversational checklist; do not start drafting until you have answers.

| Category | What to Ask | Example Answer |
|----------|-------------|----------------|
| **Exam subject** | What class / test? | AP Biology final |
| **Exam date** | Exact date and time | Friday, May 17 at 8:00am |
| **Days until exam** | Calculate from today | 10 days |
| **Exam format** | Multiple choice, essay, short answer, mixed, oral, math/science | Mixed: 60 multiple choice, 2 essay |
| **Topics / units covered** | List every chapter, unit, or topic the exam could cover | Ch 12-16: cell division, genetics, DNA replication, protein synthesis, biotechnology |
| **Confidence per topic** | Student rates 1-5 for each | Cell division 4, Genetics 2, DNA replication 2, Protein synthesis 1, Biotech 3 |
| **Study materials available** | Textbook, notes, past exams, study guides, online resources | Class notes, textbook, 2 past exams, Khan Academy |
| **Past exam performance** | What went wrong last time? | "Ran out of time on essays," "Forgot formulas" | 
| **Available prep time** | Hours per day, days available, existing commitments | 2 hrs/day weekdays, 4 hrs/day weekends; soccer Wed 6-8pm |
| **Hard deadline constraints** | Any immovable conflicts | Soccer game Saturday 2-5pm; no studying after 9pm on school nights |

**Quick confidence rating scale (use this exact language with the student):**

| Rating | Meaning |
|--------|---------|
| **5** — Got it | Could teach this to someone else |
| **4** — Pretty good | Occasional small mistakes, mostly solid |
| **3** — Shaky | Understand basics but struggle with harder applications |
| **2** — Weak | Know the vocabulary but can't solve problems independently |
| **1** — Lost | Barely recognize the topic; needs re-learning from scratch |

## Step 2 — Run the Inventory Phase

The Inventory Phase happens immediately — during this session. Its output is a complete topic inventory with confidence ratings that drives every other phase.

### Topic Inventory Template

Create a master list of every topic that could appear on the exam. Cross-reference at least two sources.

```
## Topic Inventory — [Subject] [Exam Type] — [Student Name]

Exam Date: [Date] | Days Until: [N] | Format: [Format]

| # | Topic / Subtopic | Confidence (1-5) | Source Verified | Priority |
|---|------------------|------------------|-----------------|----------|
| 1 | [Topic] — [subtopic] | [1-5] | [Syllabus + Textbook TOC] | [High/Med/Low] |
| 2 | ... | ... | ... | ... |

**Priority rule:** Topics rated 1-2 = High. Topics rated 3 = Medium. Topics rated 4-5 = Low (review only).
```

### Cross-Reference Sources

Verify topics against at least two of these sources. Check each source you use.

- [ ] **Syllabus** — Official topic list from teacher/course outline
- [ ] **Textbook table of contents** — Chapter and section headings for all covered material
- [ ] **Past exams** — Questions from previous years reveal what actually gets tested
- [ ] **Study guide** — Teacher-provided review sheet or practice test
- [ ] **Class notes** — Topics the teacher emphasized with extra time or repeated examples
- [ ] **Teacher announcements** — "This will definitely be on the test" items

### Build the Priority Queue

Sort topics by confidence (lowest first). This is the order the Learning Phase will tackle them.

```
## Priority Queue (Weakest First)

1. [Weakest topic — confidence 1] — [estimated hours needed]
2. [Second weakest — confidence 2] — [estimated hours needed]
3. ...
```

**Time estimation rule:**

| Confidence | Estimated Time per Topic |
|------------|--------------------------|
| 1 — Lost | 3-4 hours (re-learn + practice) |
| 2 — Weak | 2-3 hours (review + intensive practice) |
| 3 — Shaky | 1-2 hours (targeted practice on hard problems) |
| 4 — Pretty good | 30-45 min (light review) |
| 5 — Got it | 15-20 min (quick refresh or skip) |

## Step 3 — Build the Phased Checklist

Distribute tasks across four phases. Every task must be specific and check-off-able. Phases 2-4 map to specific days based on the exam date.

### Phase Overview

| Phase | Timing | Purpose | What Happens |
|-------|--------|---------|--------------|
| **1. Inventory** | Immediately (today) | Know what you're up against | Complete topic list, confidence ratings, priority queue |
| **2. Learning** | Majority of available days | Build competence in weak areas | Re-learn, practice problems, verify understanding |
| **3. Practice** | Last 3-5 days before exam | Simulate exam conditions | Full timed practice exams, error-pattern analysis |
| **4. Consolidation** | Day before exam | Lock in, rest, prepare | Light review only, logistics, sleep, confidence |

### Phase 2 — Learning Phase (Days [N-3] through [N-5] out)

For every topic rated 1-3: re-learn the concept, do 3-5 practice problems, verify understanding. Work weakest topics first.

```
## Phase 2: Learning Phase — [Date Range]

### [Day 1 — Date]
- [ ] [Subject]: [Topic] — Re-read notes + textbook section [X.Y] — [estimated time]
- [ ] [Subject]: [Topic] — Complete practice problems [source, page/problem #s] — [time]
- [ ] [Subject]: [Topic] — Check answers, log any mistakes in error log — [time]
- [ ] [Subject]: [Topic] — Re-do missed problems independently — [time]

### [Day 2 — Date]
- [ ] [Subject]: [Next weakest topic] — Watch [Khan Academy/video resource] on [specific subtopic] — [time]
- [ ] [Subject]: [Next weakest topic] — Complete [worksheet/source] problems [#s] — [time]
- [ ] [Subject]: [Next weakest topic] — Check answers, add mistakes to error log — [time]

### [Continue for each day...]
```

**Learning Phase rules:**
- Work weakest topics first. Do not start with a topic rated 4-5.
- Every topic rated 1-3 gets: re-learning source + 3-5 practice problems + answer checking + error logging.
- If a topic has sub-topics, list each sub-topic as a separate check-off-able task.
- Never assign "Study Chapter X." Instead: "Read p. 234-238, take notes on [specific concept], then complete problems #5-10."
- Build in 10-minute breaks every 45-50 minutes of focused work.

### Phase 3 — Practice Phase (Last 3-5 Days Before Exam)

Full practice exams under timed conditions. Review wrong answers using error-pattern analysis. Target 80%+ accuracy before exam day.

```
## Phase 3: Practice Phase — [Date Range]

### [Practice Day 1 — Date]
- [ ] Full timed practice exam — [source, e.g., "2019 AP Bio released exam, Section I only"] — [time]
- [ ] Grade answers, record score: ___ / ___ — [time]
- [ ] Error-pattern analysis: categorize each miss (see template below) — [time]
- [ ] Re-do all missed problems without looking at answers — [time]

### [Practice Day 2 — Date]
- [ ] Full timed practice exam — [source, different from Day 1] — [time]
- [ ] Grade answers, record score: ___ / ___ — [time]
- [ ] Review error log from Day 1 — re-do any problems still missed — [time]
- [ ] Focused weak-area drill: [specific topic based on error pattern] — [time]

### [Practice Day 3 — Date]
- [ ] Mixed review: 20 problems from [source] covering highest-priority topics — [time]
- [ ] Grade, log mistakes — [time]
- [ ] Review all accumulated errors one final time — [time]
- [ ] Verify target met: latest practice score ___% (target: 80%+)
```

**Error-Pattern Analysis Template**

For every wrong answer, the student logs:

```
| Problem # | Topic | Error Type | Root Cause | Fix |
|-----------|-------|-----------|------------|-----|
| [Q5] | [DNA replication] | [Concept error] | [Forgot that leading/lagging strands differ] | [Re-read p. 245-246; draw diagram] |
| [Q12] | [Genetics] | [Careless] | [Didn't read "not" in question] | [Underline negation words on every question] |
```

**Error types:** Concept error, Careless mistake, Time ran out, Didn't know approach, Formula/equation error, Vocabulary gap.

### Phase 4 — Consolidation Phase (Day Before Exam)

Light review only. No new material. Sleep, nutrition, materials prep.

```
## Phase 4: Consolidation Phase — [Day Before Exam Date]

### Morning
- [ ] Quick review: flashcards or formula sheet — 20 minutes max
- [ ] Review error log ONE final time — 15 minutes
- [ ] No new problems. No new topics. No exceptions.

### Afternoon / Evening
- [ ] Prepare exam materials (see Exam Logistics Checklist below) — 10 minutes
- [ ] Set out clothes, pack bag, set two alarms — 10 minutes
- [ ] Light dinner, avoid heavy or unfamiliar foods
- [ ] No caffeine after 4:00pm
- [ ] In bed by [target time] — aim for [N] hours of sleep

### The Night Before Rules
- [ ] No studying after [cutoff time, e.g., 8:00pm]
- [ ] No screens 1 hour before bed
- [ ] Brief confidence visualization: "I have prepared. I know this material."
```

## Step 4 — Add Exam Format Strategy and Logistics

### Exam Format Strategy

Add a strategy section tailored to the exam format. Include only the relevant format(s).

**Multiple Choice Strategy:**
- Read the question fully before looking at answer choices (cover choices if needed)
- Eliminate obviously wrong answers first — narrow to 2 choices
- Watch for absolute words: "always," "never," "all," "none" — these are often wrong
- Watch for "all of the above" / "none of the above" — verify every option before selecting
- Flag uncertain questions and return after completing all others
- Never leave a question blank if there's no penalty for guessing
- Manage time: divide total questions by time; check pace every 10-15 questions

**Essay Strategy:**
- Read all essay prompts first; start with the one you know best
- Spend 5 minutes outlining before writing — thesis + 2-3 supporting points per paragraph
- Allocate time per question: [total essay time] / [number of essays] — stick to it
- Use vocabulary from the prompt in your answer (shows engagement with the question)
- Leave 5 minutes at the end to proofread for clarity and completeness
- If running out of time, write bullet-point outlines for remaining essays — partial credit

**Short Answer Strategy:**
- Answer in direct, complete sentences
- Use the vocabulary from the question in your response
- Be concise but thorough — include a definition + example + connection to the concept
- If unsure, write what you know that's related; partial credit beats blank

**Math / Science Problem Strategy:**
- Show all work — even if answer is wrong, work earns partial credit
- Check units at every step; convert before calculating
- Estimate the answer before calculating — catch order-of-magnitude errors
- Write down relevant formulas before starting (memory dump)
- If stuck: write down what you know, what you're trying to find, and relevant formulas — then move on
- Circle or box final answers for the grader

### Exam Logistics Checklist

```
## Exam Day Logistics — [Exam Name] — [Date]

### What to Bring
- [ ] [#] sharpened pencils (bring 3+)
- [ ] [Pen with blue/black ink if required for essays]
- [ ] Calculator — with FRESH batteries (test the night before)
- [ ] Student ID / photo ID
- [ ] Watch (non-smart) for pacing
- [ ] Water bottle (clear, no label if required)
- [ ] Tissues
- [ ] [Any permitted reference materials — formula sheet, etc.]
- [ ] [Backup supplies: extra batteries, spare pencil, eraser]

### What to Know
- [ ] Exam location: [room/building]
- [ ] Exam time: [start time] — arrive by [arrival time]
- [ ] Seating: [assigned / open / TBD]
- [ ] Duration: [N minutes/hours]
- [ ] Bathroom policy: [allowed / not allowed / limited]
- [ ] Materials allowed: [closed book / open note / calculator permitted / etc.]

### What to Prepare the Night Before
- [ ] Comfortable clothes laid out (dress in layers)
- [ ] Alarm set for [time] — plus backup alarm
- [ ] Breakfast plan: [light, protein-rich — e.g., eggs, toast, fruit]
- [ ] Route to exam location confirmed (arrive 10-15 min early)
- [ ] Bag packed with all materials from "What to Bring" list
```

## Step 5 — Build the Sacrifice List and Deliver

### Sacrifice List

If time is short, the student must know what to cut. Build a ranked list of topics to deprioritize.

```
## Sacrifice List — If Time Runs Short, Cut in This Order

| Priority to Cut | Topic | Reason | Minimum Still Do |
|-----------------|-------|--------|------------------|
| 1st | [Topic name] | Lowest weight on exam / highest confidence | 15-min flashcard review |
| 2nd | [Topic name] | Teacher indicated "minor topic" | Skim notes, 2 practice problems |
| 3rd | [Topic name] | Very broad; focus on sub-topic [X] only | Learn sub-topic X only |

**Never sacrifice:** [list topics that are high-weight AND low-confidence — these are non-negotiable]
```

**Sacrifice list rules:**
- Topics that are high-weight AND low-confidence are **never** sacrificed — they get priority.
- Topics that are low-weight AND high-confidence are sacrificed first.
- If the exam has known weight distributions (e.g., "Unit 3 is 40% of the exam"), use those weights to guide sacrifices.
- A "sacrificed" topic still gets a minimum 15-minute review — never completely ignored.

### Output Format

**Default:** Clean, well-structured markdown with checkboxes. Group by phase and day.

**If the student wants to print or save to phone:**
- Deliver as a `.docx` file if document tools are available.
- Use clear headers for each phase and day.
- Bold the current day's tasks for quick scanning.
- Include the sacrifice list and exam logistics as appendix sections.
- Add page breaks between phases if multi-page.

### Printable Checklist Quality Check

Before delivering, verify:

- [ ] Every task is check-off-able — a student can mark it complete without interpretation
- [ ] No vague tasks like "Study Chapter 5" — all tasks specify the exact action and source
- [ ] Tasks are assigned to specific days with time estimates
- [ ] Confidence ratings drive the order (weakest topics first)
- [ ] The sacrifice list exists and is ranked
- [ ] Exam format strategy matches the actual test format
- [ ] Exam logistics checklist is complete and personalized
- [ ] The consolidation phase enforces "no new material"
- [ ] Error-pattern analysis template is included for practice phase
- [ ] Total scheduled hours fit within the student's stated availability (never exceed 90% of available time)

## Key Principles

- **Specific tasks only.** "Complete p. 120 problems #1-10, check answers" works. "Study genetics" does not.
- **Inventory before everything.** Never start building day-by-day tasks until the full topic list and confidence ratings are complete.
- **Weakest topics first.** The Learning Phase always begins with confidence 1 topics, then 2, then 3. Never start with a strong topic.
- **80% accuracy target.** The Practice Phase continues until practice exam scores hit 80%+ or the student runs out of days.
- **Never new material the day before.** The Consolidation Phase is light review, logistics, and sleep only.
- **Sacrifice list is mandatory.** Every checklist must include a ranked sacrifice list for time-crunched scenarios.
- **Never schedule more than 90% of available time.** Leave buffer for slippage, hard problems, and life.
- **Error-pattern analysis beats "review mistakes."** Students categorize every error by type and root cause so patterns emerge.
- **Logistics are part of prep.** A prepared student who forgets their calculator loses points. The logistics checklist prevents this.
- **The checklist is a literal checklist.** The student should print it and check boxes off. Design for that use case.

## Example: Complete Checklist Snippet

Below is a partial example showing what a complete Phase 2 day looks like for a student with 10 days until an AP Biology exam.

```
## Exam Prep Checklist — AP Biology Final — Maya Chen

**Exam Date:** Friday, May 17 at 8:00am | **Days Until:** 10
**Format:** Mixed — 60 multiple choice (90 min), 2 essays (60 min)

---

### INVENTORY PHASE — Complete by: Monday, May 6

| # | Topic | Confidence | Priority |
|---|-------|-----------|----------|
| 1 | Protein synthesis — transcription & translation | 1 | High |
| 2 | DNA replication — enzymes & error correction | 2 | High |
| 3 | Genetics — Punnett squares, pedigrees, probability | 2 | High |
| 4 | Biotechnology — gel electrophoresis, PCR, cloning | 3 | Medium |
| 5 | Cell division — mitosis & meiosis comparison | 4 | Low |

---

### LEARNING PHASE — May 7-11 (Days 10-6)

#### Tuesday, May 7 (Day 10)
- [ ] AP Bio: Protein synthesis — re-read class notes + textbook p. 312-320 — 45 min
- [ ] AP Bio: Protein synthesis — watch Amoeba Sisters "Protein Synthesis" video — 10 min
- [ ] AP Bio: Protein synthesis — complete worksheet "Transcription & Translation Practice" problems #1-8 — 30 min
- [ ] AP Bio: Protein synthesis — check answers, log mistakes in error log — 15 min
- [ ] AP Bio: Protein synthesis — re-do missed problems without looking — 15 min
- [ ] **BREAK — 10 min**
- [ ] AP Bio: DNA replication — re-read notes + textbook p. 289-298 — 35 min
- [ ] AP Bio: DNA replication — draw enzyme diagram from memory, check against notes — 15 min
- [ ] AP Bio: DNA replication — complete textbook problems p. 299 #5, 7, 9, 11, 13 — 25 min

#### Wednesday, May 8 (Day 9)
- [ ] AP Bio: DNA replication — check yesterday's answers, log mistakes — 15 min
- [ ] AP Bio: DNA replication — re-do missed problems independently — 15 min
- [ ] AP Bio: Genetics — re-read notes on Punnett squares + probability rules — 30 min
- [ ] AP Bio: Genetics — complete practice problems: monohybrid #1-4, dihybrid #5-8 — 30 min
- [ ] AP Bio: Genetics — check answers, log mistakes — 15 min
- [ ] **BREAK — 10 min**
- [ ] AP Bio: Genetics — pedigree analysis practice worksheet #1-3 — 20 min
- [ ] AP Bio: Protein synthesis — quick review: re-do yesterday's hardest problem — 10 min

#### Thursday, May 9 (Day 8)
- [ ] AP Bio: Genetics — re-do all missed Punnett & pedigree problems — 20 min
- [ ] AP Bio: Biotechnology — re-read notes on gel electrophoresis, PCR, cloning — 30 min
- [ ] AP Bio: Biotechnology — draw process flowcharts for PCR and gel electrophoresis — 20 min
- [ ] AP Bio: Biotechnology — complete practice problems p. 340-341 #2, 4, 6, 8, 10 — 25 min
- [ ] AP Bio: Biotechnology — check answers, log mistakes — 15 min
- [ ] **BREAK — 10 min**
- [ ] AP Bio: Cell division — quick review: mitosis vs meiosis comparison chart — 20 min
- [ ] AP Bio: Full mixed review — 10 MC questions from Ch 12-16 — 15 min

---

### PRACTICE PHASE — May 12-15 (Days 5-2)

#### Sunday, May 12 (Day 5)
- [ ] Full timed practice: 2019 AP Bio released exam, Section I (MC only) — 90 min
- [ ] Grade answers, record score: ___ / 60 — 15 min
- [ ] Error-pattern analysis: log all misses in error log table — 20 min
- [ ] Re-do all missed MC problems without looking at answers — 30 min

#### Monday, May 13 (Day 4)
- [ ] Full timed practice: 2021 AP Bio released exam, Section I (MC only) — 90 min
- [ ] Grade answers, record score: ___ / 60 — 15 min
- [ ] Review error log from Sunday — re-do any problems still missed — 20 min
- [ ] Focused weak-area drill: 15 protein synthesis + DNA replication MC questions — 25 min

#### Tuesday, May 14 (Day 3)
- [ ] Timed essay practice: 2 released AP Bio essay prompts — 60 min
- [ ] Self-grade using official rubric, note missing elements — 15 min
- [ ] Mixed review: 20 MC questions from highest-priority topics — 25 min
- [ ] Review all accumulated errors one final time — 15 min
- [ ] Verify target: latest MC practice score ___% (target: 80%+)

---

### CONSOLIDATION PHASE — Thursday, May 16 (Day 1)

#### Morning
- [ ] Quick review: flashcards for enzyme names and biotech vocab — 20 min
- [ ] Review error log ONE final time — 15 min
- [ ] No new problems. No new topics.

#### Afternoon / Evening
- [ ] Prepare exam materials (see logistics) — 10 min
- [ ] Set out clothes, pack bag, set two alarms — 10 min
- [ ] Light dinner — 6:30pm
- [ ] No caffeine after 4:00pm
- [ ] In bed by 10:00pm

---

### EXAM DAY — Friday, May 17

- [ ] Wake up 7:00am, quick formula sheet skim — 15 min
- [ ] Protein-rich breakfast — eggs, toast, fruit
- [ ] Arrive at exam location by 7:45am
- [ ] **EXAM: 8:00am**

---

### EXAM FORMAT STRATEGY — Mixed (MC + Essay)

**Multiple Choice:**
- Cover choices, read question first, eliminate wrong answers
- Flag uncertain questions, return after finishing all
- Watch for "all of the above" / "none of the above"
- Pace check: should be at question 30 by the 45-minute mark

**Essay:**
- Read both prompts first, start with stronger prompt
- 5-minute outline before writing: thesis + 2-3 body points
- Allocate 30 minutes per essay — set a mental timer
- Leave 5 minutes to proofread both essays
- Use vocabulary from the prompt in responses

---

### EXAM LOGISTICS CHECKLIST

**What to Bring:**
- [ ] 3 sharpened #2 pencils
- [ ] 2 blue/black pens for essays
- [ ] Calculator with fresh batteries (tested last night)
- [ ] Student ID
- [ ] Watch (non-smart)
- [ ] Clear water bottle
- [ ] Tissues

**What to Know:**
- [ ] Location: Room 204, Science Building
- [ ] Arrive by: 7:45am
- [ ] Duration: 3 hours total
- [ ] Closed book, no notes

---

### SACRIFICE LIST — If Time Runs Short

| Cut Order | Topic | Reason | Minimum Still Do |
|-----------|-------|--------|------------------|
| 1st | Biotechnology | Teacher said "~10% of exam" | 15-min flashcard review |
| 2nd | Cell division details | Confidence 4 — just quick refresh | Skim comparison chart |

**NEVER sacrifice:** Protein synthesis (high weight + confidence 1), Genetics (high weight + confidence 2)
```
