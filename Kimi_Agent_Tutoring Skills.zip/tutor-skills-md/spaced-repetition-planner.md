---
name: spaced-repetition-planner
description: Use after teaching any new concept or unit, when a student forgets material they previously seemed to know, at the start of exam prep to schedule review of all course material, or when building a long-term retention plan for cumulative subjects (math, science, language learning). Creates a calendar-style review schedule with expanding intervals to combat the forgetting curve, batches topics into efficient sessions, adapts to confidence ratings, and produces both a day-by-day calendar and a living topic index.
---

# Spaced-Repetition Planner

Turn "we covered this, let's move on" into "we covered this, we'll review it strategically so it sticks." This skill builds a calendar-based review schedule that spaces review sessions at expanding intervals to move concepts from short-term into long-term memory. It batches topics into efficient 20-30 minute sessions, adapts to each topic's confidence level, and produces a living document the student updates after every review.

## Workflow Overview

1. **Collect topic inventory** — Gather every topic or concept that needs scheduled review.
2. **Build the spacing schedule** — Calculate review dates using expanding intervals, adjusted for confidence.
3. **Batch into sessions** — Group topics into 20-30 minute review sessions of 3-5 topics each.
4. **Produce the calendar and topic index** — Output a day-by-day calendar table and a master topic tracker.
5. **Explain the living updates** — Teach the student how to update confidence and adjust future intervals after each review.

## Step 1 — Collect Topic Inventory

Ask the student (or extract from context) the following for every topic/concept to be scheduled:

| Field | Description | Example |
|-------|-------------|---------|
| **Topic name** | Short, specific label | "Mitosis vs. Meiosis" |
| **Date learned** | Day the concept was first taught/solid | 2025-03-10 |
| **Confidence** | Self-rated 1-5 after initial learning (5 = could teach it) | 3 |
| **Source** | Where to find review material — page numbers, notes file, flashcard deck name | Bio ch.7 pp.142-148; **Deck: "Cell-Division-Flashcards"** |
| **Review time** | Estimated minutes for one review pass (5-15 min typical) | 8 min |

**If using the worksheet-n-flashcards skill previously:** Reference the exact flashcard deck names in the Source column. This links the two skills — the student knows which deck to study on which day.

**If scheduling for exam prep:** Collect *all* course topics at once. The planner will spread them across the available weeks.

**If a student forgot previously known material:** Add that topic to the inventory with today's date and a confidence of 2 (forced re-learn).

## Step 2 — Build the Spacing Schedule

For each topic, calculate review dates using this expanding-interval formula:

| Review | Interval | Days after *initial learning* | Cumulative days |
|--------|----------|-------------------------------|-----------------|
| R1 | 1 day after learning | +1 | 1 |
| R2 | 3 days after R1 | +4 | 4 |
| R3 | 7 days after R2 | +11 | 11 |
| R4 | 14 days after R3 | +25 | 25 |
| R5 | 30 days after R4 | +55 | 55 |
| Maintenance | 30 days after R5 | +85 | 85 |

**Adjust ±1 day for scheduling convenience** — e.g., if R1 falls on a day the student has a known conflict, shift it one day earlier or later. Document any shift.

**Confidence decay alerts — add extra early reviews for low-confidence topics:**

| Initial Confidence | Extra Reviews | Placement | Example |
|--------------------|---------------|-----------|---------|
| 4-5 | None | Standard schedule | — |
| 3 | +1 extra review | Between R1 and R2 (call it R1.5, ~2 days after R1) | R1 → R1.5 → R2 → R3... |
| 1-2 | +2 extra reviews | Add R1.5 (~2 days after R1) and R2.5 (~2 days after R2) | R1 → R1.5 → R2 → R2.5 → R3... |

Label extra reviews clearly (e.g., "R1.5 — Mitosis vs. Meiosis (low confidence extra)").

**Example schedule for a single topic learned on March 10:**

- Topic: "Mitosis vs. Meiosis" | Confidence: 3 | Source: Bio ch.7 + Deck: "Cell-Division-Flashcards" | Time: 8 min
- R1: March 11 (R1.5: March 13 extra due to confidence 3)
- R2: March 14
- R3: March 21
- R4: April 4
- R5: May 4

## Step 3 — Batch Topics into Sessions

**Never schedule one topic alone** — context switching between 3-5 related (or even unrelated) topics in a single 20-30 minute session is more efficient than one topic at a time.

**Batching rules:**

- **Target 3-5 topics per session** (20-30 minutes total).
- **Total time per session must not exceed 30 minutes.** If the sum exceeds 30 min, move the lowest-confidence topic to an adjacent day.
- **Prefer same-subject topics** in a session when possible (e.g., math topics together, vocab topics together).
- **If topics from different subjects must share a day**, group by confidence level — high-confidence topics can be paired with low-confidence ones since the high-confidence reviews are faster.
- **If two topics land on the same day and time is short**, the **lower-confidence topic takes priority** — move the higher-confidence topic to the next available day.

**Conflict resolution example:**

> March 14 has 4 topics scheduled but student only has 20 minutes:
> - "Mitosis vs. Meiosis" (conf 3, 8 min) ← KEEP
> - "Photosynthesis stages" (conf 2, 10 min) ← KEEP
> - "Cell organelles" (conf 4, 5 min) ← MOVE to March 15
> - "DNA replication" (conf 5, 6 min) ← MOVE to March 15
>
> Result: March 14 = 2 topics, 18 min. March 15 absorbs the overflow.

## Step 4 — Produce the Calendar and Topic Index

**Output A: Calendar Table**

Present a running day-by-day calendar. Group by week for readability.

```
## Review Calendar — Biology Unit 3

### Week of March 10-16
| Date | Day | Topics to Review | Time | Source | Done? |
|------|-----|------------------|------|--------|-------|
| Mon 3/10 | — | *Initial learning day — Mitosis vs. Meiosis, Photosynthesis stages, Cell organelles, DNA replication* | — | — | — |
| Tue 3/11 | R1 | Mitosis vs. Meiosis; Cell organelles | 13 min | Bio ch.7 pp.142-148 + Deck "Cell-Division-Flashcards"; Bio ch.6 pp.120-125 | [ ] |
| Wed 3/12 | R1 | Photosynthesis stages; DNA replication | 16 min | Bio ch.8 pp.156-162 + Deck "Photosynthesis-Flashcards"; Bio ch.9 pp.170-175 | [ ] |
| Thu 3/13 | R1.5 | Mitosis vs. Meiosis *(extra — low confidence)* | 8 min | Bio ch.7 pp.142-148 + Deck "Cell-Division-Flashcards" | [ ] |
| Fri 3/14 | R2 | Mitosis vs. Meiosis; Photosynthesis stages | 18 min | [sources above] | [ ] |
| Sat 3/15 | — | *Rest day or overflow: Cell organelles; DNA replication* | 11 min | [sources above] | [ ] |
| Sun 3/16 | — | *Rest day* | — | — | — |

### Week of March 17-23
| Date | Day | Topics to Review | Time | Source | Done? |
|------|-----|------------------|------|--------|-------|
| Fri 3/21 | R3 | Mitosis vs. Meiosis; Photosynthesis stages; Cell organelles; DNA replication | 29 min | [all sources] | [ ] |
```

**Output B: Topic Index**

A master list of every topic being tracked. This is the "living" part — the student updates this after each review.

```
## Topic Index

| # | Topic | Learned | Confidence | Next Review | Status | Source |
|---|-------|---------|------------|-------------|--------|--------|
| 1 | Mitosis vs. Meiosis | 3/10 | 3 → ? | 3/11 (R1) | Scheduled | Bio ch.7 pp.142-148 + Deck "Cell-Division-Flashcards" |
| 2 | Photosynthesis stages | 3/10 | 2 → ? | 3/12 (R1) | Scheduled | Bio ch.8 pp.156-162 + Deck "Photosynthesis-Flashcards" |
| 3 | Cell organelles | 3/10 | 4 → ? | 3/11 (R1) | Scheduled | Bio ch.6 pp.120-125 |
| 4 | DNA replication | 3/10 | 5 → ? | 3/12 (R1) | Scheduled | Bio ch.9 pp.170-175 |
```

**Status options:** Scheduled | Reviewed — confidence up | Reviewed — confidence stable | Reviewed — confidence dropped | Mastery reached | Overdue

## Step 5 — Explain Living Updates

After each review session, the student (or tutor) updates the Topic Index using these rules:

**Post-review confidence update:**

| New Confidence | Action | Next Interval |
|----------------|--------|---------------|
| 4-5 (strong) | Extend next interval by 50% | If next was R3 in 7 days → make it 10-11 days |
| 3 (okay) | Keep standard interval | No change |
| 1-2 (weak) | **Reset to R1** — start the sequence over | Next review in 1 day |

**Update workflow (takes <1 minute):**

1. After reviewing a topic, rate confidence 1-5.
2. Update the Topic Index: new confidence in the Confidence column, recalculate next review date, update Status.
3. If any next-review date changed, update the Calendar table to reflect the new date.
4. If a topic was reset to R1, schedule it within 1 day and re-balance sessions as needed.

**Example update:**

> After R1 on 3/11: "Mitosis vs. Meiosis" rated 5 (up from 3).
> - Confidence column: `3 → 5`
> - Status: `Reviewed — confidence up`
> - Next review was R2 on 3/14 (3 days after R1). With 50% extension: R2 moves to 3/16 (4-5 days after R1).
> - Update Calendar: move this topic from 3/14 to 3/16, re-batch if needed.

## Key Principles

- **Batching is mandatory.** Never schedule a session with fewer than 3 topics or more than 30 minutes. Single-topic sessions are inefficient.
- **Confidence drives the schedule.** Low-confidence topics get extra early reviews; high-confidence topics earn extended intervals. The schedule adapts to the student, not the other way around.
- **±1 day flexibility is allowed.** Shift reviews by one day to avoid conflicts, but document the shift. Do not shift by more than 1 day — it breaks the spacing effect.
- **Priority goes to the struggling material.** When conflicts force a choice, the lower-confidence topic stays and the higher-confidence topic moves.
- **The Topic Index is the source of truth.** The calendar is a view *derived from* the index. If they diverge, the index wins.
- **Link to flashcards explicitly.** When worksheet-n-flashcards decks exist, put the deck name in the Source column so the student knows exactly what to study.
- **Keep it under 5 minutes of interaction.** Collect inventory quickly, compute dates, output the calendar and index, explain the update rules. Do not over-engineer.

## Theming / Branding

- **Tone:** Practical, encouraging, no guilt. Frame forgotten material as a scheduling problem, not a student problem.
- **Calendar presentation:** Use markdown tables. Group by week. Include checkboxes `[ ]` for Done — students find physical check-offs motivating.
- **Color cues (if rendering in HTML or rich format):** Green for high-confidence topics, yellow for medium, red for low. Overdue items in bold red.
- **Naming:** Use "Review" not "Study." Studying implies new learning; reviewing implies reinforcement. This small word choice reduces student anxiety.
