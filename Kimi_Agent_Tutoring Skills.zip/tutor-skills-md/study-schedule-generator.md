---
name: study-schedule-generator
description: Use when a student is overwhelmed by workload, preparing for exams, starting a new term, or needs help building consistent study habits. Also use after any session where the tutor assigns substantial homework or review. This skill produces a structured weekly study schedule that balances all subjects, assignments, and extracurricular commitments into clear, time-blocked calendars the student can realistically follow. Output formats include a repeating weekly template, a day-by-day exam cram schedule, and an assignment-driven work-backwards schedule.
---

# Study Schedule Generator

Build a realistic, time-blocked study schedule tailored to the student's full life — not just their classes. The schedule must respect their energy patterns, leave breathing room, and specify concrete tasks for every block so the student knows exactly what to do and when.

## Workflow Overview

1. **Gather inputs** — Collect the student's full academic and personal load.
2. **Choose a schedule type** — Match the format to the student's immediate need.
3. **Draft the schedule** — Map every block with subject, duration, specific task, and location/materials.
4. **Reality check** — Have the student rate feasibility; revise if below 7/10.
5. **Deliver and print prep** — Format as markdown table or .docx, optimized for phone screenshot or print.

## Step 1 — Gather Inputs

Collect all of the following before drafting. Use a conversational checklist; do not start building until you have answers.

| Category | What to Ask | Example Answer |
|----------|-------------|----------------|
| **Classes & Grades** | List every subject and current grade | Math B-, Chemistry C+, English A, History B |
| **Upcoming Assignments** | Name, subject, due date, estimated effort | Chem lab report — 3 days — 4 hrs; History essay — 5 days — 6 hrs |
| **Upcoming Tests/Quizzes** | Subject, date, topics covered | Chem unit test — Mar 8 — Ch 4-6; Math quiz — Mar 6 — factoring |
| **Extracurriculars** | Activity, days/times committed | Soccer practice Mon/Wed/Fri 3:30-5:30; Part-time job Sat 10-4 |
| **Preferred Study Times** | When does the student feel sharpest? | "I'm dead before 10am; best after dinner" |
| **Problem Areas** | Which subjects need the most time blocks? | Chemistry (struggling with stoichiometry), Math (word problems) |
| **Non-Negotiables** | Fixed obligations that cannot move | Church Sunday 9-12; family dinner daily 6-7pm |

**Circadian preference rule:**
- **Morning person** → Front-load hard subjects (Math, Chemistry) before noon. Reserve afternoons for lighter review.
- **Night owl** → Place heavy subjects after dinner. Use morning blocks for light reading or review.
- **Neither / varies** → Put hardest subject at the student's stated "best window," even if that's mid-afternoon.

## Step 2 — Choose Schedule Type

Select the format that matches the student's situation. Explain the choice briefly.

| Type | Best For | Structure |
|------|----------|-----------|
| **Weekly Template** | Building long-term routines; stable workload | Repeating week with fixed subject blocks (e.g., "Math: Mon/Wed 4-5pm") |
| **Cram / Exam Schedule** | Test prep with a hard deadline | Day-by-day countdown; specific topics per block; includes review days |
| **Assignment-Driven Schedule** | Poor time estimation; many looming deadlines | Work backwards from due dates; break each assignment into sub-tasks with mini-deadlines |

If a student has both exams *and* routine coursework, produce a **Cram/Exam Schedule** that sits on top of a reduced Weekly Template (e.g., "during exam week, follow the cram schedule; return to weekly template after").

## Step 3 — Draft the Schedule

### Capacity Rule
**Never schedule 100% of available study time. Default to 75% capacity.**

If a student has 20 hours of available study time per week, schedule only 15 hours of focused blocks. The remaining 25% is buffer for slow days, unexpected assignments, and recovery.

### Time Block Format

Every block must include all four elements:

```
[Subject/Topic] — [Duration] — [Specific Task] — [Location/Materials]
```

**Bad example:** `Math — 1 hr — study math — desk`

**Good example:** `Math — 1 hr — complete p. 45-47 problems #1-15 odd, check answers in back — desk, textbook, calculator, answer key`

### Subject Rotation Rules
- **Never schedule the same hard subject back-to-back.** Alternate demanding subjects with lighter ones (e.g., Math → English reading → Chemistry → flashcard review).
- **Max 2 hours per single subject per day** for Weekly Templates. Exception: Cram schedules may go to 3 hours with a mandatory 10-min break every 50 minutes.
- **Problem areas get more frequent, shorter blocks** rather than fewer marathon sessions. A struggling Chemistry student gets 45 min × 4 days, not 3 hours × 1 day.

### Sample Weekly Template

```
## Weekly Study Schedule — Alex

| Time Block | Monday | Tuesday | Wednesday | Thursday | Friday | Saturday | Sunday |
|------------|--------|---------|-----------|----------|--------|----------|--------|
| 7:00-7:30am | — | — | — | — | — | — | — |
| 4:00-4:45pm | Math: factoring review, p.112 #5-25 odd — desk, calculator | Chemistry: stoichiometry practice problems — desk, notes | Math: word problems, worksheet packet — desk | Chemistry: lab prep read Ch5.3 — desk, textbook | **Light day** — flashcard review only | History: essay outline draft — library, laptop | **Buffer / rest** |
| 5:00-5:45pm | — | History: read Ch8, take notes — couch, textbook, notebook | — | History: read Ch9, take notes — couch, textbook, notebook | — | — | Plan next week / tidy notes — 20 min |
| 7:30-8:15pm | Chemistry: flashcards — Anki, phone | Math: review today's mistakes — desk, red pen | Chemistry: lab report draft — laptop, Google Docs | Math: mixed review worksheet — desk | **Free** | **Free** | **Free** |
| 8:15-8:30pm | — | — | — | — | — | — | — |

**Non-negotiables:** Soccer practice M/W/F 3:30-5:00pm | Family dinner daily 6:00-7:00pm | Church Sunday 9:00-12:00pm
**Buffer built in:** Friday evening, all of Sunday afternoon/evening, Saturday after 5pm
```

### Sample Cram / Exam Schedule

```
## Chemistry Unit Test — 5-Day Countdown (Test: Friday, Mar 8)

| Day | Morning Block | Afternoon Block | Evening Block | Notes |
|-----|---------------|-----------------|---------------|-------|
| **Mon Mar 4** | — | Ch 4 review: redo missed quiz problems — 1 hr — desk, notes, red pen | Ch 5 review: stoichiometry limiting reactant problems — 1 hr — desk, worksheet | Start with weakest chapters |
| **Tue Mar 5** | Ch 6 review: thermochemistry calorimetry problems — 45 min — desk, calculator | Mixed Ch 4-5 practice test — 1 hr — timed, desk only | Grade practice test, log mistakes — 30 min — red pen | Simulate test conditions |
| **Wed Mar 6** | Review Monday's mistakes — 30 min | Ch 6 deep dive: thermo equations & sign conventions — 1 hr — desk, formula sheet | Mixed Ch 5-6 practice test — 1 hr — timed | |
| **Thu Mar 7** | **Light review only:** flashcards & formula sheet — 30 min | Review all logged mistakes one final time — 45 min | **No studying after 8pm** — sleep is part of prep | Early bedtime |
| **Fri Mar 8** | **TEST DAY** — quick formula sheet skim only — 15 min | — | — | |
```

**Cram schedule rules:**
- Always include a "review mistakes" day (typically the day before the final light-review day).
- The day before the exam is lighter than the days before it.
- Never schedule new material learning on the final day.

### Sample Assignment-Driven Schedule

```
## History Essay — "Causes of WWI" — Due Friday, Mar 15

| Sub-Task | Mini-Deadline | Scheduled Block | Duration |
|----------|---------------|-----------------|----------|
| Research: find & save 4 sources + notes | Mon Mar 11 | Mon 4:00-5:30pm | 1.5 hrs |
| Outline: thesis + 3 body paragraph claims | Tue Mar 12 | Tue 7:00-7:45pm | 45 min |
| Draft body paragraph 1 | Wed Mar 13 | Wed 4:00-4:45pm | 45 min |
| Draft body paragraphs 2 & 3 | Thu Mar 14 | Thu 4:00-5:15pm | 1.25 hrs |
| Intro + conclusion draft | Thu Mar 14 | Thu 7:00-7:30pm | 30 min |
| Full edit + Works Cited | Fri Mar 15 | Fri 7:00-7:45am | 45 min |
| **Buffer** | — | Built into Fri morning slot | 30 min |
```

**Assignment-driven rules:**
- Work backwards from the due date.
- Break every assignment into 3-7 sub-tasks. No sub-task should exceed 90 minutes.
- Each sub-task gets its own mini-deadline, at least 24 hours before the final due date.
- Always leave a buffer block between the final sub-task and the deadline.

## Step 4 — Reality Check

Before finalizing, present the draft schedule and ask:

> **"On a scale of 1-10, how realistic is this for you? 1 = I'd ignore it by Wednesday. 10 = I could actually do this."**

| Rating | Action |
|--------|--------|
| **8-10** | Proceed to delivery. |
| **6-7** | Ask what feels tight. Reduce one block or move a non-negotiable. Re-check. |
| **1-5** | Major revision needed. Revisit Step 1 — you likely underestimated extracurricular load or overestimated available time. Cut at least one subject block or extend an assignment deadline. |

Do not skip this step. A schedule the student believes is impossible will not be used.

## Step 5 — Deliver and Format

### Output Format Rules

**Default:** Clean markdown table (works in any chat, easy to copy-paste).

**If the student wants to print or save to phone:**
- Deliver as a `.docx` file if document tools are available.
- Use a single-page or two-page layout with clear headers.
- Bold the time column and the current day column for quick scanning.
- Include non-negotiables and buffer notes at the bottom.

### Print / Phone-Screenshot Checklist

- [ ] Can the student read it at a glance without scrolling horizontally?
- [ ] Are time blocks ordered chronologically (top = morning, bottom = night)?
- [ ] Is the current day visually findable (bold, highlighted, or column-separated)?
- [ ] Are non-negotiables listed so the student doesn't double-book?
- [ ] Is there a one-line "what to do right now" instruction if they feel lost?

### Quick-Reference Footer

Append this to every schedule:

```
---
**If you get behind:** Skip the current block and jump to the next one. Catch up during buffer time — do not push everything back.
**If you finish early:** Use the remaining time for flashcard review or preview tomorrow's material.
**Stuck on a problem?** Mark it, move on after 10 minutes, ask your tutor next session.
```

## Key Principles

- **Specific tasks beat vague goals.** "Complete p. 45 odd problems" works. "Study math" does not.
- **75% capacity is the ceiling.** A 15-hour schedule beats a 20-hour schedule the student abandons.
- **Respect circadian rhythm.** Hard subjects go in the student's peak window, never in their dead zone.
- **Buffer is sacred.** Do not fill buffer time with "optional" tasks. It exists for slippage.
- **Feasibility score below 7 means rewrite.** Never deliver a schedule the student does not believe they can follow.
- **Non-negotiables are immovable.** Build the schedule around them, not through them.
- **Problem areas get frequency, not duration.** Shorter, more frequent blocks build retention better than occasional marathons.
