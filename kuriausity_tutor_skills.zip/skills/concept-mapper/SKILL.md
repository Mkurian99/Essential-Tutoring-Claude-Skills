---
name: concept-mapper
description: Turn material into a concept map that shows how ideas connect, what depends on what, and the order to learn them. Use whenever a tutor or teacher needs a concept map, a knowledge map, a visual of how topics relate, a prerequisite or dependency map, a study map, a "big picture" overview of a unit, or help sequencing what to teach first. Triggers include concept map, mind map, knowledge graph, prerequisite map, "show how these ideas connect," learning sequence, or visualizing a topic's structure. Produces a labeled node-and-edge map (relationships named on the edges) plus a prerequisite-ordered learning sequence, rendered as a themed HTML/SVG diagram.
---

# Concept Map & Knowledge Structure

A list of topics hides the thing that matters most: how the ideas hang together. A concept map makes the structure visible — which ideas are central, which depend on which, and therefore what to teach first. The discipline that separates a real concept map from a decorative bubble diagram is **labeled relationships**: every connection states *how* two ideas relate ("causes," "is a kind of," "requires," "contrasts with"), not just *that* they're near each other. Those labels are where the understanding lives.

## Workflow

1. Read the source (or take the topic) and extract the concepts: the nouns and ideas a student must hold.
2. Identify the relationships between them and label each one. This is the core work.
3. Mark prerequisite edges (A must be understood before B).
4. Decide the layout: hierarchy (general → specific), dependency (prerequisite flow), or hub-and-spoke (one central idea).
5. Derive the learning sequence by ordering along the prerequisite edges.
6. Render the map and the sequence.

## Step 2 — Label every relationship (the heart of this skill)

For each pair of connected concepts, write the linking phrase that makes a proposition: *Concept → [relationship] → Concept*. Read aloud, an edge should be a true sentence.

- "Inflation → *erodes* → purchasing power"
- "Mitochondrion → *is a kind of* → organelle"
- "Common denominator → *is required for* → adding unlike fractions"
- "Necessary condition → *contrasts with* → sufficient condition"

Edges without labels ("inflation —— purchasing power") are the failure mode; they look like a map but assert nothing and teach nothing. If you can't name the relationship, the two concepts probably don't belong connected.

Common relationship types to reach for: is-a-kind-of, is-part-of, causes, requires/depends-on, contrasts-with, is-an-example-of, leads-to, is-measured-by.

## Step 3 — Prerequisite edges and the learning sequence

Mark which edges are *prerequisite* (B can't be understood until A is). The prerequisite subgraph, read in order, is the teaching sequence: start with concepts that depend on nothing, then the concepts those unlock, and so on. This turns the map into a lesson plan. If the prerequisite edges form a cycle, that's a signal two concepts are tangled and should be taught together or split; flag it.

## Step 4 — Layout choice

- **Hierarchy** — for taxonomies and general-to-specific material (biology classifications, parts of an argument). Top-down tree.
- **Dependency** — for skills with prerequisites (math, anything cumulative). Left-to-right or top-down flow along prerequisite edges.
- **Hub-and-spoke** — for one central concept with related facets (a single theme explored from angles). Central node, radial links.

Pick the one that fits the material; don't force a tree onto a web.

## Step 5 — Render

Use the bundled template `assets/concept_map_template.html`. It takes a small JSON describing nodes and labeled edges and renders an EMERALDOPAL-themed interactive diagram (Mermaid under the hood, so it lays out automatically and stays legible). Substitute the placeholders:

- `__TITLE__` — map title
- `__SUBTITLE__` — short scope line
- `__DIRECTION__` — `TD` (top-down) or `LR` (left-right)
- `__GRAPH_BODY__` — Mermaid node/edge lines, e.g.:
  ```
  A["Common denominator"] -->|is required for| B["Adding unlike fractions"]
  B -->|leads to| C["Mixed-number sums"]
  ```

Keep edge labels short (2–4 words); the full relationship can read slightly compressed on the diagram as long as it's still a true link. If Graphviz is preferred for print, emit DOT instead and render to SVG/PNG; the same node/edge data drives either. Always render the **learning sequence** as an ordered list beneath the map, so the structure converts directly into what to teach first.

## Authoring discipline (read this every time)
- **Every edge is labeled.** An unlabeled edge is a bug, not a style choice.
- **Concepts, not sentences, in nodes.** A node is an idea ("opportunity cost"), not a paragraph. The relationship goes on the edge.
- **Don't invent connections for symmetry.** Only draw an edge that names a real relationship. A sparse honest map beats a dense decorative one.
- **No filler labels.** Edge labels are relationships, never "relates to" or "connected to" — those are non-labels. If that's all you can say, reconsider the edge.

## Differentiation
- **Skeleton map for support / note-taking:** render the nodes with several edge labels blanked, so students supply the relationships as a retrieval exercise. The completed map is the answer key.
- **Stretch:** give advanced students the concept list and have them build the map; the map *is* the assessment of whether they see the structure.
- **Visual / big-picture learners:** lead with the map before the linear notes, so the structure frames the details.
- **Executive function:** the prerequisite sequence doubles as a checklist of what to study in what order, which is often the missing piece for students who have the material but no order to attack it in.

## Output
Deliver the rendered map (HTML or SVG/PNG) plus the ordered learning sequence. The sequence is the natural input to `lesson-architect` (teach in prerequisite order) and `spaced-review-planner` (the concepts become the item list).

## Theming
The template defaults to Kuriausity EMERALDOPAL: dark-field, Cormorant Garamond title + Inter labels, opal gradient top rule, emerald/malachite nodes, muted rim edges. Spelling: **Kuriausity**. If the project supplies other brand guidelines, edit the template's color variables rather than rebuilding.
