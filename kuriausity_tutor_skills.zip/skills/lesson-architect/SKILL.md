---
name: lesson-architect
description: Build a single differentiated lesson plan with tiered tasks and built-in accommodations for a mixed group. Use whenever a tutor or teacher needs to plan a session or lesson, structure a class around an objective, prepare a tutoring session agenda, design an activity for students at different levels, or "plan how to actually teach" a topic. Triggers include lesson plan, session plan, unit, teaching plan, "how should I teach X," activity design, or differentiating instruction for varied learners. The plan always specifies an objective, a gradual-release arc, three task tiers (support/core/extension), checks for understanding, and accommodations — not a topic outline.
---

# Differentiated Lesson Architect

A lesson plan is a script for one block of teaching time that says what the student will be able to *do* by the end, how the time is spent getting there, and how the teacher knows it worked. The deliverable is not a list of topics; it is a sequenced plan with a measurable objective, a release of responsibility from teacher to student, three tiers so a mixed group is all productively challenged, and explicit checks so the teacher catches a stall while there's still time to fix it.

## Workflow

1. Pin the objective and the evidence that proves it.
2. Lay out the time and the gradual-release arc.
3. Write the three task tiers.
4. Place the checks for understanding.
5. Add accommodations and the materials list.
6. Render the plan.

## Step 1 — Objective and evidence

Write one objective as: *the student will be able to [observable verb] [content] [to what standard]*. "Understand the causes of WWI" is not an objective; "explain two long-term and one immediate cause of WWI and how they connect, in a written paragraph" is. Pair it with the **evidence**: the specific thing the student produces or does that shows the objective was met. Plan the evidence before the activities, so the activities aim at it.

## Step 2 — The arc (gradual release)

Structure the block as **I do → we do → you do**, with rough minute budgets:

- **Hook / activate (5–10%)** — surface prior knowledge or pose the problem the lesson answers. Not a warm-up worksheet; a question that makes the lesson feel needed.
- **I do — model (15–25%)** — the teacher works an example aloud, narrating the thinking, not just the steps. The reasoning is the part students can't see on their own.
- **We do — guided (25–35%)** — teacher and students work together; the teacher fades support as students take over.
- **You do — independent (25–35%)** — students work the tiered task. This is where differentiation lives.
- **Close (5–10%)** — students articulate what they learned and the teacher collects the evidence (an exit ticket, a one-sentence summary, a worked problem).

State minutes for each, summing to the session length.

## Step 3 — Three task tiers

For the "you do" phase, write the *same* core task at three levels so every student works on the lesson's objective, not a different one:

- **Support** — more scaffolding: a partial worked example, a sentence frame, a reduced problem set, a word bank, the steps listed. Same objective, more support to reach it.
- **Core** — the target task at grade level.
- **Extension** — the same task with the scaffolds removed and a transfer twist: apply it to a new case, justify the method, or handle the edge case. Extension is harder *thinking*, not just *more* problems.

The three tiers must share an objective and a closing artifact so the group can debrief together. Never tier into three unrelated activities; that is three lessons and no shared discussion.

## Step 4 — Checks for understanding

Place at least two quick checks *before* the independent phase, so a misconception is caught before it's practiced. A check is a fast, low-stakes read on whether to proceed: a cold-call question, a thumbs scale, a single whiteboard problem, a "explain it to your partner." For each check, write the **branch**: what to do if most students have it (proceed) and what to do if they don't (reteach the modeled step, slow the guided phase). A plan without branches assumes the lesson goes perfectly, which it won't.

## Step 5 — Accommodations

Add a short accommodations block covering the profiles likely in the room. Make these concrete moves, not labels:

- **Executive function / ADHD** — chunk the independent task into checkpoints; give a visible timer and a single next-step at a time; provide the steps in writing so working memory isn't the bottleneck.
- **ELL** — pre-teach the 3–5 load-bearing terms; provide a sentence frame for the written evidence; pair the new term with a visual or a known cognate.
- **Dyslexia / reading load** — read key text aloud or provide audio; reduce copying; assess the target skill, not decoding speed.
- **2e / advanced** — the extension tier is the floor, not a reward; let them skip practice they've shown mastery of and move to transfer.

## Authoring discipline (read this every time)

- **No promissory or hype language.** The plan describes what *will be attempted and measured*, not "students will love this" or "guaranteed mastery." (Aligns with the firm's no-outcome-promise rule.)
- **No filler.** Cut "engaging," "fun," "genuinely," "in today's classroom." Say what the activity is and why it serves the objective.
- **Em dashes sparingly.** Plans should read as clean instructions.
- **Every activity earns its place.** If a step doesn't move students toward the objective or produce evidence, cut it. No activity for its own sake.

## Step 6 — Output

Render as a one-page (screen) or two-page (print) plan with: objective and evidence at the top; a time-budgeted arc; the three tiers in parallel; the checks with their branches; the accommodations block; and a materials/prep list. Use the `docx` skill for a print plan or HTML for screen. If the lesson needs a practice set, hand the objective to `scaffold-builder`; if it needs a discussion, hand the text to `socratic-ladder`; if it needs an exit ticket, hand the objective to `worksheet-n-flashcards`.

## Theming

Kuriausity EMERALDOPAL: Cormorant Garamond display + Inter body, opal gradient top rule, malachite section labels, dark-field screen / light-field print. Spelling: **Kuriausity**. Defer to project brand guidelines if supplied.
