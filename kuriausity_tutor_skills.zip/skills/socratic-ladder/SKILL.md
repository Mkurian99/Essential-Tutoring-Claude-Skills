---
name: socratic-ladder
description: Turn a text or topic into a tiered question ladder and a facilitation guide for a Socratic discussion or seminar. Use whenever a tutor or teacher needs discussion questions, a seminar plan, a Socratic questioning sequence, questions that move from recall to analysis to evaluation, a reading-discussion guide, or a way to run a thoughtful conversation about a text. Triggers include discussion questions, Socratic seminar, questioning ladder, "questions to ask about this reading," seminar guide, deep questions, or facilitating discussion. Produces a climbing sequence of questions (comprehension to interpretation to evaluation to transfer) with follow-up probes, anticipated responses, and facilitation moves.
---

# Socratic Question Ladder & Seminar Guide

Good discussion questions form a ladder: they start where everyone can get on (what does the text say) and climb to where the thinking happens (what's at stake, is it right, where else does it apply). A flat list of "what did you think?" questions strands the conversation at opinion. This skill builds the ladder for a specific text or topic, with the probes and facilitation moves that keep a real discussion moving and honest. It draws directly on the firm's debate and philosophy strengths: the goal is reasoned exchange, not a quiz with discussion seating.

## The ladder (four rungs)

Build questions at each rung; you need the lower rungs to support the higher ones.

1. **Comprehension** — establish a shared, accurate reading. "What is the author claiming here? What does this term mean in this passage?" A few of these; don't dwell, but don't skip — analysis built on a misreading goes nowhere.
2. **Analysis / interpretation** — examine how and why. "Why does the author put this here? What assumption is this resting on? How do these two passages relate?" This is where the work begins.
3. **Evaluation** — judge the reasoning. "Is the argument sound? What's the strongest objection? Where does it break down? Whose perspective is missing?" Push for warrants, not verdicts.
4. **Transfer / synthesis** — connect outward. "Where else does this apply? How does it change what we said earlier? What would the author say about [a new case]?" This is what makes the discussion stick.

## Workflow

1. Read the text (or take the topic) and identify its central claim, key moves, and pressure points (where it's contestable, ambiguous, or assumes something).
2. Write an **opening question** — one genuine, open question that has no single right answer and that the whole text bears on. The seminar lives or dies on this.
3. Build 2–4 questions per rung, anchored to specific passages or ideas.
4. For each question, write follow-up probes and an anticipated-response note.
5. Add facilitation moves and a closing question.

## What makes the questions work

**Genuinely open at the top, anchored at the bottom.** Comprehension questions have answers in the text; evaluation and transfer questions don't, and the facilitator must not have a "right answer" they're fishing for. If the question has a hidden answer the leader wants, it's not Socratic, it's a guessing game, and students learn to read the leader instead of the text.

**Anchored to evidence.** Every interpretive and evaluative question should be answerable by pointing to the text. "Where do you see that?" is the spine of the method. Build that demand into the questions: "What in the passage supports reading it that way?"

**Probes that deepen, not redirect.** For each main question, supply follow-ups that press the same thread: "What do you mean by that? What's your evidence? What would change your mind? Can you say more?" These keep the class on one idea long enough to get somewhere, instead of collecting six shallow takes.

**Anticipate responses.** For the hard questions, note the likely answers (including the common misreading) and how to push each one further. This is what lets a tutor facilitate in real time instead of nodding.

## Facilitation moves (include in the guide)
- **Wait time.** After a question, silence is the tool, not the enemy; give it 5–10 seconds before rescuing.
- **Redirect to peers.** "What do others think of that?" keeps it a discussion, not a series of teacher-student dyads.
- **Press for warrant.** "What makes you say that?" applied to weak and strong answers alike, so it doesn't read as a gotcha.
- **Steelman.** "What's the best version of the view you disagree with?" — a debate move that raises the level.
- **Park and return.** Note a good tangent and come back to it, rather than chasing or killing it.

## Authoring discipline (read this every time)
- **No leading questions disguised as open ones.** "Don't you think the author is being unfair here?" is not a question; it's a position with a question mark. Ask "Is the author being fair here?" and mean it.
- **Test the text, not its packaging.** Ask about the ideas and argument, never about the document's framing or instructions. (No "how many paragraphs does the author use.")
- **No filler.** Drop "genuinely," "really make you think," "dive deep." A sharp question doesn't need a hype frame.
- **Em dashes sparingly.** Questions should be clean.

## Differentiation
- **Entry points for everyone.** The comprehension rung gives quieter or less-prepared students a real way in; keep two or three accessible questions early.
- **Sentence frames** for ELL and support-tier students: "I think ___ because the text says ___." Lower the language barrier without lowering the thinking.
- **Stretch prompts** for advanced students: assign them the steelman or the missing-perspective question in advance so they come loaded.
- **Written backchannel** for students who think before they speak (and for executive-function or anxious profiles): a one-line written response to the opening question before the talk starts, so speaking isn't the only way to participate.

## Output
Deliver the ladder as a facilitator's guide: opening question up top, the four rungs with their probes and anticipated responses, the facilitation moves, and a closing question. Render via the `docx` skill for a print guide or HTML for screen. Pairs with `text-leveler` (so a mixed group reads the same text at their levels, then discusses together) and `rubric-and-feedback` (a discussion-participation rubric).

## Theming
Kuriausity EMERALDOPAL: Cormorant Garamond + Inter, opal gradient top rule, malachite rung labels, dark-field screen / light-field print. Spelling: **Kuriausity**. Defer to project brand guidelines if supplied.
