#!/usr/bin/env python3
"""Spaced-repetition + interleaving scheduler for the spaced-review-planner skill.

Reads a JSON list of study items (name, topic, confidence) and produces a
dated plan across the available study days between a start date and an exam
date, using expanding review intervals weighted by confidence, interleaving
topics within each session, and reserving a final taper window for mixed
retrieval. Emits CSV and an .ics calendar.

No third-party dependencies (uses only the standard library).
"""
import argparse
import json
import sys
from collections import defaultdict
from datetime import date, datetime, timedelta

# Expanding intervals (in days) by confidence. Shorter/more for shaky items.
INTERVALS = {
    "new":   [0, 1, 3, 7, 14, 30, 60],
    "shaky": [0, 2, 5, 12, 28, 56],
    "solid": [0, 7, 21, 50],
}
WEEKDAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
MINUTES_PER_ITEM = 8  # rough planning estimate per retrieval touch


def parse_days(names):
    idx = {d.lower(): i for i, d in enumerate(WEEKDAYS)}
    out = set()
    for n in names:
        key = n[:3].lower()
        if key in idx:
            out.add(idx[key])
    return out or {0, 1, 2, 3, 4}


def study_days(start, exam, allowed):
    days, d = [], start
    while d <= exam:
        if d.weekday() in allowed:
            days.append(d)
        d += timedelta(days=1)
    return days


def nearest_study_day(target, days):
    """Return the first study day on or after target, else the last one."""
    for d in days:
        if d >= target:
            return d
    return days[-1] if days else target


def build_schedule(items, start, exam, allowed, minutes, taper_days):
    days = study_days(start, exam, allowed)
    if not days:
        raise SystemExit("No study days between start and exam date.")
    cap_items = max(1, minutes // MINUTES_PER_ITEM)
    taper_start = exam - timedelta(days=taper_days)

    # Spread first-touches across early sessions, round-robin by topic for
    # interleaving, then schedule expanding reviews for each touch.
    by_topic = defaultdict(list)
    for it in items:
        by_topic[it.get("topic", "General")].append(it)
    interleaved = []
    topics = list(by_topic)
    i = 0
    while any(by_topic[t] for t in topics):
        t = topics[i % len(topics)]
        if by_topic[t]:
            interleaved.append(by_topic[t].pop(0))
        i += 1

    plan = defaultdict(list)  # date -> list of (item, action)
    # Distribute first touches over the first ~40% of the runway.
    first_window = max(1, int(len(days) * 0.4))
    for n, it in enumerate(interleaved):
        first_day = days[min(n % first_window, len(days) - 1)]
        conf = it.get("confidence", "new").lower()
        intervals = INTERVALS.get(conf, INTERVALS["new"])
        for k, gap in enumerate(intervals):
            target = first_day + timedelta(days=gap)
            if target > exam:
                break
            if target >= taper_start:
                continue  # taper window handled separately
            d = nearest_study_day(target, days)
            action = "learn" if k == 0 else "recall"
            plan[d].append((it["item"], it.get("topic", "General"), action))

    # Taper window: mixed full retrieval of everything, lightly.
    taper = [d for d in days if d >= taper_start]
    if taper:
        for n, it in enumerate(interleaved):
            d = taper[n % len(taper)]
            plan[d].append((it["item"], it.get("topic", "General"), "recall (mixed)"))

    # Flag overloaded days.
    overloaded = {d: len(v) for d, v in plan.items() if len(v) > cap_items}
    return plan, cap_items, overloaded, taper_start


def write_csv(plan, path):
    rows = ["date,weekday,item,topic,action"]
    for d in sorted(plan):
        for item, topic, action in plan[d]:
            rows.append(f"{d.isoformat()},{WEEKDAYS[d.weekday()]},"
                        f"\"{item}\",{topic},{action}")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(rows) + "\n")


def write_ics(plan, path, minutes):
    lines = ["BEGIN:VCALENDAR", "VERSION:2.0",
             "PRODID:-//Kuriausity//Spaced Review//EN"]
    stamp = datetime.now().strftime("%Y%m%dT%H%M%SZ")
    uid = 0
    for d in sorted(plan):
        items = plan[d]
        summary = f"Study ({len(items)} items): " + ", ".join(
            sorted({t for _, t, _ in items}))
        desc = "\\n".join(f"{a}: {i}" for i, _, a in items)
        uid += 1
        lines += [
            "BEGIN:VEVENT",
            f"UID:kuriausity-{d.isoformat()}-{uid}@local",
            f"DTSTAMP:{stamp}",
            f"DTSTART;VALUE=DATE:{d.strftime('%Y%m%d')}",
            f"DTEND;VALUE=DATE:{(d + timedelta(days=1)).strftime('%Y%m%d')}",
            f"SUMMARY:{summary}",
            f"DESCRIPTION:Recall before checking.\\n{desc}",
            "END:VEVENT",
        ]
    lines.append("END:VCALENDAR")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\r\n".join(lines) + "\r\n")


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("items", help="JSON list of {item, topic, confidence}")
    ap.add_argument("--start", required=True, help="YYYY-MM-DD")
    ap.add_argument("--exam", required=True, help="YYYY-MM-DD target date")
    ap.add_argument("--days", nargs="+", default=["Mon", "Tue", "Wed", "Thu", "Fri"],
                    help="study weekdays, e.g. Mon Wed Fri")
    ap.add_argument("--minutes", type=int, default=45, help="minutes per session")
    ap.add_argument("--taper-days", type=int, default=7,
                    help="length of final mixed-retrieval window")
    ap.add_argument("--out-csv", default="plan.csv")
    ap.add_argument("--out-ics", default="plan.ics")
    a = ap.parse_args()

    with open(a.items, encoding="utf-8") as f:
        items = json.load(f)
    start = date.fromisoformat(a.start)
    exam = date.fromisoformat(a.exam)
    if exam <= start:
        sys.exit("Exam date must be after start date.")

    plan, cap, overloaded, taper_start = build_schedule(
        items, start, exam, parse_days(a.days), a.minutes, a.taper_days)
    write_csv(plan, a.out_csv)
    write_ics(plan, a.out_ics, a.minutes)

    n_days = len(plan)
    n_touches = sum(len(v) for v in plan.values())
    print(f"Scheduled {len(items)} items across {n_days} sessions "
          f"({n_touches} retrieval touches).")
    print(f"Session cap ~{cap} items ({a.minutes} min @ {MINUTES_PER_ITEM} min/item).")
    print(f"Taper (mixed retrieval) begins {taper_start.isoformat()}.")
    if overloaded:
        print(f"WARNING: {len(overloaded)} day(s) exceed the cap. "
              "Add a study day, raise --minutes, or mark more items 'solid':")
        for d in sorted(overloaded):
            print(f"  {d.isoformat()} ({WEEKDAYS[d.weekday()]}): "
                  f"{overloaded[d]} items")
    print(f"Wrote {a.out_csv} and {a.out_ics}.")


if __name__ == "__main__":
    main()
