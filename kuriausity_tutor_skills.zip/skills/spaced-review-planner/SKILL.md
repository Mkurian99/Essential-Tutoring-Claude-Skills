---
name: spaced-review-planner
description: Turn a set of topics, terms, or flashcards into an evidence-based spaced-repetition and interleaving schedule with real calendar dates, sized to a target date. Use whenever a student or tutor needs a study schedule, review plan, "how do I not forget this," a plan to cram less and retain more, a revision timetable before an exam (LSAT, SAT, ACT, AP, bar, finals), or a way to space out and interleave practice across weeks. Triggers include spaced repetition, review schedule, study plan, retention, "spread this out," interleaving, or scheduling practice toward a deadline. Comes with a scheduler script that emits a dated plan as CSV and calendar (.ics).
---

# Spaced Review & Retrieval Planner

Massed practice (cramming) produces fast forgetting; spaced, interleaved retrieval produces durable memory. This skill takes what a student must learn and lays it across the calendar so each item is reviewed at expanding intervals, different topics are interleaved rather than blocked, and the load is heaviest early and lighter near the exam. The deliverable is a dated plan a student can actually follow, not advice to "review regularly."

## The principles this encodes

- **Spacing.** Review an item at expanding gaps (for example 1, 3, 7, 16, 35 days) rather than back to back. Each successful recall at a longer gap strengthens retention more than a massed repeat.
- **Retrieval, not review.** "Review" means *try to recall, then check* — closed-book self-testing — not rereading. Schedule recall attempts, not passive passes.
- **Interleaving.** Mix topics within a session rather than finishing one before starting the next. Interleaving feels harder and produces better discrimination and transfer. The schedule deliberately alternates topics.
- **Difficulty-weighting.** Hard or shaky items get shorter initial intervals and more repetitions; mastered items get long intervals. The plan takes a confidence rating per item and spaces accordingly.
- **Taper to the date.** Front-load new learning; reserve the last stretch for mixed full-difficulty retrieval and gap-patching, not new material.

## Workflow

1. Collect the item set (topics, terms, or a flashcard list) and a confidence rating for each (new / shaky / solid), plus the start date and the target/exam date.
2. Decide session cadence (days per week, minutes per session).
3. Run the scheduler to assign each item's review dates by expanding intervals, interleaved across sessions and capped at the target date.
4. Review the plan for load balance and adjust intervals or cadence if days are overloaded.
5. Deliver the dated plan plus a short "how to use it" note (retrieval, not rereading).

## Step 1 — Build the item list

Each item needs a name, a topic/category (for interleaving), and a confidence rating:

```json
[
  {"item": "RC main-point questions", "topic": "Reading", "confidence": "shaky"},
  {"item": "Necessary vs sufficient", "topic": "LogicalReasoning", "confidence": "new"},
  {"item": "Conditional chains", "topic": "LogicGames", "confidence": "solid"}
]
```

If the source is a flashcard deck or a worksheet's term list, lift the items from there; pair this skill with `worksheet-n-flashcards`, whose deck is the natural input.

## Step 2 — Run the scheduler

```bash
python scripts/schedule.py items.json \
  --start 2026-06-08 --exam 2026-08-15 \
  --days Mon Tue Wed Thu Fri --minutes 45 \
  --out-csv plan.csv --out-ics plan.ics
```

The scheduler assigns each item a first touch, then expanding-interval reviews (shorter for "new"/"shaky," longer for "solid"), interleaves topics so no session is single-topic, stops scheduling new intervals past the exam date, and reserves the final week for mixed retrieval. It writes a per-day plan to CSV and a calendar file (.ics) the student can import. Read `scripts/schedule.py --help` for all options (interval set, session cap, taper length).

## Step 3 — Balance the load

Open the CSV and check no day is overloaded past the session minutes. If days spill over, either add a study day, raise the per-session cap, or lengthen intervals for "solid" items. The scheduler flags overloaded days in its summary. A plan a student abandons in week two is worse than a lighter plan they finish.

## Differentiation

- **Executive function / ADHD.** Keep sessions short and fixed (same time, same length), cap items per session low, and make each day's plan a short concrete checklist rather than an open "study" block. The .ics import puts the plan where the student already looks.
- **High-confidence / advanced.** Start more items at "solid" so they get long intervals and the schedule spends its time on genuine gaps, not relearning.
- **Anxiety / overwhelm.** Show only the current week by default; the full plan exists but the student sees one week at a time.

## Authoring discipline

- **No false precision.** Spacing intervals are robust but approximate; present the dates as a workable plan, not a guarantee that recall happens on cue. Do not claim a specific retention percentage.
- **No hype, no filler.** "Try to recall before checking" beats "supercharge your memory." Drop "genuinely," "effortlessly," exclamation marks.
- **Retrieval is the instruction.** Every session note tells the student to attempt recall first, then check. If the plan reads like a rereading schedule, it is wrong.

## Output

Deliver the CSV (or a rendered weekly table) and the .ics, plus a short header explaining the three rules the plan runs on: recall before checking, mix topics, trust the gaps. Optionally render the weekly view as an EMERALDOPAL HTML or docx table. Keep the language plain and the dates real.

## Theming

Kuriausity EMERALDOPAL for any rendered view: Cormorant Garamond + Inter, opal gradient rule, emerald for "done" states, malachite labels, DM Mono for dates. Spelling: **Kuriausity**. Defer to project brand guidelines if supplied.
