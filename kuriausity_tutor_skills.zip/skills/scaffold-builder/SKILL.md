---
name: scaffold-builder
description: Build a practice set with faded scaffolding so a student moves from a fully worked example to independent work on the same skill. Use whenever a tutor or teacher needs practice problems, a problem set, worked examples, a step-by-step practice progression, guided-to-independent exercises, or "examples then problems" for a skill. Triggers include practice set, worked examples, scaffolded practice, fading support, gradual release, "give me problems that build up," or homework that ramps. Produces a sequence (worked → completion → faded → independent) on one skill, with the support removed gradually and a difficulty ramp, plus a worked-solution key.
---

# Scaffolded Practice (Gradual Release)

Handing a student ten independent problems after one example is a cliff. This skill builds a *ramp*: the same skill practiced through a sequence where support fades one step at a time, so the student is always working slightly beyond what they could do unaided but never in free fall. The structure is the **worked-example effect** and **completion problems** — proven ways to build a skill without overloading working memory.

## The fading sequence

For a single target skill, build four stages:

1. **Worked example** — the problem fully solved, every step shown *with the reasoning named*, not just the operations. The student studies it; they don't solve anything yet. Include a "why this step" note on the non-obvious moves.
2. **Completion problems** — the same problem type with some steps done and blanks for the student to fill. Start with only the last step blank, then earlier steps. The student supplies the part they're ready for while the rest holds the structure.
3. **Faded / prompted** — the full problem, but with prompts standing in for the removed scaffold: a hint, a first step given, a "remember to..." cue, a sentence frame. Support is present but thin.
4. **Independent** — the bare problem, no support. This is the transfer test: can they do it alone.

Across the four stages, also **ramp difficulty** modestly so the independent problems aren't just the worked example with new numbers; the last one or two should require a small extension or a less obvious case, which is where real learning shows.

## Workflow

1. Take the target skill (from a lesson objective, a diagnosis, or a named topic) and an example problem type.
2. Write one strong worked example with named reasoning.
3. Generate 2–3 completion problems, blanking later steps first, then earlier ones.
4. Generate 2–3 faded problems with shrinking prompts.
5. Generate 3–5 independent problems with a difficulty ramp and at least one transfer case.
6. Write a worked-solution key for every problem (not just answers).

## Authoring rules

**Name the reasoning, not just the steps.** The worked example's value is the thinking made visible: "I look for a common denominator first *because* unlike fractions can't combine" beats a silent line of arithmetic. The steps are visible already; the reasoning is what the student can't see.

**Fade one thing at a time.** Each stage removes one support, not all of them. If stage 3 is as bare as stage 4, the ramp has a gap and students fall through it.

**Keep the skill constant, vary the surface.** Every problem trains the same target skill; change the numbers, context, or framing so the student generalizes the method rather than memorizing one problem. Don't switch skills mid-set; that's a different set.

**One transfer problem at the end.** The final independent item should apply the skill to a slightly new situation. If a student can only do problems identical to the example, they have a procedure, not a skill.

**Every problem gets a worked solution, not a letter.** The key models the same named-reasoning the worked example did. A bare answer key can't teach a student who's stuck.

## Authoring discipline (read this every time)
- **Original problems only.** Train the same skill as any source; never reproduce copyrighted problems verbatim. Write fresh ones.
- **No filler in the reasoning notes.** Drop "genuinely," "as we can clearly see," "simply." If a step is hard, say what makes it hard.
- **Em dashes sparingly.** Worked steps read as clean instructions.
- **No false encouragement.** "This step trips people up; here's why" is honest and useful. "You've got this!" is noise.

## Differentiation
- **Support tier:** more completion problems, smaller fades, a worked example for each problem type, a reference card of the steps to keep visible.
- **Core tier:** the standard four-stage ramp.
- **Stretch tier:** start at the faded stage (skip the worked example and most completions), and make the transfer problem genuinely novel — justify the method, handle the edge case, or solve it a second way.
- **Executive function support:** number the stages visibly, put one problem per block with clear space, and mark where the student should pause and check before moving on, so the set is self-pacing.

## Output
Render as a print-ready set (the `docx` skill) or screen HTML, with stages clearly labeled, generous work space, and the worked-solution key on a separate page. The skill pairs naturally with `lesson-architect` (it builds the "you do" phase) and `worksheet-n-flashcards` (which handles assessment once the skill is practiced).

## Theming
Kuriausity EMERALDOPAL: Cormorant Garamond + Inter, opal gradient top rule, malachite stage labels, dark-field screen / light-field print. Spelling: **Kuriausity**. Defer to project brand guidelines if supplied.
