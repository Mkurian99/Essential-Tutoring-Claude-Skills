---
name: rubric-and-feedback
description: Build an analytic rubric for an assignment and generate targeted, criterion-referenced feedback against it. Use whenever a tutor or teacher needs a rubric, a grading guide, a scoring guide for an essay/debate/lab/problem set/presentation, a way to grade consistently, or specific written feedback on a student's work. Triggers include rubric, grading criteria, scoring guide, "how should I grade this," feedback on a draft, marking, or assessment criteria. Produces a leveled analytic rubric (criteria x performance levels with concrete descriptors) and, when given student work, feedback that names the level, points to evidence, and gives one prioritized next move per criterion.
---

# Rubric & Targeted Feedback

A rubric makes grading consistent and turns a grade into instruction: the student should be able to read it and know exactly what "better" looks like. This skill builds **analytic** rubrics (separate criteria, each scored across performance levels with concrete descriptors) and uses them to generate feedback that is specific, evidence-based, and actionable. A rubric of vague adjectives ("excellent / good / fair") teaches nothing; the descriptors must describe observable features of the work.

## Part 1 — Build the rubric

### Workflow
1. Identify the 3–6 criteria that actually matter for this task. More than six and grading becomes unreliable; fewer than three and it's not analytic.
2. Choose the performance levels (default four: Emerging, Developing, Proficient, Distinguished). Four avoids the "safe middle" of a three-level scale and stays manageable.
3. Write a concrete descriptor for each cell. The descriptor names what the work *shows*, not how good it is.
4. Weight the criteria if some matter more, and state the weighting.

### Rules for good criteria
- **Criteria are dimensions of quality, not parts of the assignment.** For an essay: thesis, evidence, reasoning, structure, style, mechanics — not "introduction, body, conclusion." Dimensions can be assessed independently; parts can't.
- **Descriptors are observable.** "Thesis is arguable and specific; names a position a reasonable person could dispute" beats "good thesis." A tutor and a student should read the same cell and agree the work is or isn't there.
- **Levels differ by features, not by intensity words.** The move from Developing to Proficient should be a describable change in the work ("evidence is present but not interpreted" → "each piece of evidence is tied to the claim it supports"), not "fairly good" → "very good."
- **Make adjacent levels distinguishable.** If you can't tell two adjacent cells apart, the student can't either. Each step up names a specific thing the previous level was missing.

### Domain notes
- **Debate / forensics** (a brand strength): criteria like case construction, clash and refutation, weighing, signposting, delivery. Reward engagement with the opponent's argument, not just delivery of one's own.
- **Essay** (Essay Writing Tour de Force): thesis, evidence, reasoning, structure, style, mechanics.
- **Problem sets / quantitative:** correct method, accuracy, clarity of work shown, justification.
- **Presentation:** content accuracy, organization, delivery, response to questions.

## Part 2 — Generate feedback against the rubric

When given student work plus the rubric, produce feedback that does three things per criterion, in this order:

1. **Name the level and why** — which cell the work lands in, with a quotation or specific reference from the work as evidence. Specific reference, never "your essay was unclear."
2. **Name the gap to the next level** — the one describable thing that would move it up, taken straight from the next rubric cell.
3. **Give one concrete next move** — a single action the student can take on the next draft for this criterion. Not five suggestions; the one that matters most.

Then a short global note that prioritizes: of all the criteria, which one change would most improve the work. Students can act on one priority; a flat list of every flaw gets ignored.

### Feedback tone
- **Criterion-referenced, not person-referenced.** "The thesis names a topic but not a position" beats "you didn't think hard enough." Critique the work, address the writer with respect.
- **Specific and balanced.** Name what works as precisely as what doesn't, so the student knows what to keep. Vague praise is as useless as vague criticism.
- **Honest.** If the work is at Emerging, the feedback says so plainly and kindly. Inflated feedback robs the student of the information they need. (This matches the firm's no-flattery standard.)

## Authoring discipline (read this every time)
- **No filler or hype.** Drop "genuinely," "great job overall," "amazing potential." Say what is on the page.
- **No promissory claims.** Feedback describes the current draft and the next move, not a guaranteed grade.
- **Em dashes sparingly.** Feedback should read as clean, direct sentences.
- **One priority, not a pile.** The global note picks the single highest-leverage change.

## Differentiation
- **Two-column rubric for younger or support-tier students:** a "got it / not yet" version of the same criteria with student-facing language, alongside the full four-level rubric for the tutor.
- **Glow-and-grow framing** for early learners: one strength named precisely, one next move, per criterion, without the full level grid.
- **Self-assessment column.** Add a blank column for the student to rate themselves before the tutor does; comparing the two is itself instruction and is especially useful for executive-function and metacognition work.

## Output
Render the rubric as a clean table (criteria as rows, levels as columns, weights noted) via the `docx` skill for print or HTML for screen. Deliver feedback as a short structured document keyed to the rubric criteria, ending with the single prioritized next move. If the feedback reveals a recurring conceptual error, hand it to `error-analysis`; if it implies a reteach, hand the objective to `lesson-architect`.

## Theming
Kuriausity EMERALDOPAL: Cormorant Garamond + Inter, opal gradient top rule, malachite for level headers, emerald for the "next move." Dark-field screen / light-field print. Spelling: **Kuriausity**. Defer to project brand guidelines if supplied.
