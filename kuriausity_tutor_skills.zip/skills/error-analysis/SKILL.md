---
name: error-analysis
description: Diagnose the misconception behind a student's wrong answers or work sample and prescribe targeted micro-lessons, instead of just marking it wrong. Use whenever a tutor or teacher has a student's errors, a graded test, a worked problem with mistakes, a pattern of "they keep getting this wrong," or wants to understand why a student is making a mistake and what to do about it. Triggers include error analysis, misconception, "why do they keep getting X wrong," diagnosing mistakes, mistake patterns, or analyzing student work. Output names the likely underlying misconception (not just the surface error), explains the faulty reasoning, and prescribes a specific reteach and a check.
---

# Error Analysis & Misconception Mapper

Most wrong answers are not random; they are the correct output of a *wrong rule* the student is running consistently. The job is to find the rule. "Marked wrong, try again" leaves the faulty rule in place, so the student reproduces the error on the next problem. This skill reads student work, infers the underlying misconception, and prescribes the specific reteach that replaces the wrong rule with the right one.

## The core distinction

- **Slip** — a careless one-off (transposed digits, skipped step) the student can self-correct. Note it, don't reteach it.
- **Misconception** — a stable wrong rule producing predictable errors. This is the target. It is reproducible: give a similar problem and the same error appears.

Tell them apart by looking for *pattern*. One wrong answer is data; the same error across several problems is a misconception you can name.

## Workflow

1. Collect the work: the problems, the student's answers, and (ideally) their shown steps. Steps are gold; without them you infer the rule from the answers.
2. For each error, reconstruct the procedure the student *did* run that would produce that exact answer. Work backward from the wrong answer to the rule that generates it.
3. Group errors into misconceptions. Several surface errors often trace to one wrong rule.
4. Name each misconception in plain language and state the correct rule it displaces.
5. Prescribe a targeted micro-lesson and a check for each misconception, prioritized.

## Step 2 — Reconstruct the faulty rule (the heart of this skill)

Don't label the error ("subtraction mistake"); reproduce it. Ask: what rule, applied correctly, yields this wrong answer?

**Example.** Student computes 5/6 − 1/3 = 4/3.
- Surface label: "got the fraction wrong." Useless.
- Reconstruction: they subtracted across (5−1=4) and (6−3=3) without a common denominator. The rule they're running is "subtract numerators, subtract denominators." That rule also predicts their answer to 3/4 − 1/2. Test it; if it holds, you've found the misconception.
- This is now teachable: the student needs *why* the common denominator is required, not another worked problem.

Classic misconception families to scan for: over-generalized rules ("add across" carried from multiplication), inverted conditionals (affirming the consequent — directly relevant to LSAT/LR work), sign errors from a misremembered rule, place-value confusions, applying a special case as the general rule, and confusing a term with its sibling (necessary vs sufficient, civil liberty vs civil right, mean vs median).

## Step 3 — Output: the diagnosis

For each misconception:

```
Misconception: "Subtract numerators and subtract denominators."
Evidence: items 3, 7, 11 — each is the across-subtraction result, not a slip.
Why it persists: the rule works for multiplying fractions, so it feels consistent.
Correct rule it displaces: unlike fractions need a common denominator first.
Reteach (micro-lesson): a 10-minute visual with fraction bars showing why
  sixths and thirds can't combine until they're the same size; then two
  problems worked aloud naming the common-denominator step.
Check: 7/8 − 1/4 and 2/3 − 1/6 — if the across-error is gone, it's fixed;
  if it returns, the visual didn't land, so try the number-line model.
```

End with a **priority order**: which misconception to address first. Prerequisite errors come before downstream ones — there's no point fixing fraction subtraction if the student doesn't yet have equivalent fractions. The order is the lesson sequence.

## Authoring discipline (read this every time)
- **Diagnose the work, never the student.** "The rule being run is X" beats "the student is sloppy / not trying / bad at math." The faulty rule is fixable; a character judgment is not, and it's usually wrong.
- **Reconstruct, don't guess.** Every named misconception must be supported by a reconstruction that *predicts the actual wrong answer*. If your explanation doesn't reproduce the error, it's the wrong explanation.
- **No filler, no hype.** Drop "genuinely," "clearly the student just needs to focus." Plain reconstructions.
- **Distinguish slip from misconception honestly.** Don't manufacture a deep misconception out of one careless error; don't dismiss a real pattern as carelessness.

## Differentiation
- **When steps are missing** (younger students, or a bare answer key): infer cautiously, state the inference as provisional, and prescribe a "show me how you did one" probe before committing to a reteach.
- **For ELL students:** check whether the error is conceptual or a language miss — a word-problem error can be a vocabulary gap, not a math gap. Separate the two before prescribing.
- **For anxious or discouraged students:** lead the student-facing version with the fact that the error is systematic and therefore fixable, which is true and reframes "I'm bad at this" as "I learned one rule wrong."

## Output
Deliver a tutor-facing diagnosis (the structure above) and, when useful, a brief student-facing note that names the one rule to fix first without jargon. The misconception list is the natural input to `lesson-architect` (the reteach) and `spaced-review-planner` (spacing the corrected items for retention).

## Theming
Kuriausity EMERALDOPAL for rendered output: Cormorant Garamond + Inter, opal gradient rule, malachite labels, dark-field screen / light-field print. Spelling: **Kuriausity**. Defer to project brand guidelines if supplied.
