---
name: diagnostic-builder
description: Build a short diagnostic or placement assessment that locates where a student actually is and maps every wrong answer to a specific skill gap. Use whenever a tutor or teacher needs a baseline test, placement check, pre-assessment, "figure out what they don't know yet" instrument, intake quiz, or a diagnostic to decide what to teach next — including from a syllabus, standard, exam blueprint, or a topic the user names. Distinct from worksheet/quiz generation: the deliverable here is diagnostic, every item is tagged to a sub-skill, and the output includes a results-to-next-steps map, not just a score.
---

# Diagnostic & Placement Builder

A diagnostic is not a quiz. Its job is to find the *edge* of what a student can do, so the tutor knows where to start. That means every item targets one named sub-skill, the items climb in difficulty until they break, and the answer key tells the tutor what a given miss *means* and what to teach next. A diagnostic that produces only a number has failed.

## Workflow

1. Read the source (syllabus, standard, exam blueprint, prior work) or take the named topic.
2. Decompose the domain into a **skill map**: the ordered sub-skills a student needs, from prerequisite to target. This map is the spine of the whole instrument.
3. Write 2–3 items per sub-skill at graduated difficulty, tagged to the sub-skill.
4. Build the **diagnostic key**: for each item, the answer, the sub-skill it tests, the most likely misconception behind each distractor, and the recommended next move.
5. Render the student-facing form and the tutor-facing key as separate documents.

## Step 1 — Build the skill map

Decompose the target into 5–10 ordered sub-skills. Order matters: a diagnostic works by walking up the ladder until the student stops succeeding, so prerequisite skills come first.

Example (fractions): (1) part-whole naming → (2) equivalent fractions → (3) common denominators → (4) addition/subtraction → (5) multiplication → (6) division → (7) word-problem translation.

State each sub-skill as something a student *does*, not a topic label: "converts a mixed number to an improper fraction," not "mixed numbers."

## Step 2 — Authoring rules

**One sub-skill per item, tagged.** Every item names the sub-skill it probes. If an item needs three skills to solve, you can't tell which one failed; split it.

**Climb until it breaks.** Within each sub-skill, order items easy → hard. The point of difficulty where a student stops getting items right is the diagnostic signal. A flat-difficulty diagnostic locates nothing.

**Distractors are diagnostic, not decorative.** Each wrong option should correspond to a specific, nameable error: the off-by-one, the inverted rule, the prerequisite the student skipped, the classic procedure-without-understanding slip. The key records what each distractor reveals. This is most of the value of the instrument.

**Keep it short.** A diagnostic is 12–24 items, not 50. You are sampling the ladder, not exhaustively testing it. Long diagnostics get abandoned and tell you nothing about a tired student.

**Mix item types only with reason.** Multiple-choice gives clean distractor diagnostics; a short constructed-response ("show your steps") surfaces process errors a bubble can't. Use a few constructed-response items at the rungs where *how* a student works matters more than whether they land the answer.

## Authoring discipline (read this every time)

- **Test the subject, never the document.** Do not write items about the source's own framing — not "how many questions are on this exam," not "what does this unit cover," not page numbers or the guide's instructions. That meta-content is not knowledge; turning it into questions is the most common way these instruments go wrong. The only exception is when the user explicitly asks the student to learn an exam's format.
- **No filler intensifiers** in stems or rationales: drop "genuinely," "truly," "essentially," "delve," "in today's world." Plain declaratives.
- **No promissory language.** The key says "indicates the student has not yet mastered X," not "this will fix their grade."
- **Em dashes sparingly.** One per paragraph at most; prefer a period.
- **Original items only.** Test the same knowledge as any source, but never reproduce a copyrighted item verbatim or near-verbatim.

## Step 3 — Differentiation

Diagnostics serve a diverse intake. Build in:

- **A floor and a ceiling.** Include 2–3 items below the expected entry point (so a struggling student isn't stuck at zero, which tells you nothing) and 2–3 above the target (so a placement-out student is identified rather than capped).
- **Access without dilution.** For ELL or reading-load concerns, keep stems in plain syntax and short sentences so you are measuring the target skill, not reading speed — unless reading *is* the skill being assessed. Note where you simplified language so the tutor knows it was deliberate.
- **A process lane.** For executive-function or 2e profiles, the constructed-response items that ask for steps reveal whether the gap is the concept or the organization of work. Flag those items in the key.

## Step 4 — Output

Produce two artifacts.

**Student form** — a clean test with no skill tags visible (tags would coach the answer). Use the `worksheet-n-flashcards` generator or the `docx` skill for a print-ready form, or a simple HTML form for online delivery. Numbered items, lettered options, space for constructed responses, a short honest instruction line ("Work in order. If you don't know one, skip it rather than guess, so the result reflects what you actually know.").

**Tutor key** — the diagnostic instrument. One row per item:

```json
{
  "item": 7,
  "sub_skill": "finds a common denominator for unlike fractions",
  "answer": "C",
  "distractor_meaning": {
    "A": "added denominators directly (no common denominator)",
    "B": "used the larger denominator without scaling the numerator",
    "D": "multiplied denominators but forgot to scale numerators"
  },
  "if_missed": "Back up to equivalent fractions before attempting addition; assign the equivalent-fractions micro-lesson first."
}
```

Close the key with a **placement summary**: a short rule for reading the result. "Highest sub-skill answered correctly at both difficulty levels = the student's working edge. Start instruction one rung below it." Then a routing table mapping likely failure patterns to the first lesson to teach. If the result feeds another skill, the failure tags are the input for `error-analysis` and `lesson-architect`.

## Theming

Visual outputs use the Kuriausity EMERALDOPAL system (dark-field for screen, light-field for print): Cormorant Garamond display + Inter body, the opal gradient as a thin top rule, emerald CTA, malachite labels. Note the spelling: **Kuriausity**, never "Kuriousity." If the project supplies different brand guidelines, follow those instead.
