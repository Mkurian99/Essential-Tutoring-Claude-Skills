---
name: text-leveler
description: Rewrite any passage at multiple reading levels while holding the content constant, and produce a vocabulary gloss for access. Use whenever a tutor or teacher needs to make a text easier or harder, level a reading for a mixed-ability group, produce a struggling-reader and an advanced version of the same passage, adapt material for English-language learners, simplify a dense primary source, or "meet the text where the student is." Triggers include leveling, differentiating a reading, simplifying, scaffolding a hard text, ELL adaptation, or producing tiered versions of one source. Comes with a readability scorer so the levels can be verified, not guessed.
---

# Text Leveler & Readability Tiers

The same idea, told three ways, so a mixed group reads the *same content* at the level each student can actually decode. The hard part is holding meaning constant while changing the load: a good leveled version keeps every claim and the logical structure of the original, and changes only sentence length, syntax, and vocabulary. Cutting content is not leveling; it is a different (shorter) text.

## Workflow

1. Read the source passage in full.
2. Decide the tier set (default three: foundation, core, stretch — see below).
3. Rewrite the passage at each tier, preserving all content and structure.
4. Build a vocabulary gloss for the words that carry the load.
5. Verify with the readability scorer; adjust until the tiers actually separate.
6. Deliver the tiers side by side with the gloss.

## Step 1 — Set the tiers

Default to three, anchored to grade bands the user names (or infer from context):

- **Foundation** — shorter sentences, common words, one idea per sentence, explicit connectives ("because," "so," "but"). Pronouns resolved to their nouns. No subordinate clause stacking.
- **Core** — the target grade level. Normal sentence variety, grade-appropriate vocabulary, the original's structure intact.
- **Stretch** — the original or slightly elevated: richer syntax, precise and abstract vocabulary, implication left for the reader to draw.

If the user names specific grades ("a 4th-grade and an 8th-grade version"), target those. The scorer (Step 5) confirms you hit them.

## Step 2 — Leveling rules

**Content is invariant.** Every factual claim, every step of an argument, every named entity in the source appears in every tier. If the foundation version drops a claim, it is wrong. Reduce *load*, not *information*. The one thing that changes across tiers is how hard the language is to process, never what the passage says.

**Lower a level by:** shortening sentences; replacing rare words with common ones (and glossing the rare word rather than deleting the concept); unpacking nominalizations into verbs ("the destruction of the city" → "the army destroyed the city"); making implicit logic explicit; resolving pronouns; one idea per sentence.

**Raise a level by:** combining related sentences with subordination; restoring precise domain vocabulary; using implication instead of spelling out; varying sentence openings. Never raise a level by adding padding or abstraction for its own sake.

**Keep the register honest.** A leveled-down history passage still reads like history, not like a children's storybook narrator. Do not add "Wow!" or rhetorical questions or a chummy voice. Plain is not the same as cute.

## Authoring discipline (read this every time)

- **No filler intensifiers and no AI tells.** Drop "genuinely," "truly," "delve," "it's important to note," "in today's world." These inflate load without adding content, which defeats the purpose.
- **Em dashes sparingly.** A leveled-down tier should mostly use periods; a dash forces the reader to hold two clauses at once.
- **Don't moralize.** Adapting a text does not license adding a lesson or a takeaway the source didn't have.
- **Attribute, don't reproduce at length.** If the source is copyrighted, your tiers are paraphrases of substantial passages, which is fine; do not reproduce long verbatim stretches of the original in the "stretch" tier. Summarize and rephrase.

## Step 3 — Vocabulary gloss

Pull the words that carry the meaning and would block a reader: domain terms, low-frequency words, and words used in a non-everyday sense. For each, give a short plain-language meaning and, where it helps an ELL reader, the part of speech and a same-sentence example. This is what lets the foundation tier keep a hard concept (gloss the word) instead of deleting it.

## Step 4 — Differentiation built in

- **ELL lane.** Offer the foundation tier with the gloss inline and cognates noted where they exist (Spanish/Malayalam/German per the project's languages, if relevant). Keep idioms out of the foundation tier or gloss them; idioms are the silent wall for language learners.
- **Dyslexia-friendly formatting option.** When asked, render with generous line spacing, left-aligned ragged-right text, short paragraphs, and a sans-serif body. Offer it; do not impose it.
- **One-source, many-readers principle.** The deliverable is designed so a tutor can hand different tiers to different students working from the *same* lesson, then run one discussion. Keep paragraph breaks parallel across tiers so students can be on "the second paragraph" together.

## Step 5 — Verify with the scorer

Run the bundled scorer to confirm the tiers actually separate and hit their targets:

```bash
python scripts/readability.py foundation.txt core.txt stretch.txt
```

It reports Flesch Reading Ease, Flesch–Kincaid grade, average sentence length, and percent of long words for each file, side by side. If two tiers land at the same grade, they are not different tiers; revise and rerun. The scorer is a check on your own work, not a target to game — do not shorten sentences past sense just to move a number.

## Step 6 — Deliver

Default to a single document with the tiers in parallel columns or stacked sections, each labeled with its verified grade level, followed by the gloss. Use the `docx` skill for a print handout or render HTML for screen. Keep the labels factual ("Reading level: grade 4," from the scorer), not euphemistic.

## Theming

Visual outputs use the Kuriausity EMERALDOPAL system: Cormorant Garamond display + Inter body, opal gradient top rule, dark-field for screen and light-field for print. Spelling: **Kuriausity**. If the project supplies other brand guidelines, follow those.
