#!/usr/bin/env python3
"""Readability scorer for the text-leveler skill.

Reports Flesch Reading Ease, Flesch-Kincaid grade level, mean sentence
length, and percent long words for one or more text files, side by side,
so leveled tiers can be verified rather than guessed.

Usage:
    python readability.py foundation.txt core.txt stretch.txt
    python readability.py passage.txt            # single file
No third-party dependencies. Syllable counts are estimated heuristically,
so treat grade levels as +/- one grade, not exact. The point is the
*separation* between tiers, not a precise absolute.
"""
import re
import sys


def split_sentences(text):
    # Split on sentence-ending punctuation followed by space/newline.
    parts = re.split(r"(?<=[.!?])\s+", text.strip())
    return [p for p in parts if p.strip()]


def words(text):
    return re.findall(r"[A-Za-z]+(?:'[A-Za-z]+)?", text)


def count_syllables(word):
    word = word.lower()
    if not word:
        return 0
    # Vowel-group heuristic with a silent-e correction.
    groups = re.findall(r"[aeiouy]+", word)
    n = len(groups)
    if word.endswith("e") and not word.endswith(("le", "ee", "ie")):
        n -= 1
    if word.endswith("le") and len(word) > 2 and word[-3] not in "aeiouy":
        n += 1
    return max(1, n)


def score(text):
    sents = split_sentences(text)
    wlist = words(text)
    n_sent = max(1, len(sents))
    n_word = max(1, len(wlist))
    syllables = sum(count_syllables(w) for w in wlist)
    long_words = sum(1 for w in wlist if count_syllables(w) >= 3)

    asl = n_word / n_sent              # average sentence length
    asw = syllables / n_word           # average syllables per word
    flesch = 206.835 - 1.015 * asl - 84.6 * asw
    fk_grade = 0.39 * asl + 11.8 * asw - 15.59
    pct_long = 100.0 * long_words / n_word
    return {
        "words": n_word,
        "sentences": n_sent,
        "mean_sentence_len": asl,
        "flesch_reading_ease": flesch,
        "fk_grade": fk_grade,
        "pct_long_words": pct_long,
    }


def band(grade):
    if grade < 1:
        return "K"
    if grade <= 5:
        return "elementary"
    if grade <= 8:
        return "middle"
    if grade <= 12:
        return "high school"
    return "college+"


def main(paths):
    rows = []
    for p in paths:
        try:
            with open(p, encoding="utf-8") as f:
                txt = f.read()
        except OSError as e:
            print(f"  skip {p}: {e}", file=sys.stderr)
            continue
        s = score(txt)
        rows.append((p, s))

    if not rows:
        print("No readable files.", file=sys.stderr)
        return 1

    name_w = max(len(p) for p, _ in rows) + 2
    print(f"{'file':<{name_w}}{'words':>7}{'sent':>6}{'len':>7}"
          f"{'FK grade':>10}{'band':>14}{'ease':>8}{'%long':>8}")
    print("-" * (name_w + 60))
    for p, s in rows:
        print(f"{p:<{name_w}}{s['words']:>7}{s['sentences']:>6}"
              f"{s['mean_sentence_len']:>7.1f}{s['fk_grade']:>10.1f}"
              f"{band(s['fk_grade']):>14}{s['flesch_reading_ease']:>8.0f}"
              f"{s['pct_long_words']:>7.0f}%")

    if len(rows) > 1:
        grades = [s["fk_grade"] for _, s in rows]
        spread = max(grades) - min(grades)
        print("-" * (name_w + 60))
        if spread < 1.5:
            print(f"NOTE: tiers span only {spread:.1f} grade levels. "
                  "They are too close to function as distinct tiers; revise.")
        else:
            print(f"OK: tiers span {spread:.1f} grade levels.")
    return 0


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    sys.exit(main(sys.argv[1:]))
